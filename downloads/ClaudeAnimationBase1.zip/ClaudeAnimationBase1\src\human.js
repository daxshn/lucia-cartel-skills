// human.js: a hand-painted cartoon person that takes the SAME options as clawd() (emotions(), feel(), move(), hold()
// props, hats, emotes, walk/view/flip), so any scene written for Clawd can swap clawd → human.
// (x, y) = ground point between the feet; u = size unit. A person is about 12u tall:
//   feet 0, hip -3.1u, shoulders -6u, head centre -8.9u (radius ~2.9u), head top -11.8u.
// Extra options: cast (a CAST key, or an object like CAST entries), old (grey hair), sit (seated on something ~3u high).
const CAST = {
  A:  { skin: '#F1C29C', hair: '#3A2A2C', style: 'short', top: '#4F86C2', legs: '#39456A', shoe: '#2B2738' },
  B:  { skin: '#F6CDA9', hair: '#5B3122', style: 'long',  top: '#E17C92', legs: '#F6CDA9', shoe: '#8B3A52', dress: true },
  C:  { skin: '#C98D63', hair: '#231E26', style: 'short', top: '#E3A33B', legs: '#57483B', shoe: '#2B2738' },
  D:  { skin: '#8E5C40', hair: '#1E1A22', style: 'curly', top: '#6FA06A', legs: '#3B3F55', shoe: '#2B2738' },
};
const _CROWD = {
  skin: ['#F1C29C', '#D9A27A', '#B87B55', '#8E5C40', '#F6CDA9', '#C98D63'],
  hair: ['#3A2A2C', '#7A4A2E', '#1E1A22', '#B9774A', '#5B3122', '#2B2738'],
  top:  ['#D2493A', '#4F9FA8', '#8A6FB8', '#E3A33B', '#5E8F4E', '#E17C92', '#4F86C2'],
  style: ['short', 'long', 'curly', 'bun', 'short', 'long'],
};
function castOf(key, o) {
  if (o.cast && typeof o.cast === 'object') return o.cast;
  if (CAST[o.cast || key]) return CAST[o.cast || key];
  let h = 0; for (const ch of String(key)) h = (h * 31 + ch.charCodeAt(0)) % 9973;
  const pick = (arr, k) => arr[Math.floor(hash(h + k) * arr.length) % arr.length];
  const style = pick(_CROWD.style, 3), dress = style === 'long' || style === 'bun';
  const skin = pick(_CROWD.skin, 1);
  return { skin, hair: pick(_CROWD.hair, 2), style, top: pick(_CROWD.top, 4), legs: dress ? skin : pick(['#39456A', '#57483B', '#3B3F55', '#6B5A4A'], 5), shoe: '#2B2738', dress };
}
// clawd's arm angle (0 = straight out, .2 = rest, 1.5 = straight up) → a person's (rest hangs down by the side)
const armAng = a => a < .2 ? -1.15 + (a - .2) * .35 : -1.15 + (a - .2) / 1.3 * 2.65;

let HUMAN_N = 0;
function human(x, y, u, o = {}) {
  const id = o.boilKey ?? 'h' + (++HUMAN_N), rs = part => boilSeed(`human ${id} ${part}`);
  const C = castOf(id, o);
  x += (o.dx || 0) * u * .6;
  const view = o.view || 'front', side = view === 'side', backish = view === 'back' || view === 'qback';
  const dy = (o.dy || 0) * u * .75, sq = ((o.sq || 0) + (o.take || 0)) * .6;
  const sw = clamp(u / 15, .45, 2.4), J = u * .05;
  // mood colour on the skin: a named tint, or the cross-faded body colour emotions() hands over mid-change
  let skin = C.skin;
  if (o.tint && (o.tintK ?? 1) > 0) skin = mixCol(skin, TINT[o.tint] || o.tint, .32 * clamp(o.tintK ?? 1));
  else if (o.col && o.col !== PAL.clay) { const a = o.col, b = PAL.clay, d = Math.abs(parseInt(a.slice(1, 3), 16) - parseInt(b.slice(1, 3), 16)) + Math.abs(parseInt(a.slice(3, 5), 16) - parseInt(b.slice(3, 5), 16)) + Math.abs(parseInt(a.slice(5, 7), 16) - parseInt(b.slice(5, 7), 16)); skin = mixCol(skin, a, clamp(d / 140) * .3); }
  const skinDk = mixCol(skin, '#7A3E2E', .3), hair = o.old ? '#D6D2DC' : C.hair, hairDk = mixCol(hair, PAL.ink, .3);
  const top = C.top, topDk = mixCol(top, PAL.ink, .25);
  const HC = -8.9 * u, HR = 2.9 * u;   // head centre and radius
  const sit = !!o.sit, airborne = Math.abs(o.dy || 0);

  rs('shadow');
  if (!o.noShadow) { const f = 1 - Math.min(.5, airborne * .06); paint(ellPts(x, y + u * .15, u * (side ? 2.2 : 3) * f, u * .75 * f, 20), { fill: PAL.ink, fillOp: 85, bleed: .25, tex: .3, border: .1, ink: null }); }

  push();
  translate(x, y + dy);
  if (o.rot) rotate(o.rot * .7);
  scale((o.flip ? -1 : 1) * (o.sx ?? 1) * (1 + sq * .6), (o.sy ?? 1) * (1 - sq));

  // ----- arms -----
  const SH = -5.65 * u, AL = 2.9 * u, AW = .78 * u;
  const arm = (which, px, dir, behind) => {
    rs('arm' + which);
    const a = which === 'L' ? (o.aL ?? .2) : (o.aR ?? .2), hook = which === 'L' ? o.armL : o.armR;
    push(); translate(px, SH);
    let ang = armAng(a);
    if (side) rotate(-ang); else rotate(dir < 0 ? ang : -ang);
    const s = side ? 1 : dir, x0 = s < 0 ? -AL : 0;
    const sleeve = behind ? topDk : top, hand = behind ? skinDk : skin;
    paint(rrPts(x0, -AW / 2, AL, AW, AW * .45, J * .5), { wash: hand, washOp: 255, ink: PAL.ink, sw: sw * .7 });
    paint(rrPts(s < 0 ? -AL * .48 : 0, -AW / 2 - .05 * u, AL * .48, AW + .1 * u, AW * .4, J * .5), { wash: sleeve, washOp: 255, ink: PAL.ink, sw: sw * .7 });
    paint(ellPts(s * AL, 0, .5 * u, .48 * u, 12, J * .4), { wash: hand, washOp: 255, ink: PAL.ink, sw: sw * .7 });
    if (hook) { translate(s * (AL - .9 * u), 0); if (s < 0) scale(-1, 1); hook(u, sw); }
    pop();
  };
  const SX = side ? .15 * u : 1.85 * u;
  if (side) arm('R', -.2 * u, 1, true);
  else if (view === 'q') arm('R', SX - .3 * u, 1, true);

  // ----- legs -----
  const HIP = -3.1 * u, legX = side ? [.05, -.05] : [-.72, .72];
  if (!o.noLegs) [0, 1].forEach(i => {
    rs('leg' + i);
    let lx = legX[i] * u, lift = 0, kneeFwd = 0;
    if (o.walk != null) {
      const ph = (o.walk + (i ? .5 : 0)) * TAU;
      if (side) { lx += Math.sin(ph) * .95 * u; lift = Math.max(0, Math.cos(ph)) * .55 * u; }
      else lift = Math.max(0, Math.sin(ph)) * .5 * u;
    }
    const far = side && i === 1, col = far ? mixCol(C.legs, PAL.ink, .2) : C.legs;
    if (sit) {   // thigh comes toward us (a short blob at the hip), shin hangs down to the floor
      paint(ellPts(lx * 1.25, HIP + .35 * u, .62 * u, .55 * u, 12), { wash: C.dress ? top : col, washOp: 255, ink: PAL.ink, sw: sw * .7 });
      kneeFwd = .25 * u;
    }
    const top0 = HIP + (sit ? .7 * u : 0);
    paint(rectPts(lx * (sit ? 1.25 : 1) - .42 * u, top0, .84 * u, -top0 - .3 * u - lift, J * .5), { wash: col, washOp: 255, ink: PAL.ink, sw: sw * .7 });
    const fx = lx * (sit ? 1.25 : 1) + (side ? .35 * u : (i ? .12 : -.12) * u) + kneeFwd * 0;
    paint(ellPts(fx, -.32 * u - lift, side ? .75 * u : .58 * u, .36 * u, 12), { wash: far ? mixCol(C.shoe, PAL.ink, .2) : C.shoe, washOp: 255, ink: PAL.ink, sw: sw * .7 });
  });

  // ----- long hair behind the body -----
  const fw = side ? .8 : view === 'q' ? .85 : 1, fcx = side ? 1.05 * u : view === 'q' ? .6 * u : 0;
  const style = o.old ? (C.style === 'long' || C.style === 'bun' ? 'bun' : 'old') : C.style;
  if (style === 'long') {
    rs('hairback');
    const P = backish
      ? [[-3.1, -9.4], [-3.4, -6.5], [-2.8, -4.6], [0, -4.3], [2.8, -4.6], [3.4, -6.5], [3.1, -9.4]]
      : side ? [[-1.8, -10.5], [-3.4, -8], [-3.3, -5.2], [-1.6, -4.7], [.2, -6.2], [.6, -9]]
      : [[-3.0, -9.6], [-3.4, -6.6], [-3.0, -4.7], [-1.7, -5.0], [1.7, -5.0], [3.0, -4.7], [3.4, -6.6], [3.0, -9.6]];
    paint(P.map(([a, b]) => [a * u, b * u]), { wash: hair, washOp: 255, fill: hairDk, fillOp: 60, tex: .6, ink: PAL.ink, sw: sw * .8, curv: .5 });
  }

  // ----- torso -----
  rs('body');
  const tw = side ? 1.35 : 1.9;
  const torso = C.dress
    ? [[-tw * .82, -6.1], [tw * .82, -6.1], [tw * 1.05, -4.4], [tw * 1.3, -2.55], [-tw * 1.3, -2.55], [-tw * 1.05, -4.4]]
    : [[-tw, -6.1], [tw, -6.1], [tw * .92, -4.2], [tw * .86, -2.95], [-tw * .86, -2.95], [-tw * .92, -4.2]];
  paint(rectPts(-.45 * u, -6.5 * u, .9 * u, .8 * u), { wash: skinDk, washOp: 255, ink: PAL.ink, sw: sw * .6 });   // neck
  const TP = torso.map(([a, b]) => [a * u, b * u]);
  paint(TP, { wash: top, washOp: 255, fill: topDk, fillOp: 55, bleed: .05, tex: .6, ink: PAL.ink, sw, curv: .25 });
  if (!C.dress && !backish) inkLine([[-tw * .55 * u, -6.05 * u], [0, -5.4 * u], [tw * .55 * u, -6.05 * u]], sw * .6, PAL.ink, 'inkfine', .5);   // collar
  if (!C.dress) paint(rectPts(-tw * .88 * u, -3.35 * u, tw * 1.76 * u, .42 * u), { wash: mixCol(C.legs, PAL.ink, .15), washOp: 255, ink: PAL.ink, sw: sw * .5 });   // belt line

  // ----- head -----
  rs('head');
  const headPts = ellPts(fcx * .25, HC, HR * (side ? .92 : 1), HR * 1.02, 26, J);
  if (!backish) for (const s of side ? [-1] : [-1, 1]) paint(ellPts(s * HR * .98 + (side ? -.2 * u : 0), HC + .3 * u, .5 * u, .65 * u, 10), { wash: skin, washOp: 255, ink: PAL.ink, sw: sw * .6 });   // ears
  paint(headPts, { wash: backish ? hair : skin, washOp: 255, ink: null });
  if (!backish) paint(ellPts(fcx * .25 - .9 * u, HC - 1.2 * u, 1.5 * u, 1 * u, 14, J), { fill: '#FFFFFF', fillOp: 45, bleed: .2, tex: .7, ink: null });
  paint(headPts, { ink: PAL.ink, sw });
  if (o.gloom > .02 && !backish) {
    paint(ellPts(fcx * .25, HC - 1.6 * u, HR * .85, 1.1 * u, 18), { fill: PAL.indigo, fillOp: 150 * o.gloom, bleed: .1, tex: .5, ink: null });
    for (let i = 0; i < 4; i++) { const gx = fcx * .25 + (-1.3 + i * .87) * u; inkLine([[gx, HC - 2.4 * u], [gx, HC - (2.4 - 1.6 * o.gloom) * u]], sw * .4, PAL.ink, 'inkfine', 0); }
  }

  // ----- hair on top -----
  rs('hair');
  const H = pts => pts.map(([a, b]) => [a * u, b * u]);
  if (backish) paint(H([[-2.9, -9.2], [-2.6, -11], [0, -11.95], [2.6, -11], [2.9, -9.2], [2.5, -7], [0, -6.4], [-2.5, -7]]), { wash: hair, washOp: 255, fill: hairDk, fillOp: 60, tex: .6, ink: PAL.ink, sw, curv: .5 });
  else if (side) paint(H([[-2.6, -8.2], [-2.8, -10.2], [-1, -11.95], [1.6, -11.6], [2.6, -10.2], [1.8, -10.4], [.4, -10.2], [-.8, -9.6], [-1.5, -8.4]]), { wash: hair, washOp: 255, fill: hairDk, fillOp: 60, tex: .6, ink: PAL.ink, sw: sw * .9, curv: .45 });
  else if (style === 'old') {   // receding grey: tufts over the ears and a few strands on top
    for (const s of [-1, 1]) paint(ellPts(s * 2.55 * u, HC - .6 * u, .75 * u, 1.2 * u, 12), { wash: hair, washOp: 255, ink: PAL.ink, sw: sw * .7 });
    inkLine(H([[-.9, -11.6], [0, -12.1], [.9, -11.6]]), sw * .8, hairDk, 'ink', .5);
  } else if (style === 'curly') {
    for (let i = 0; i < 9; i++) { const a = Math.PI * (1.02 + i / 8 * .96); paint(ellPts(fcx * .25 + Math.cos(a) * 2.75 * u, HC - .3 * u + Math.sin(a) * 2.75 * u, .95 * u, .9 * u, 12), { wash: hair, washOp: 255, ink: PAL.ink, sw: sw * .6 }); }
  } else {
    const dx = fcx * .25 / u, bang = style === 'long' || style === 'bun';
    const P = bang
      ? [[-3.05, -8.3], [-3.0, -10.4], [-1.5, -11.8], [.6, -12.0], [2.4, -11.3], [3.05, -9.8], [3.05, -8.3], [2.4, -9.6], [1.2, -10.2], [-.2, -9.7], [-1.4, -10.2], [-2.5, -9.4]]
      : [[-3.0, -8.6], [-3.0, -10.6], [-1.6, -11.9], [.8, -12.05], [2.6, -11.2], [3.05, -9.3], [2.6, -9.7], [2.0, -10.0], [1.2, -9.6], [.4, -10.15], [-.5, -9.7], [-1.4, -10.1], [-2.3, -9.5]];
    paint(P.map(([a, b]) => [(a * fw + dx) * u, b * u]), { wash: hair, washOp: 255, fill: hairDk, fillOp: 60, tex: .6, ink: PAL.ink, sw, curv: .4 });
    if (style === 'bun') paint(ellPts(dx * u, -12.4 * u, 1.2 * u, 1 * u, 14), { wash: hair, washOp: 255, ink: PAL.ink, sw: sw * .8 });
  }

  // ----- face: clawd's eyes / mouth / blush, mapped into the head -----
  if (!backish) {
    const FS = .48, sides = side ? [1] : [-1, 1];
    push(); translate(fcx, HC + .55 * u); scale(FS * fw, FS); translate(0, 6 * u);
    if (o.blush) blush(u, sw / FS, { bx: 3.9, sides }, o.blush === true ? 1 : o.blush);
    rs('eyes'); eyes(u, o, sw / FS * .75, sides, clamp(o.smear || 0)); rs('mouth');
    let m = o.mouth; if (!m && (o.lid || 0) > .05) m = 'teeth';
    push(); translate((side ? 1.7 : 0) * u, .3 * u); mouth(u, m, sw / FS * .75); pop();
    if (o.draw) o.draw(u, sw / FS * .7);   // face props (glasses) use clawd's face coordinates
    pop();
    if (!m) inkLine([[fcx - .35 * u * fw, HC + 1.5 * u], [fcx + .35 * u * fw, HC + 1.55 * u]], sw * .45, mixCol(skinDk, PAL.ink, .3), 'inkfine', .5);   // a resting mouth
    paint(ellPts(fcx + (side ? .55 * u : 0), HC + .95 * u, .22 * u, .16 * u, 8), { wash: skinDk, washOp: 160, ink: null });   // nose
  }

  // ----- hat, mapped from clawd's head-top -----
  rs('hat');
  if (o.hat && o.hat !== 'cat') { push(); translate(fcx * .25, -11.75 * u - (C.style === 'curly' ? .5 * u : 0)); scale(.64 * (side ? .8 : 1), .64); translate(0, 8 * u); hat(u, o.hat, sw / .64); pop(); }

  // arms in front
  if (side) arm('L', .35 * u, 1, false);
  else if (view === 'q') arm('L', -SX + .5 * u, -1, false);
  else { arm('L', -SX, -1, false); arm('R', SX, 1, false); }
  pop();

  rs('emote');
  if (o.emote) {
    const topE = EMOTE_TOP.includes(o.emote), dir = o.flip ? -1 : 1;
    const ex = topE ? x : x + dir * 3.5 * u, ey = y + dy + (topE ? -13.6 : -11.6) * u * (1 - sq);
    emote(o.emote, ex, ey, u * .85, o.emoteK ?? 1, o.emoteAge ?? T);
  }
  rs('after');
}

// model sheet: node render.mjs --loop=cast --sheet=0.5 --w=1920 --cols=1 --out=out/check/cast.jpg
LOOPS.cast = t => {
  paint(rectPts(-100, -100, W + 200, H + 200), { wash: '#F2E6D3', ink: null });
  inkLine([[0, 470], [W, 470]], 1, PAL.ink, 'ink', 0); inkLine([[0, 1010], [W, 1010]], 1, PAL.ink, 'ink', 0);
  const row1 = [['A', 'happy', {}], ['B', 'love', { hat: 'bow' }], ['C', 'surprised', { hat: 'beanie' }], ['D', 'angry', {}], ['A', 'sad', {}], ['B', 'cry', { hat: 'bow' }], ['G7', 'excited', { hat: 'party' }]];
  row1.forEach(([k, e, ov], i) => human(150 + i * 270, 470, 30, { ...feel(e, t), ...ov, boilKey: k + i }));
  const row2 = [['A', 'neutral', { view: 'side', walk: t * 1.5 }], ['B', 'happy', { view: 'side', flip: true, walk: t * 1.5, hat: 'bow' }], ['A', 'angry', { view: 'qback', flip: true }],
    ['A', 'happy', { old: true, sit: true }], ['B', 'relieved', { old: true, sit: true, hat: 'bow' }], ['B', 'determined', { hat: 'fedora', ...hold('mag', 'L', .9, 1.7) }], ['A', 'happy', hold('phone')]];
  row2.forEach(([k, e, ov], i) => human(150 + i * 270, 1010, 30, { ...feel(e, t), ...ov, boilKey: k, cast: k }));
};
LOOPS.cast.len = 2;
