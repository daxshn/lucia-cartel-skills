"""Word-synced 'premium' captions as an ASS file: 2-4 word chunks at the bottom, the spoken word turns yellow and
pops slightly, everything in a heavy rounded font with a thick dark outline and a soft shadow.
    python scripts/make_captions.py out/vo/words.json out/captions.ass
"""
import json, sys

src, dst = sys.argv[1], sys.argv[2]
VERT = '--vertical' in sys.argv
segs = json.load(open(src, encoding='utf-8'))
words = [(w[0], w[1], w[2].strip()) for s in segs for w in s['w'] if w[2].strip()]

MAX_WORDS, MAX_CHARS, GAP = (3, 16, .35) if VERT else (4, 22, .35)
chunks, cur = [], []
for i, w in enumerate(words):
    cur.append(w)
    nxt = words[i + 1] if i + 1 < len(words) else None
    text = ' '.join(x[2] for x in cur)
    end_punct = w[2][-1] in '.!?;:' or (w[2][-1] == ',' and len(cur) >= 2)
    if (not nxt or len(cur) >= MAX_WORDS or len(text) >= MAX_CHARS - 4 or end_punct or nxt[0] - w[1] > GAP
            or len(text + ' ' + nxt[2]) > MAX_CHARS):
        chunks.append(cur); cur = []

def ts(t):
    t = max(0, t); h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
    return f'{h}:{m:02d}:{s:05.2f}'

YEL, WHITE = '&H004AD9FF&', '&H00FFFFFF&'   # ASS colours are &HBBGGRR
head = """[Script Info]
ScriptType: v4.00+
PlayResX: {PX}
PlayResY: {PY}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,Segoe UI Black,{FS},&H00FFFFFF,&H00FFFFFF,&H00332429,&H96000000,-1,0,0,0,100,100,1,0,1,{OL},5,2,60,60,{MV},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
head = head.replace('{PX}', '1080' if VERT else '1920').replace('{PY}', '1920' if VERT else '1080').replace('{FS}', '104' if VERT else '92').replace('{OL}', '9' if VERT else '8').replace('{MV}', '430' if VERT else '64')
out = [head]
for ci, ch in enumerate(chunks):
    c_end = ch[-1][1] + .25
    if ci + 1 < len(chunks): c_end = min(c_end, chunks[ci + 1][0][0])
    for wi, (a, b, _) in enumerate(ch):
        start = ch[0][0] if wi == 0 else a
        end = ch[wi + 1][0] if wi + 1 < len(ch) else c_end
        if end <= start: continue
        parts = []
        for wj, (_, _, txt) in enumerate(ch):
            if wj == wi: parts.append(r'{\c' + YEL + r'\fscx112\fscy112}' + txt + r'{\c' + WHITE + r'\fscx100\fscy100}')
            else: parts.append(txt)
        pop = r'{\fscx82\fscy82\t(0,90,\fscx100\fscy100)}' if wi == 0 else ''
        out.append(f'Dialogue: 0,{ts(start)},{ts(end)},Cap,,0,0,0,,{pop}' + ' '.join(parts) + '\n')
open(dst, 'w', encoding='utf-8').write(''.join(out))
print(f'{len(words)} words, {len(chunks)} chunks -> {dst}')
