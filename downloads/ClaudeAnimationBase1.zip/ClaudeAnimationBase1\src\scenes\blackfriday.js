// blackfriday.js: "Every Type of Person on Black Friday" (vertical, 2:22), cut to out/bf/voiceover.wav.
// Beats are pinned to spoken phrases with at('phrase'), looked up in BFW (Whisper word timings).
(() => {
  const norm = s => s.toLowerCase().replace(/[^a-z0-9]/g, '');
  const TW = BFW.map(([s, e, w]) => [s, e, norm(w)]);
  let FROM = 0; const CACHE = new Map();
  const find = (phrase, after) => {
    const P = phrase.split(/\s+/).map(norm).filter(Boolean);
    for (let i = 0; i < TW.length; i++) {
      if (TW[i][0] < after - .01) continue;
      let ok = true; for (let j = 0; j < P.length; j++) if (!TW[i + j] || TW[i + j][2] !== P[j]) { ok = false; break; }
      if (ok) return TW[i][0];
    }
    console.warn('at(): no match for "' + phrase + '" after ' + after.toFixed(1)); return after;
  };
  const at = (phrase, after = FROM) => { const k = phrase + '|' + after; if (!CACHE.has(k)) CACHE.set(k, find(phrase, after)); return CACHE.get(k); };
  const SEC = [], DUR_BF = PROJECT.duration;
  const sec = (t0, spec) => {
    FROM = t0 - .5; const S = spec(); S.t0 = t0; S.titleY = S.titleY || 330;
    const wrap = f => f && ((...a) => { const p = FROM; FROM = t0 - .5; try { return f(...a); } finally { FROM = p; } });
    for (const k of ['bg', 'over', 'under', 'shake', 'screen']) S[k] = wrap(S[k]);
    for (const c of Object.values(S.ch)) if (c.pose) c.pose = wrap(c.pose);
    SEC.push(S);
  };
  const K = (...keys) => keys.sort((a, b) => a[0] - b[0]);
  const L = (name, extra = {}) => ({ look: name, ...extra });
  const shakeAt = (...ts) => t => ts.reduce((m, a) => Math.max(m, t > a && t < a + 1.2 ? 12 * Math.exp(-(t - a) * 3.5) : 0), 0);

  // ---------- intro ----------
  sec(0, () => ({
    bg: t => bfFront(t),
    shake: t => shakeAt(at('gladiators'))(t),
    ch: {
      C: { x: 700, o: L('wrestA'), k: K([0, 'excited'], [at('gladiators'), 'furious'], [at('every type'), 'happy'], [at("let's go"), 'excited']) },
      B: { x: 960, o: L('mom'), k: K([0, 'determined'], [at('gladiators'), 'furious'], [at('every type'), 'happy'], [at("let's go"), 'excited']) },
      A: { x: 1220, o: L('looker'), k: K([0, 'happy'], [at('gladiators'), 'angry'], [at('air fryer'), 'starstruck'], [at('every type'), 'happy'], [at("let's go"), 'excited']) },
    },
    bub: [[at('air fryer'), at('every type'), 'B', 'airfryer'], [at('every type'), at("let's go"), 'A', 'tag']],
    cam: [[0, 'W'], [at('gladiators'), 'T'], [at('every type'), 'W']],
  }));

  // ---------- 1. the camper ----------
  sec(12.28, () => ({ tt: at('number one') + .3, n: 1, title: 'The Camper',
    bg: t => { bfFront(t, { open: t > at('doors finally') }); if (t < at('doors finally')) tent(760, .9); },
    ch: {
      A: { x: [[at('sprints'), 1120], [at('sprints') + .7, 900]], o: L('camper', { hat: 'beanie' }),
        k: K([0, 'sleepy'], [at('since tuesday'), 'neutral'], [at('thermos'), 'happy', hold('thermos')], [at('first in line'), 'proud', hold('thermos')], [at('doors finally'), 'surprised'], [at('sprints'), 'excited'], [at('sold out'), 'cry']) },
    },
    bub: [[at('since tuesday'), at('tent'), 'A', 'clock'], [at('first in line'), at('doors finally'), 'A', 'star'], [at('the tv he'), at('sold out'), 'A', 'tvbox'], [at('sold out'), at('sold out') + 2.4, 'A', 'phoneSold']],
    cam: [[0, 'W'], [at('thermos'), 'A'], [at('doors finally'), 'W'], [at('sold out'), 'A']],
  }));

  // ---------- 2. the wrestler ----------
  sec(30.3, () => ({ tt: at('number two') + .3, n: 2, title: 'The Wrestler',
    bg: t => { bfStore(t); bfTVs(t); },
    shake: t => shakeAt(at('nobody lets go'), at('cage match'))(t),
    ch: {
      A: { x: [[at('grab it'), 720], [at('grab it') + .5, 830]], o: L('wrestA'), k: K([0, 'neutral'], [at('one tv left'), 'surprised'], [at('grab it'), 'determined', { aR: .6 }], [at('nobody lets go'), 'furious', { aR: .6 }], [at('store manager'), 'angry', { aR: .6 }]) },
      B: { x: [[at('grab it'), 1200], [at('grab it') + .5, 1090]], o: L('wrestB', { flip: true }), k: K([0, 'neutral'], [at('one tv left'), 'surprised'], [at('grab it'), 'determined', { aR: .6 }], [at('nobody lets go'), 'furious', { aR: .6 }], [at('store manager'), 'angry', { aR: .6 }]) },
      C: { x: [[at('store manager') - .2, 1700], [at('store manager') + .9, 1290]], u: UU * .8, y: GY - 30, o: L('employee'), k: K([0, 'laugh', hold('phone')]) },
    },
    bub: [[at('one tv left'), at('two people'), 'A', 'tvbox'], [at('nobody lets go'), at("this isn't"), 'B', 'anger'], [at('cage match'), at('and somewhere'), 'A', 'anger']],
    cam: [[0, 'W'], [at('one tv left'), [960, 720, 1.9]], [at('two people'), 'W'], [at('nobody lets go'), 'T'], [at('store manager'), 'W']],
  }));

  // ---------- 3. just looking ----------
  sec(44.42, () => {
    const later = at('40 minutes');
    return { tt: at('number three') + .3, n: 3, title: 'Just Looking',
      bg: t => bfStore(t),
      over: t => {
        if (t < later) return;
        const items = ['giftbag', 'box'];
        if (t > at('third air fryer')) items.push('airfryer');
        if (t > at('massage chair')) items.push('box', 'tvbox');
        cart(720, items, 1.05, true);
        cart(1210, t > at('massage chair') ? ['airfryer', 'airfryer', 'giftbag'] : ['giftbag'], 1.05);
        if (t > at('teddy bear')) { const k = backOut(seg(t, at('teddy bear'), at('teddy bear') + .4)); boilSeed('bigteddy'); push(); translate(1210, GY - 230); scale(k); icon('teddy', 0, -120, 150); pop(); }
      },
      ch: {
        B: { x: 960, o: L('looker'), k: K([0, 'happy'], [at('for nothing'), 'shy'], [at('just looking'), 'happy', { lookX: 0 }], [later, 'excited'], [at('third air fryer'), 'starstruck'], [at('teddy bear'), 'love'], [at('just looking', at('teddy bear')), 'smug', { lookX: 0 }]) },
      },
      bub: [[at('for nothing'), at('just looking'), 'B', ['tag', 'cross']], [at('third air fryer'), at('massage chair'), 'B', 'airfryer']],
      cam: [[0, 'W'], [at('for nothing'), 'B'], [later, 'W'], [at('just looking', at('teddy bear')), 'B']] };
  });

  // ---------- 4. the online shopper ----------
  sec(59.31, () => ({ tt: at('number four') + .3, n: 4, title: 'The Online Shopper',
    bg: t => bfBedroom(t),
    ch: {
      B: { x: 960, o: L('online'), k: K([0, 'sleepy', hold('laptop', 'R', .45, 1.5)], [at('pajamas'), 'neutral', hold('laptop', 'R', .45, 1.5)], [at('47 tabs'), 'determined', hold('laptop', 'R', .45, 1.5)], [at('add to cart'), 'excited', hold('laptop', 'R', .45, 1.5)], [at('enter your card'), 'hopeful', hold('laptop', 'R', .45, 1.5)], [at('sold out'), 'cry'], [at('every single year'), 'sad']) },
    },
    bub: [[at('never leaves'), at('pajamas'), 'B', ['house', 'cross']], [at('47 tabs'), at('refreshing'), 'B', 'laptop'], [at('refreshing'), at('add to cart'), 'B', 'moon'], [at('add to cart'), at('enter your card'), 'B', 'check'], [at('enter your card'), at('sold out'), 'B', 'money'], [at('sold out'), at('number five'), 'B', 'phoneSold']],
    cam: [[0, 'W'], [at('47 tabs'), 'B'], [at('add to cart'), 'T'], [at('sold out'), 'B']],
  }));

  // ---------- 5. the deal calculator ----------
  sec(74.02, () => ({ tt: at('number five') + .3, n: 5, title: 'The Deal Calculator',
    bg: t => bfStore(t),
    ch: {
      B: { x: 960, o: L('calc'), k: K([0, 'thinking', hold('calc')], [at('60'), 'confused', hold('calc')], [at('done the math'), 'smug', hold('calc')], [at('twice'), 'proud', hold('calc')], [at('saved'), 'proud', hold('calc')], [at('spent'), 'surprised'], [at('on gas'), 'sad']) },
    },
    bub: [[at('60'), at('40'), 'B', 'tag'], [at('40'), at('the price'), 'B', ['tag', 'tag']], [at('the price'), at("they've done"), 'B', 'chart'], [at('saved'), at('spent'), 'B', 'money'], [at('spent'), at('number six'), 'B', 'gas']],
    cam: [[0, 'W'], [at('60'), 'B'], [at('done the math'), 'T'], [at('spent'), 'B']],
  }));

  // ---------- 6. the master-plan mom ----------
  sec(89.01, () => {
    const elec = at('electronics'), toys = at('toys go');
    return { tt: at('number six') + .3, n: 6, title: 'The Master Plan Mom',
      bg: t => bfStore(t),
      ch: {
        C: { x: [[elec, 720], [elec + 1.1, -300]], u: UU * .72, o: L('kid'), k: K([0, 'excited', hold('walkie', 'L')], [elec, 'determined']) },
        B: { x: 960, o: L('mom'), k: K([0, 'determined', hold('map')], [at('color'), 'determined', hold('list')], [at('walkie'), 'determined', hold('walkie')], [at('military'), 'cool', hold('walkie')], [elec, 'furious', hold('walkie')], [at('nobody gets left'), 'proud']) },
        D: { x: [[toys, 1200], [toys + 1.1, 2200]], u: UU * .72, o: L('vegan'), k: K([0, 'excited', hold('walkie')], [toys, 'determined']) },
      },
      bub: [[at('map of the store'), at('color'), 'B', 'map'], [at('color'), at('walkie'), 'B', 'list'], [at('military'), elec, 'B', 'star'], [elec, toys, 'C', 'tvbox'], [toys, at('nobody gets left'), 'D', 'teddy']],
      cam: [[0, 'W'], [at('map of the store'), 'B'], [at('walkie'), 'W'], [at('military'), 'B'], [elec, 'W']] };
  });

  // ---------- 7. the employee ----------
  sec(105.03, () => ({ tt: at('number seven') + .3, n: 7, title: 'The Employee',
    bg: t => bfCheckout(t),
    ch: {
      B: { x: 960, o: L('employee'), k: K([0, 'sleepy'], [at('seen things'), 'scared', { gloom: .6 }], [at('terrible things'), 'scared', { gloom: 1 }], [at('do you have'), 'bored'], [at('the answer is no'), 'angry'], [at('there is no back'), 'neutral', { eyes: 'blank' }]) },
      A: { x: [[at('do you have') - .2, 1700], [at('do you have') + .8, 1260]], u: UU * .9, o: L('wrestB', { flip: true }), k: K([0, 'hopeful'], [at('the answer is no'), 'sad']) },
    },
    bub: [[at('4 a'), at('seen things'), 'B', 'clock'], [at('do you have'), at('the answer is no'), 'A', ['box', '?']], [at('the answer is no'), at('there is no back'), 'B', 'cross']],
    cam: [[0, 'W'], [at('seen things'), 'B'], [at('do you have'), 'W'], [at('there is no back'), 'B']],
  }));

  // ---------- 8. the gifter ----------
  sec(117.99, () => ({ tt: at('number eight') + .3, n: 8, title: 'The Gift Buyer',
    bg: t => bfStore(t), over: t => cart(1220, ['giftbag', 'giftbag', 'teddy', 'giftbag', 'airfryer'], 1.05),
    ch: {
      B: { x: 920, o: L('gifter'), k: K([0, 'happy', hold('giftbag')], [at('for my mom'), 'love', hold('giftbag')], [at('for my sister'), 'happy', hold('giftbag')], [at('again'), 'shy', hold('giftbag')], [at('is for me'), 'mischief', hold('giftbag')], [at('actually'), 'laugh']) },
    },
    bub: [[at('for my mom'), at('for my sister'), 'B', 'heart'], [at('for my sister'), at('for my mom', at('for my sister')), 'B', 'heart'], [at('again'), at('is for me'), 'B', ['heart', '?']], [at('is for me'), at('actually'), 'B', 'star'], [at('actually'), at('so which'), 'B', ['giftbag', 'giftbag']]],
    cam: [[0, 'W'], [at('for my mom'), 'B'], [at('is for me'), 'T'], [at('actually'), 'W']],
  }));

  // ---------- outro ----------
  sec(131.68, () => {
    const fam = (x, name, extra = {}) => ({ x, y: GY - 60, u: UU * .78, o: L(name, extra), k: K([0, 'happy']), pose: t => move('bounce', t + x * .001, x % 5) });
    return {
      bg: t => bfFront(t, { open: true }),
      ch: {
        F1: fam(660, 'wrestA'), F2: fam(1260, 'gifter'), F3: fam(800, 'employee'), F4: fam(1120, 'calc'),
        A: { x: 870, o: L('camper', { hat: 'beanie' }), k: K([0, 'happy'], [at('the camper'), 'surprised'], [at('online now'), 'cry'], [at('like and subscribe'), 'happy']) },
        B: { x: 1060, o: L('mom'), pose: t => t > at('good luck') ? { aR: 1.2 + .5 * Math.sin(t * 13) } : null, k: K([0, 'happy'], [at('which one'), 'playful', { lookX: 0 }], [at('like and subscribe'), 'excited']) },
      },
      bub: [[at('which one'), at('tell us'), 'B', '?'], [at('online now'), at('like and'), 'A', 'laptop'], [at('like and subscribe'), DUR_BF, 'B', 'heart']],
      cam: [[0, 'W'], [at('the camper'), 'A'], [at('like and subscribe'), 'W']] };
  });

  const WIPES = [[BF.red, BF.yel], [BF.night, BF.red], [BF.yel, '#1E1A22']];
  SEC.forEach(prepSection);
  const last = SEC.length - 1;
  shots(SEC.map((S, i) => [S.t0, (t, lt, dur) => {
    const R = runSection(S, t);
    boilSeed('transition');
    if (i === 0 && lt < .5) iris(...R.eye, lerp(0, 2200, easeIn(lt / .5)));
    if (i > 0 && lt < .3) brushWipe(.5 + lt / .6, WIPES[i % WIPES.length]);
    if (i < last && lt > dur - .3) brushWipe((lt - (dur - .3)) / .6, WIPES[(i + 1) % WIPES.length]);
    if (i === last && t > DUR_BF - 1.4) iris(W / 2, H * .5, t < DUR_BF - .9 ? lerp(2200, 420, ease(seg(t, DUR_BF - 1.4, DUR_BF - .9))) : t < DUR_BF - .4 ? 420 : lerp(420, 0, easeIn(seg(t, DUR_BF - .4, DUR_BF - .05))));
  }]));
})();
