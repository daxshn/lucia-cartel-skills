// config_bf.js: the Black Friday short (vertical). Loaded by studio_bf.html instead of src/config.js.
const PROJECT = { duration: 141.8, bpm: 120, offset: 0, size: [1080, 1920] };
