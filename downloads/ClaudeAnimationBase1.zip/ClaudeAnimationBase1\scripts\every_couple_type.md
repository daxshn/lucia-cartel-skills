# Har Type Ka Couple — voiceover script (~10 min)

Sirf **VO** wali lines bolni hain. *[Scene]* wali lines video ke liye hain, bolni nahi hain.
Cast: **Clawd** (plain) aur **Clawdi** (sar pe bow). Har type ke beech 1 second ka pause rakhna.

---

## 0. Intro (~35 s)

*[Scene: park ki bench. Clawd aur Clawdi baithe hain, peeche se alag-alag couples guzar rahe hain.]*

**VO:**
Duniya mein do tarah ke log hote hain. Ek jo single hain... aur doosre jo single logon ko jalane ke liye paida hue hain.

Lekin ruko. Saare couples ek jaise nahi hote. Kuch itna ladte hain ki padosi popcorn le aate hain. Kuch itna pyaar karte hain ki dekhne wale ko sugar ho jaaye.

Toh aaj hum dekhenge har type ka couple. Aur sach batana — aap inme se kaun se ho? Aur agar single ho... toh bhi dekh lo, kam se kam pata toh chale ki kis cheez se bache hue ho.

Chalo shuru karte hain.

---

## 1. Tom and Jerry Couple (~50 s)

*[Scene: dono ek doosre pe chilla rahe hain, gusse wale emote. Phir ek second mein gale lag jaate hain.]*

**VO:**
Number ek. Tom and Jerry couple.

Inki subah "good morning" se nahi, "tune kal reply kyun nahi kiya" se hoti hai. Ye log har cheez pe ladte hain. Khana kya khayenge — ladai. Kaun si movie dekhenge — ladai. AC ka temperature — world war.

Aur sabse mazedaar baat? Paanch minute pehle jo bol rahe the "mujhse baat mat karna"... wahi paanch minute baad pooch rahe hain, "khana khaya?"

Inke dost ab beech mein padte hi nahi. Kyunki jab tak dost samjhaane aata hai, tab tak ye dono ek hi plate mein momos kha rahe hote hain. Aur dost? Dost villain ban chuka hota hai.

Ladai inki love language hai. Jis din ye ladna band kar dein... us din samajh lo kuch gadbad hai.

---

## 2. Long Distance Couple (~50 s)

*[Scene: screen do hisson mein. Ek taraf din, ek taraf raat. Dono phone pakde so gaye hain.]*

**VO:**
Number do. Long distance couple.

Inka rishta teen cheezon pe chalta hai. Wi-Fi, charger, aur umeed.

Ye log video call pe saath khana khate hain, saath movie dekhte hain, aur saath so bhi jaate hain. Phone pe. Subah uthte hain toh call ab bhi chal rahi hoti hai, aur phone ki battery teen percent.

Inki sabse badi dushman koi ladki ya ladka nahi hai. Inka sabse bada dushman hai... "network issue". Aadhi ladaiyan toh sirf isliye hoti hain ki "hello? hello? awaaz aa rahi hai?" mein hi bees minute nikal jaate hain.

Lekin jis din ye milte hain na... us din airport pe aisa scene hota hai ki security wale bhi emotional ho jaate hain.

Saal mein do baar milna, aur teen sau tirsath din intezaar. Isko kehte hain patience.

---

## 3. Babu Shona Couple (~50 s)

*[Scene: dono ek doosre ko khila rahe hain, charon taraf dil. Peeche khada dost disgusted face bana raha hai.]*

**VO:**
Number teen. Babu shona couple.

Savdhaan. Inke paas zyada der khade rehne se diabetes ho sakta hai.

"Mera babu ne thana thaya?" Bhai, tera babu chhabbis saal ka hai, uska pet nikla hua hai, usne thana nahi, poori thali khayi hai.

Ye log ek doosre ko naam se nahi bulate. Babu, shona, jaanu, baby, cutie, pookie. Asli naam toh shayad inhe khud yaad nahi.

Restaurant mein ye aamne-saamne nahi baithte. Ek hi side baithte hain. Chipak ke. Aur saamne wali kursi pe baithta hai inka bechara dost, jo soch raha hota hai, "main yahan kyun aaya?"

Aur phone rakhne mein inhe ek ghanta lagta hai. "Pehle tum rakho." "Nahi pehle tum." "Nahi tum." Bhai koi toh rakho, recharge khatam ho jayega.

---

## 4. Foodie Couple (~45 s)

*[Scene: table pe khane ka pahaad. Dono ki aankhon mein chamak. Ek doosre ki plate se chura rahe hain.]*

**VO:**
Number chaar. Foodie couple.

Inki date ka matlab hai khana. Inki anniversary ka matlab hai khana. Inki ladai ka hal bhi hai... khana.

Ye log candle light dinner nahi karte. Ye log buffet karte hain. Aur aisa karte hain ki restaurant ka maalik door se haath jod leta hai.

Inka sabse romantic sawaal "kya tum mujhse pyaar karte ho" nahi hai. Inka sabse romantic sawaal hai, "aaj kya khayein?"

Aur sachcha pyaar ki pehchaan? Jab aakhri momo bacha ho... aur wo bole, "tu kha le."

Bas. Isse bada tyaag duniya mein koi nahi hai.

Haan, ek problem hai. Relationship ke saath-saath inka wazan bhi serious ho jaata hai.

---

## 5. Gym Couple (~45 s)

*[Scene: dono sweatband pehne, ek doosre ko utha ke squat kar rahe hain. Sheeshe ke saamne selfie.]*

**VO:**
Number paanch. Gym couple.

Foodie couple ke bilkul ulte. Ye log saath mein rote nahi, saath mein protein peete hain.

Inki date hoti hai subah paanch baje. Gym mein. Jahan ek doosre ko dekh ke nahi, ek doosre ki form dekh ke impress hote hain. "Babe, teri deadlift kya kamaal hai."

Ye gift mein phool nahi dete. Ye dete hain whey protein ka dabba. Aur sach kahun toh wo phoolon se mehenga bhi padta hai.

Inki har photo sheeshe ke saamne hoti hai. Aur caption hamesha ek hi: "couple that trains together, stays together."

Bas ek din inse galti se pooch lo "cheat day kab hai?"... phir dekho, pandrah minute ka diet lecture free mein milega.

---

## 6. Jasoos Couple (~50 s)

*[Scene: Clawdi fedora aur chashma pehne Clawd ke phone mein jhaank rahi hai. Clawd ke sar pe paseena.]*

**VO:**
Number chhe. Jasoos couple.

Inme se ek ko CBI mein hona chahiye tha. Galti se relationship mein aa gaya.

"Ye kiski photo like ki?" "Ye Priya kaun hai?" "Online tha toh reply kyun nahi kiya?" "Last seen do baje ka kyun hai?"

Bhai, saamne wala sirf paani peene utha tha.

Inke saath rehne wale ko phone ka password nahi, apni poori zindagi ka hisaab dena padta hai. Location on, screenshot ready, aur har dost ka background check ho chuka hai.

Aur inki yaadasht! Teen saal pehle ki ek comment, tareekh aur time ke saath yaad hai. Lekin doodh lana... wo bhool jaate hain.

Thoda sa jealous hona cute hota hai. Lekin jab partner ko apna hi phone chhupa ke chalana pade... toh samajh lo jasoosi zyada ho gayi hai.

---

## 7. Breakup-Patchup Couple (~50 s)

*[Scene: dono ulte mud ke chale jaate hain. Phir waapas aa ke gale. Phir se chale jaate hain. Dost calendar pe nishaan laga raha hai.]*

**VO:**
Number saat. Breakup patchup couple.

Inka relationship status bijli ki tarah hai. Kabhi hai, kabhi nahi hai.

Somvaar ko breakup. Budhvaar ko "I miss you". Shukravaar ko patchup. Aur ravivaar ko phir se "humein break chahiye."

Inke doston ki haalat sabse kharaab hai. Kyunki breakup ke time dost ne bol diya, "accha hua, wo tere layak hi nahi tha." Aur do din baad wahi dono haath pakad ke saamne khade hain. Ab dost kahan muh chhupaye?

Ye log ek doosre ko block karte hain, unblock karte hain, phir block karte hain. Instagram bhi confuse ho jaata hai.

Sau baar bola "ab kabhi baat nahi karunga." Aur ek sau ek-vi baar... phir call utha liya.

Sach ye hai ki ye ek doosre ke saath nahi reh sakte. Aur ek doosre ke bina toh bilkul nahi.

---

## 8. "Hum Bas Dost Hain" Couple (~45 s)

*[Scene: dono saath hans rahe hain. Peeche saare dost suspicious nazron se dekh rahe hain.]*

**VO:**
Number aath. "Hum bas dost hain" couple.

Ye couple hai. Sabko pata hai ye couple hai. Bas in dono ko nahi pata.

Roz raat teen baje tak baat karte hain. Ek doosre ke bina khana nahi khate. Ek ko bukhaar aaye toh doosra dawai le ke pahunch jaata hai. Aur poochho toh — "arre nahi yaar, hum bas acche dost hain."

Haan bhai. Aur main bas accha insaan hoon.

Poora college, poora office, dono ke mummy-papa, yahan tak ki chai wale bhaiya ko bhi pata hai. Sab bas intezaar kar rahe hain ki ye do bewakoof kab samjhenge.

Aur jis din ye finally bolte hain, "guys, hum date kar rahe hain"... us din koi shock nahi hota. Sab ek saath bolte hain:

"Finally!"

---

## 9. Instagram Couple (~50 s)

*[Scene: camera ke saamne dono muskura ke pose de rahe hain. Camera hat-te hi dono bored, apne-apne phone mein.]*

**VO:**
Number nau. Instagram couple.

Inka pyaar bahut gehra hai. Kam se kam... camera on hone tak.

Ye log khana khane nahi jaate. Ye log khane ki photo lene jaate hain. Khana thanda ho jaaye chalega, lekin angle sahi hona chahiye.

Ek photo ke liye saintaalis take. "Thoda aur hans." "Aise nahi, natural lag." Bhai saintaalis-ve take mein natural kaun lagta hai?

Aur caption: "my whole world." Jabki paanch minute pehle isi baat pe ladai hui thi ki photo mein main mota kyun lag raha hoon.

Inki anniversary post itni lambi hoti hai ki padhte-padhte agli anniversary aa jaaye.

Lekin ek baat maan-ni padegi. Inki feed dekh ke hum sabko lagta hai, "yaar, hum zindagi mein kya kar rahe hain?"

Yaad rakhna: online jo sabse perfect dikhta hai, zaroori nahi wo sabse khush bhi ho.

---

## 10. Ulta Couple (~50 s)

*[Scene: party. Clawd headphones lagaye kone mein, Clawdi party hat pehne beech mein naach rahi hai. Phir wo use kheench ke le aati hai.]*

**VO:**
Number das. Ulta couple. Ek introvert, ek extrovert.

Ek ko party mein jaana hai. Doosre ko party se ghar jaana hai. Aur dono ek hi party mein hain.

Extrovert wala paanch minute mein pachaas logon se mil chuka hai. Introvert wala paanch minute mein ek hi cheez dhoondh chuka hai: ghar ka paltu kutta. Aur ab wo usi ke saath kone mein baitha hai.

Ek bolta hai, "chalo bahar chalte hain!" Doosra bolta hai, "ghar pe bhi toh hum bahar hi hain... balcony mein."

Ek ka phone din mein sau baar bajta hai. Doosre ka phone silent pe hai — do hazaar unnees se.

Lekin yahi toh mazaa hai. Ek doosre ko duniya dikhata hai. Aur doosra use sikhata hai ki kabhi-kabhi chup baithna bhi sukoon hota hai.

Ulte hain. Isliye poore hain.

---

## 11. Aalsi Couple (~45 s)

*[Scene: dono sofe pe kambal mein lipte, sleepy face. Remote door pada hai, dono use ghoor rahe hain, koi nahi uthta.]*

**VO:**
Number gyarah. Aalsi couple.

Inka dream date: kahin nahi jaana.

Plan banta hai, "is weekend pakka ghoomne chalenge." Weekend aata hai. Dono ek doosre ko dekhte hain. Aur phir... "order kar lein?"

Ye log saath mein series dekhte hain. Matlab, series chalti hai, aur ye dono so jaate hain. Subah ladai hoti hai ki kaun se episode tak dekha tha.

Inke ghar mein sabse badi jung hai: light kaun band karega. Dono bistar mein, switch teen kadam door. Aur behes aadhe ghante ki.

Remote door pada ho toh ye channel nahi badalte. Ye jo chal raha hai, usi ko pasand karna seekh lete hain.

Mehenge gift nahi, lambi drive nahi. Bas ek kambal, do log, aur zero plan. Sach bolun? Ye wala kaafi accha lagta hai.

---

## 12. Purana Couple (~50 s)

*[Scene: shaam ki garam roshni. Do boodhe Clawd — ek chashme mein, ek ke sar pe phool — park ki usi bench pe. Chup-chaap, haath mein haath.]*

**VO:**
Aur aakhri. Number barah. Purana couple.

Ye wo hain jo pachaas saal se saath hain. Aur aaj bhi ladte hain. Lekin ab topic badal gaya hai. "Tumne dawai li?" "Chashma kahan rakh diya?" "TV ki awaaz kam karo."

Ye "I love you" nahi bolte. Ye bolte hain, "sweater pehen lo, thand hai." Aur wo bina maange chai bana deti hai, kyunki use pata hai paanch baj gaye hain.

Inhone Tom and Jerry wali ladaiyan bhi ki hain. Doori bhi dekhi hai. Rooth-na, manana, sab kuch.

Aur phir bhi... yahin hain. Ek hi bench pe.

Na photo, na caption, na dikhawa. Bas saath.

Shayad asli pyaar yahi hai. Jo shor nahi karta. Bas rehta hai.

---

## Outro (~30 s)

*[Scene: saare couples ek saath frame mein. Beech mein Clawd aur Clawdi haath hila rahe hain. Iris band.]*

**VO:**
Toh ye the har type ke couple.

Ab sach-sach comment mein batao: aap kaun se ho? Aur apne us dost ko zaroor bhejo jo bolta hai "hum bas dost hain." Use bhi pata chalna chahiye ki sabko pata hai.

Aur agar aap single ho, toh tension mat lo. Aap sabse khatarnak type ho. Aapka paisa bhi bachta hai, neend bhi poori hoti hai... aur phone mein charging bhi rehti hai.

Video acchi lagi ho toh like kar do, aur aise hi aur videos ke liye channel ko subscribe kar lo.

Milte hain agli video mein.
