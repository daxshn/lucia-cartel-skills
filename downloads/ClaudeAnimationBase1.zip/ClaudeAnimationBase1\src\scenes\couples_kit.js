// couples_kit.js: the stage for "Every Type of Couple": icons, thought bubbles, furniture, sets, and a section runner
// that plays a spec (characters with emotion timelines, bubbles, camera keys) against the voiceover's clock.
const GY = 900, UU = 30, TU = .87, LEAFC = '#3F6B3A';   // TU: the tall cast's size unit, as a share of UU
const pw = (pts, col, sw = .8, ink = PAL.ink) => paint(pts, { wash: col, ink, sw });
const el = (x, y, rx, ry, col, sw = .8, ink = PAL.ink) => paint(ellPts(x, y, rx, ry, 16), { wash: col, ink, sw });
const rc = (x, y, w, h, col, sw = .8, ink = PAL.ink) => paint(rectPts(x, y, w, h), { wash: col, ink, sw });

// ---------- icons: (x, y) centre, s = half size ----------
const ICON = {
  heart: (x, y, s) => pw(heartPts(x, y, s * .95), PAL.rose),
  broken: (x, y, s) => { pw(heartPts(x, y, s * .95), '#B9778A'); inkLine([[x + .1 * s, y - .55 * s], [x - .25 * s, y - .1 * s], [x + .2 * s, y + .2 * s], [x - .05 * s, y + .75 * s]], 1.6, PAL.cream, 'ink', 0); },
  phone: (x, y, s) => { pw(rrPts(x - .48 * s, y - .85 * s, .96 * s, 1.7 * s, .16 * s), '#4A4263'); paint(rectPts(x - .34 * s, y - .62 * s, .68 * s, 1.15 * s), { wash: '#9FD3E8', ink: null }); },
  pizza: (x, y, s) => { pw([[x - .85 * s, y - .6 * s], [x + .85 * s, y - .6 * s], [x, y + .95 * s]], '#F2C14E'); pw(rrPts(x - .95 * s, y - .85 * s, 1.9 * s, .32 * s, .12 * s), '#C98A4B'); el(x - .25 * s, y - .25 * s, .17 * s, .17 * s, '#D2493A', .4); el(x + .22 * s, y - .05 * s, .15 * s, .15 * s, '#D2493A', .4); el(x, y + .4 * s, .12 * s, .12 * s, '#D2493A', .4); },
  fries: (x, y, s) => { for (let i = 0; i < 5; i++) rc(x - .5 * s + i * .21 * s, y - .9 * s + (i % 2) * .15 * s, .16 * s, 1 * s, '#F2C14E', .5); pw([[x - .62 * s, y - .1 * s], [x + .62 * s, y - .1 * s], [x + .45 * s, y + .9 * s], [x - .45 * s, y + .9 * s]], '#D2493A'); },
  popcorn: (x, y, s) => { for (let i = 0; i < 5; i++) el(x - .5 * s + i * .25 * s, y - .45 * s - (i % 2) * .22 * s, .26 * s, .24 * s, PAL.cream, .5); pw([[x - .6 * s, y - .3 * s], [x + .6 * s, y - .3 * s], [x + .42 * s, y + .9 * s], [x - .42 * s, y + .9 * s]], PAL.cream); for (const d of [-.3, .1]) paint([[x + d * s, y - .28 * s], [x + (d + .2) * s, y - .28 * s], [x + (d * .8 + .16) * s, y + .88 * s], [x + d * .8 * s, y + .88 * s]], { wash: '#D2493A', ink: null }); },
  burger: (x, y, s) => { pw(rrPts(x - .85 * s, y + .3 * s, 1.7 * s, .42 * s, .18 * s), '#D99A4E'); rc(x - .9 * s, y + .02 * s, 1.8 * s, .3 * s, '#7A4A2E', .6); rc(x - .95 * s, y - .12 * s, 1.9 * s, .16 * s, '#7FB85A', .5); pw(ellPts(x, y - .1 * s, .88 * s, .72 * s, 14).filter(p => p[1] <= y - .08 * s), '#D99A4E'); },
  cake: (x, y, s) => { pw([[x - .6 * s, y], [x + .6 * s, y], [x + .42 * s, y + .85 * s], [x - .42 * s, y + .85 * s]], '#B77B4D'); el(x, y - .15 * s, .72 * s, .45 * s, PAL.rose); el(x, y - .68 * s, .17 * s, .17 * s, '#D2493A', .5); },
  tv: (x, y, s) => { pw(rrPts(x - s, y - .7 * s, 2 * s, 1.3 * s, .14 * s), '#4A4263'); paint(rectPts(x - .82 * s, y - .54 * s, 1.64 * s, .98 * s), { wash: '#9FD3E8', ink: null }); inkLine([[x - .4 * s, y + .62 * s], [x - .55 * s, y + .9 * s]], 1.2); inkLine([[x + .4 * s, y + .62 * s], [x + .55 * s, y + .9 * s]], 1.2); },
  cold: (x, y, s) => { for (let i = 0; i < 3; i++) { const a = i * Math.PI / 3; inkLine([[x - Math.cos(a) * s * .9, y - Math.sin(a) * s * .9], [x + Math.cos(a) * s * .9, y + Math.sin(a) * s * .9]], 1.8, '#4F9FD6', 'ink', 0); } },
  hot: (x, y, s) => { for (let i = 0; i < 8; i++) { const a = i * TAU / 8; inkLine([[x + Math.cos(a) * s * .65, y + Math.sin(a) * s * .65], [x + Math.cos(a) * s, y + Math.sin(a) * s]], 1.5, '#E0762E', 'ink', 0); } el(x, y, .5 * s, .5 * s, PAL.ochre); },
  wifi: (x, y, s) => { for (const r of [.45, .8, 1.15]) { const P = []; for (let i = 0; i <= 6; i++) { const a = -Math.PI * .75 + i / 6 * Math.PI * .5; P.push([x + Math.cos(a) * r * s, y + .6 * s + Math.sin(a) * r * s]); } inkLine(P, 1.8, PAL.teal, 'ink', .5); } el(x, y + .6 * s, .13 * s, .13 * s, PAL.teal, .4); },
  nowifi: (x, y, s) => { ICON.wifi(x, y, s); ICON.cross(x, y, s * .8); },
  battery: (x, y, s) => { pw(rrPts(x - .9 * s, y - .5 * s, 1.7 * s, s, .12 * s), PAL.cream, 1); rc(x + .8 * s, y - .2 * s, .16 * s, .4 * s, PAL.ink, .4); paint(rectPts(x - .76 * s, y - .36 * s, .3 * s, .72 * s), { wash: '#D2493A', ink: null }); },
  fullbat: (x, y, s) => { pw(rrPts(x - .9 * s, y - .5 * s, 1.7 * s, s, .12 * s), PAL.cream, 1); rc(x + .8 * s, y - .2 * s, .16 * s, .4 * s, PAL.ink, .4); paint(rectPts(x - .76 * s, y - .36 * s, 1.42 * s, .72 * s), { wash: '#6FB85A', ink: null }); },
  moon: (x, y, s) => { el(x, y, .8 * s, .8 * s, PAL.ochre); paint(ellPts(x + .38 * s, y - .2 * s, .68 * s, .68 * s, 16), { wash: PAL.cream, ink: null }); },
  plane: (x, y, s) => { pw([[x - s, y - .1 * s], [x + s, y - .6 * s], [x + .1 * s, y + .7 * s], [x - .1 * s, y + .15 * s]], '#9FD3E8'); inkLine([[x - .1 * s, y + .15 * s], [x + s, y - .6 * s]], .8); },
  clock: (x, y, s) => { el(x, y, .9 * s, .9 * s, PAL.paper, 1.2); inkLine([[x, y], [x, y - .55 * s]], 1.4, PAL.ink, 'ink', 0); inkLine([[x, y], [x + .4 * s, y + .15 * s]], 1.4, PAL.ink, 'ink', 0); },
  house: (x, y, s) => { rc(x - .65 * s, y - .1 * s, 1.3 * s, .95 * s, PAL.ochre); pw([[x - .95 * s, y - .08 * s], [x, y - .95 * s], [x + .95 * s, y - .08 * s]], PAL.clayDk); rc(x - .16 * s, y + .3 * s, .32 * s, .55 * s, '#7A4A2E', .5); },
  dumbbell: (x, y, s) => { inkLine([[x - .7 * s, y], [x + .7 * s, y]], 2.4, PAL.ink, 'ink', 0); for (const d of [-1, 1]) { rc(x + d * .7 * s - .16 * s, y - .5 * s, .32 * s, s, '#4A4263', .6); rc(x + d * .98 * s - .1 * s, y - .32 * s, .2 * s, .64 * s, '#4A4263', .5); } },
  shaker: (x, y, s) => { rc(x - .4 * s, y - .5 * s, .8 * s, 1.4 * s, PAL.teal); rc(x - .46 * s, y - .8 * s, .92 * s, .32 * s, '#4A4263', .6); rc(x - .14 * s, y - 1 * s, .28 * s, .22 * s, '#4A4263', .5); },
  tub: (x, y, s) => { pw(rrPts(x - .7 * s, y - .6 * s, 1.4 * s, 1.5 * s, .15 * s), PAL.violet); rc(x - .76 * s, y - .9 * s, 1.52 * s, .34 * s, '#4A4263', .6); paint(rectPts(x - .68 * s, y - .2 * s, 1.36 * s, .6 * s), { wash: PAL.cream, ink: null }); ICON.dumbbell(x, y + .1 * s, s * .36); },
  flower: (x, y, s) => { for (let i = 0; i < 6; i++) { const a = i / 6 * TAU; paint(ellPts(x + Math.cos(a) * s * .55, y + Math.sin(a) * s * .55, s * .45, s * .28, 10, 0, a), { wash: PAL.rose, ink: PAL.ink, sw: .5 }); } el(x, y, s * .3, s * .3, PAL.ochre, .5); },
  coin: (x, y, s) => { el(x, y, .85 * s, .85 * s, PAL.ochre, 1); paint(ellPts(x, y, .55 * s, .55 * s, 14), { ink: '#B07A1E', sw: .8 }); },
  camera: (x, y, s) => { rc(x - .5 * s, y - .85 * s, .5 * s, .3 * s, '#4A4263', .5); pw(rrPts(x - .95 * s, y - .6 * s, 1.9 * s, 1.3 * s, .14 * s), '#4A4263'); el(x, y + .05 * s, .45 * s, .45 * s, '#9FD3E8'); },
  mag: (x, y, s) => { inkLine([[x + .3 * s, y + .3 * s], [x + .95 * s, y + .95 * s]], 3, '#7A4A2E', 'ink', 0); paint(ellPts(x - .15 * s, y - .15 * s, .62 * s, .62 * s, 18), { wash: '#CFEAF2', ink: PAL.ink, sw: 1.6 }); },
  milk: (x, y, s) => { rc(x - .5 * s, y - .35 * s, s, 1.25 * s, PAL.cream); pw([[x - .5 * s, y - .35 * s], [x, y - .95 * s], [x + .5 * s, y - .35 * s]], PAL.cream); paint(rectPts(x - .48 * s, y + .1 * s, .96 * s, .4 * s), { wash: '#5AA7D9', ink: null }); },
  lock: (x, y, s) => { const P = []; for (let i = 0; i <= 8; i++) { const a = Math.PI + i / 8 * Math.PI; P.push([x + Math.cos(a) * .42 * s, y - .15 * s + Math.sin(a) * .55 * s]); } inkLine(P, 2.2, PAL.ink, 'ink', .5); pw(rrPts(x - .65 * s, y - .15 * s, 1.3 * s, 1.05 * s, .12 * s), PAL.ochre); el(x, y + .3 * s, .13 * s, .16 * s, PAL.ink, .3); },
  pin: (x, y, s) => { pw([[x - .5 * s, y - .25 * s], [x, y + .95 * s], [x + .5 * s, y - .25 * s]], '#D2493A'); el(x, y - .35 * s, .6 * s, .6 * s, '#D2493A'); paint(ellPts(x, y - .35 * s, .22 * s, .22 * s, 10), { wash: PAL.cream, ink: null }); },
  doc: (x, y, s) => { rc(x - .65 * s, y - .9 * s, 1.3 * s, 1.8 * s, PAL.paper); for (let i = 0; i < 4; i++) inkLine([[x - .42 * s, y - .5 * s + i * .36 * s], [x + (i % 2 ? .2 : .42) * s, y - .5 * s + i * .36 * s]], .8, '#7C7390', 'inkfine', 0); },
  soup: (x, y, s) => { for (const d of [-.3, .2]) inkLine([[x + d * s, y - .25 * s], [x + (d + .15) * s, y - .6 * s], [x + d * s, y - .95 * s]], .9, '#8E86A0', 'inkfine', .6); pw(ellPts(x, y, .95 * s, .8 * s, 16).filter(p => p[1] >= y - .02 * s), PAL.teal); el(x, y, .95 * s, .2 * s, '#F2C14E', .7); },
  cup: (x, y, s) => { for (const d of [-.25, .2]) inkLine([[x + d * s, y - .5 * s], [x + (d + .15) * s, y - .8 * s], [x + d * s, y - 1.1 * s]], .9, '#8E86A0', 'inkfine', .6); const P = []; for (let i = 0; i <= 6; i++) { const a = -Math.PI / 2 + i / 6 * Math.PI; P.push([x + .5 * s + Math.cos(a) * .36 * s, y + .2 * s + Math.sin(a) * .34 * s]); } inkLine(P, 1.6, PAL.ink, 'ink', .5); pw([[x - .6 * s, y - .35 * s], [x + .6 * s, y - .35 * s], [x + .45 * s, y + .8 * s], [x - .45 * s, y + .8 * s]], PAL.cream); },
  pill: (x, y, s) => { push(); translate(x, y); rotate(-.6); pw(rrPts(-.9 * s, -.38 * s, 1.8 * s, .76 * s, .36 * s), PAL.cream); paint(rrPts(-.9 * s, -.38 * s, .95 * s, .76 * s, .3 * s), { wash: PAL.rose, ink: null }); paint(rrPts(-.9 * s, -.38 * s, 1.8 * s, .76 * s, .36 * s), { ink: PAL.ink, sw: .8 }); pop(); },
  glasses: (x, y, s) => { for (const d of [-1, 1]) paint(ellPts(x + d * .52 * s, y, .42 * s, .36 * s, 14), { wash: '#CFEAF2', ink: PAL.ink, sw: 1.4 }); inkLine([[x - .1 * s, y], [x + .1 * s, y]], 1.4, PAL.ink, 'ink', 0); },
  remote: (x, y, s) => { pw(rrPts(x - .35 * s, y - .9 * s, .7 * s, 1.8 * s, .14 * s), '#4A4263'); el(x, y - .55 * s, .14 * s, .14 * s, '#D2493A', .3); for (let i = 0; i < 3; i++) el(x, y - .1 * s + i * .3 * s, .1 * s, .1 * s, PAL.cream, .3); },
  cross: (x, y, s) => { inkLine([[x - .7 * s, y - .7 * s], [x + .7 * s, y + .7 * s]], 3, '#D2493A', 'ink', 0); inkLine([[x + .7 * s, y - .7 * s], [x - .7 * s, y + .7 * s]], 3, '#D2493A', 'ink', 0); },
  check: (x, y, s) => inkLine([[x - .7 * s, y], [x - .2 * s, y + .55 * s], [x + .8 * s, y - .6 * s]], 3, '#4E9A45', 'ink', 0),
  star: (x, y, s) => pw(starPts(x, y, s, .5, 5), PAL.ochre),
  gift: (x, y, s) => { rc(x - .75 * s, y - .35 * s, 1.5 * s, 1.2 * s, PAL.rose); rc(x - .85 * s, y - .7 * s, 1.7 * s, .4 * s, PAL.rose); paint(rectPts(x - .13 * s, y - .7 * s, .26 * s, 1.55 * s), { wash: PAL.ochre, ink: null }); },
  globe: (x, y, s) => { el(x, y, .9 * s, .9 * s, '#8EC3E6', 1); paint(ellPts(x - .25 * s, y - .2 * s, .35 * s, .3 * s, 10, s * .04), { wash: '#6FB85A', ink: null }); paint(ellPts(x + .3 * s, y + .3 * s, .28 * s, .22 * s, 10, s * .04), { wash: '#6FB85A', ink: null }); },
  dog: (x, y, s) => { el(x - .55 * s, y - .35 * s, .22 * s, .45 * s, '#7A4A2E', .6); el(x + .55 * s, y - .35 * s, .22 * s, .45 * s, '#7A4A2E', .6); el(x, y, .7 * s, .65 * s, '#C98A4B'); el(x - .25 * s, y - .1 * s, .08 * s, .1 * s, PAL.ink, .2); el(x + .25 * s, y - .1 * s, .08 * s, .1 * s, PAL.ink, .2); el(x, y + .22 * s, .14 * s, .1 * s, PAL.ink, .2); },
  mute: (x, y, s) => { ICON.phone(x - .3 * s, y, s * .85); emote('zzz', x + .45 * s, y - .1 * s, s * .9, 1, T); },
};
for (const k of ['?', '!', 'zzz', 'anger', 'music', 'bulb', 'sweat', 'hearts']) ICON[k] = (x, y, s) => emote(k, x - s * .45, y + s * .55, s * .95, 1, T);
function icon(name, x, y, s) { if (Array.isArray(name)) { icon(name[0], x - s * .62, y, s * .62); icon(name[1], x + s * .62, y, s * .62); } else if (ICON[name]) ICON[name](x, y, s); }
// held in an arm: clawd(..., hold('phone')) — for the screen-right arm; hold('phone', 'L') for the other one
const hold = (name, arm = 'R', ang = .85, s = 1.35) => ({ ['a' + arm]: ang, ['arm' + arm]: (u) => icon(name, u * 1.05, 0, u * s) });

// thought bubble with an icon; k = 0..1 pop; dir = which way the tail points (toward the speaker)
function bubble(x, y, r, k, name, dir) {
  if (k < .03) return;
  push(); translate(x, y); scale(k);
  paint(ellPts(0, 0, r * 1.25, r, 26, 1.5), { wash: PAL.cream, ink: PAL.ink, sw: 1.1 });
  el(dir * r * .95, r * 1.02, r * .17, r * .15, PAL.cream, .8); el(dir * r * 1.3, r * 1.38, r * .1, r * .09, PAL.cream, .7);
  icon(name, 0, 0, r * .58);
  pop();
}

// ---------- sets ----------
function room(o) {
  boilSeed('wall'); paint(rectPts(-500, -400, 2920, 1900), { wash: o.wall, ink: null });
  if (o.win) {
    const [x, y, w, h, sky, body] = o.win; boilSeed('win');
    rc(x - 14, y - 14, w + 28, h + 28, PAL.cream, 1); paint(rectPts(x, y, w, h), { wash: sky, ink: PAL.ink, sw: .8 });
    if (body === 'sun') paint(ellPts(x + w * .7, y + h * .35, 34, 34, 16), { wash: mixCol(PAL.cream, PAL.ochre, .5), ink: null });
    if (body === 'moon') { paint(ellPts(x + w * .7, y + h * .35, 30, 30, 16), { wash: PAL.cream, ink: null }); paint(ellPts(x + w * .7 + 14, y + h * .35 - 8, 26, 26, 16), { wash: sky, ink: null }); }
    inkLine([[x + w / 2, y], [x + w / 2, y + h]], 1.4); inkLine([[x, y + h / 2], [x + w, y + h / 2]], 1.4);
  }
  boilSeed('floor'); paint(rectPts(-500, GY - 70, 2920, 700), { wash: o.floor, ink: null });
  for (let j = 0; j < 3; j++) inkLine([[-400 + j * 900, GY - 70], [50 + j * 900, GY - 72], [500 + j * 900, GY - 70]], 1.1, PAL.ink, 'ink', .3);
  if (o.rug) { boilSeed('rug'); paint(ellPts(960, GY + 40, 760, 70, 30, 2), { wash: o.rug, ink: PAL.ink, sw: .7 }); }
}
function park(t, warm = 0) {
  const sky = mixCol('#A8D5EF', '#F6C6A0', warm), hf = mixCol('#A9D0B4', '#E3CC96', warm * .7), hm = mixCol('#8DBD72', '#BFBB62', warm * .6), grd = mixCol('#79AA5C', '#A6AA52', warm * .5);
  boilSeed('sky'); paint(rectPts(-500, -400, 2920, 1900), { wash: sky, ink: null });
  boilSeed('sun'); paint(ellPts(330, 170 + 260 * warm, 78, 78, 24, 1.5), { wash: mixCol(PAL.cream, PAL.ochre, .2 + .5 * warm), ink: null });
  for (let i = 0; i < 4; i++) { boilSeed('cl' + i); const cx = (hash(i + 5) * 2400 - 200 + t * 5) % 2600 - 200, cy = 110 + hash(i + 9) * 190, w = 130 + 70 * hash(i); for (const [dx, dy, k] of [[0, 0, 1], [.35, -30, .55], [-.4, -16, .45]]) paint(ellPts(cx + w * dx, cy + dy, w * k, 30 + 12 * k, 16, 4), { wash: PAL.cream, washOp: 205, ink: null }); }
  for (let i = 0; i < 4; i++) { boilSeed('hf' + i); paint(ellPts(-200 + i * 820, GY + 40, 600, 250 + 70 * hash(i + 2), 34, 2), { wash: hf, ink: PAL.ink, sw: .6 }); }
  for (let i = 0; i < 3; i++) { boilSeed('hm' + i); paint(ellPts(100 + i * 900, GY + 70, 660, 190 + 50 * hash(i + 12), 34, 2), { wash: hm, ink: PAL.ink, sw: .8 }); }
  boilSeed('grd'); paint(rectPts(-500, GY - 46, 2920, 800), { wash: grd, ink: null });
  for (let j = 0; j < 3; j++) inkLine([[-400 + j * 900, GY - 46], [50 + j * 900, GY - 48], [500 + j * 900, GY - 46]], 1, PAL.ink, 'ink', .3);
  const tc = mixCol(grd, LEAFC, .9);
  for (let i = 0; i < 40; i++) { boilSeed('tf' + i); const x = -300 + i * 62 + hash(i) * 40, row = i % 3, y = GY - 40 + [0, 70, 150][row] + hash(i + 50) * 30, h = 22 + 12 * hash(i + 20), s = wob(t, .45, hash(i) * 3) * 5; for (const d of [-1, 0, 1]) inkLine([[x + d * 8, y], [x + d * 13 + s, y - h]], 1.2, tc, 'inkfine', .4); }
}
const sofa = (x, w, col) => { boilSeed('sofa' + x); pw(rrPts(x - w / 2, GY - 330, w, 290, 50), col, 1.2); pw(rrPts(x - w / 2 - 50, GY - 220, 100, 210, 40), mixCol(col, PAL.ink, .15), 1.1); pw(rrPts(x + w / 2 - 50, GY - 220, 100, 210, 40), mixCol(col, PAL.ink, .15), 1.1); pw(rrPts(x - w / 2 + 30, GY - 130, w - 60, 120, 30), mixCol(col, PAL.cream, .25), 1.1); };
const table = (x, w, col, h = 86) => { boilSeed('table' + x); paint(rectPts(x - w / 2 + 20, GY - h + 20, w - 40, h + 60), { wash: mixCol(col, PAL.ink, .12), ink: PAL.ink, sw: 1 }); pw(rrPts(x - w / 2, GY - h, w, 34, 12), col, 1.2); };
const benchBack = (x, w) => { boilSeed('benchB'); for (let i = 0; i < 3; i++) rc(x - w / 2, GY - 300 + i * 62, w, 46, '#B98557', 1); for (const d of [-1, 1]) rc(x + d * (w / 2 - 50) - 12, GY - 310, 24, 320, '#8A5F3B', 1); };
const benchSeat = (x, w) => { boilSeed('benchS'); rc(x - w / 2 - 20, GY - 92, w + 40, 34, '#C9965F', 1.1); for (const d of [-1, 1]) rc(x + d * (w / 2 - 50) - 12, GY - 58, 24, 62, '#8A5F3B', 1); };
const lamp = (x, on) => { boilSeed('lamp' + x); if (on > 0) glow(x, GY - 420, 330, '#FFD98A', on); inkLine([[x, GY - 10], [x, GY - 380]], 2.2, '#4A4263', 'ink', 0); el(x, GY - 6, 60, 12, '#4A4263', .8); pw([[x - 46, GY - 470], [x + 46, GY - 470], [x + 86, GY - 370], [x - 86, GY - 370]], on > 0 ? '#F6D27A' : '#B9A98A', 1.1); };
const tvSet = (x, t, on = 1) => { boilSeed('tv' + x); rc(x - 190, GY - 110, 380, 110, '#8A5F3B', 1); pw(rrPts(x - 170, GY - 380, 340, 250, 18), '#4A4263', 1.3); const c = on ? ['#9FD3E8', '#F2C14E', '#E99BB0', '#8ED6A6'][Math.floor(t * 1.4) % 4] : '#6B6482'; paint(rectPts(x - 148, GY - 360, 296, 208), { wash: c, ink: null }); if (on) glow(x, GY - 256, 260, c, .35); };
const mirror = (x, w, h) => { boilSeed('mirror' + x); pw(rrPts(x - w / 2 - 16, GY - 100 - h - 16, w + 32, h + 32, 16), '#C9965F', 1.2); paint(rectPts(x - w / 2, GY - 100 - h, w, h), { wash: '#CFE6EE', ink: PAL.ink, sw: .8 }); inkLine([[x - w * .3, GY - 130 - h * .2], [x - w * .1, GY - 100 - h * .75]], 2, PAL.cream, 'ink', 0); inkLine([[x - w * .15, GY - 130 - h * .1], [x, GY - 100 - h * .45]], 1.4, PAL.cream, 'ink', 0); };
const bunting = (y) => { boilSeed('bunting'); const P = []; for (let i = 0; i <= 12; i++) P.push([-100 + i * 180, y + 50 * Math.sin(i / 12 * Math.PI)]); inkLine(P, 1.2, PAL.ink, 'inkfine', .5); for (let i = 0; i < 12; i++) { const [x0, y0] = P[i], [x1, y1] = P[i + 1]; pw([[x0 + 20, y0 + 3], [x1 - 20, y1 + 3], [(x0 + x1) / 2, (y0 + y1) / 2 + 80]], [PAL.rose, PAL.ochre, PAL.teal, PAL.violet][i % 4], .8); } };
const picture = (x, y, col) => { boilSeed('pic' + x); rc(x - 70, y - 55, 140, 110, '#C9965F', 1); paint(rectPts(x - 56, y - 41, 112, 82), { wash: col, ink: PAL.ink, sw: .6 }); };
function doggo(x, t, k = 1) {
  boilSeed('dog'); push(); translate(x, GY); scale(k);
  const wag = Math.sin(t * 14) * .5;
  inkLine([[58, -62], [80 + 16 * wag, -96], [86 + 26 * wag, -124]], 3, '#7A4A2E', 'ink', .6);
  for (const lx of [-46, -18, 22, 48]) rc(lx - 8, -34, 16, 36, '#A8703C', .8);
  pw(rrPts(-66, -96, 132, 70, 30), '#C98A4B', 1.1);
  el(-88, -128, 16, 34, '#7A4A2E', .8); el(-28, -128, 16, 34, '#7A4A2E', .8);
  el(-58, -112, 44, 40, '#C98A4B', 1.1); el(-72, -118, 5, 7, PAL.ink, .2); el(-46, -118, 5, 7, PAL.ink, .2); el(-60, -98, 8, 6, PAL.ink, .2);
  pop();
}

// ---------- the section runner ----------
// S = { t0, n, title, bg(t), under(t, R), over(t, R), screen(t, R), ch: { A: { x, k, o, look, pose, u, y } }, bub: [[t0, t1, who, icon]], cam: [[t, 'W'|'T'|'A'|[cx, cy, z]]] }
const CAMS = { W: [960, 540, 1], T: [960, 620, 1.22] };
function prepSection(S) {
  for (const [name, c] of Object.entries(S.ch)) {
    c.look = c.look ?? (name === 'A' ? .6 : name === 'B' ? -.6 : 0);
    c.k = c.k.map(([t, n, ov]) => { const b = (EMO[n] || EMO.neutral).body; return [t, n, b && b(0).lookX !== undefined ? ov : { lookX: c.look, ...(ov || {}) }]; });
  }
  return S;
}
const xOf = (c, t) => typeof c.x === 'number' ? c.x : kf(t, c.x);
function runSection(S, t) {
  const R = { p: {}, t };
  for (const [name, c] of Object.entries(S.ch)) {
    const u = c.u || UU, m = emotions(t, c.k, { take: c.take ?? 1 }), x = xOf(c, t);
    let o = { ...(c.o || {}), ...m };
    if (typeof c.x !== 'number') {
      const v = (kf(t + .05, c.x) - kf(t - .05, c.x)) / .1;
      if (Math.abs(v) > 45) { const w = x / (3 * u); o = { ...o, view: 'side', flip: v < 0, walk: w, dy: -.5 * Math.abs(Math.sin(w * TAU)), sq: 0, rot: .06, dx: 0, lid: 0 }; }
    }
    if (c.pose) Object.assign(o, c.pose(t, o) || {});
    R.p[name] = { x, o, u, y: c.y || GY, c };
  }
  const res = s => typeof s === 'string' ? (CAMS[s] || [R.p[s].x, R.p[s].y - (R.p[s].o.sit ? 260 : (CAMS.closeDy || 340)), CAMS.closeZ || 1.4]) : s;
  let i = 0; while (i + 1 < S.cam.length && t >= S.cam[i + 1][0]) i++;
  let cam = res(S.cam[i][1]);
  if (i > 0) { const pv = res(S.cam[i - 1][1]), k = ease(seg(t, S.cam[i][0], S.cam[i][0] + .5)); cam = cam.map((v, j) => lerp(pv[j], v, k)); }
  const sh = S.shake ? S.shake(t) : 0, sk = sh ? shakeXY(t, sh) : [0, 0];
  camBegin(cam[0] + 8 * Math.sin(t * .5) + sk[0], cam[1] + 4 * Math.sin(t * .37) + sk[1], cam[2] * (1 + .008 * Math.sin(t * .31)));
  S.bg(t, R);
  if (S.under) S.under(t, R);
  for (const [name, p] of Object.entries(R.p)) { if (p.c.hide && p.c.hide(t)) continue; tall(p.x, p.y, p.u * TU, { look: lookFor(name), ...p.o, boilKey: name }); }
  if (S.over) S.over(t, R);
  for (let j = 0; j < (S.bub || []).length; j++) {
    const [b0, b1, who, name] = S.bub[j]; if (t < b0 || t > b1) continue;
    const p = R.p[who], k = backOut(seg(t, b0, b0 + .22)) * (1 - ease(seg(t, b1 - .15, b1))), d = p.c.bd ?? (p.x < 420 ? 1 : p.x > 1500 ? -1 : p.x < 960 ? -1 : 1);
    boilSeed('bub' + j); bubble(p.x + d * 3.3 * p.u, p.y - (p.o.sit ? 15.8 : 19.3) * p.u * TU + 6 * Math.sin(t * 3 + j), 2.5 * p.u, k, name, -d);
  }
  const lead = R.p.A || R.p.B || Object.values(R.p)[0]; R.eye = toScreen(lead.x, GY - 12 * UU * TU);
  camEnd();
  if (S.screen) S.screen(t, R);
  if (S.title) { const a = t - S.tt; if (a > 0 && a < 3) { boilSeed('banner'); const bk = backOut(seg(a, 0, .25)) * (1 - seg(a, 2.6, 3)), bw = 150 + S.title.length * 46, fit = Math.min(1, (W - 80) / bw), cx = W / 2, ty = S.titleY || 200; if (bk > .03) { push(); translate(cx, ty); scale(bk * fit); rotate(-.03); paint(rrPts(-bw / 2, -150, bw, 300, 60, 6), { wash: PAL.ink, washOp: 225, ink: null }); pop(); } letter('#' + S.n, cx, ty - 70 * fit, 150 * fit, PAL.ochre, { pop: a * 4, alpha: 1 - seg(a, 2.6, 3), stroke: PAL.ink, screen: true, rot: -.04 }); letter(S.title, cx, ty + 68 * fit, 82 * fit, PAL.cream, { pop: (a - .25) * 4, alpha: 1 - seg(a, 2.6, 3), stroke: PAL.ink, screen: true, rot: -.02 }); } }
  return R;
}
// a camera-flash moment at each time in ts
const flashes = (t, ts) => flash(ts.reduce((s, a) => s + (t >= a ? Math.exp(-(t - a) * 9) : 0), 0) * .85, PAL.cream);
