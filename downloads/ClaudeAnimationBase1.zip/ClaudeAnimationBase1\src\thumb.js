// thumb.js: the YouTube thumbnail, painted with the same cast.  node render.mjs --loop=thumb --stills=0.4 --out=out/thumb
LOOPS.thumb = t => {
  const BLACK = '900 {S}px "Segoe UI Black", "Arial Black", Impact, sans-serif', F = s => BLACK.replace('{S}', s);
  // sunburst behind everyone
  boilSeed('thumb bg'); paint(rectPts(-100, -100, W + 200, H + 200), { wash: '#FF9DB3', ink: null });
  const C = [1010, 640];
  for (let i = 0; i < 18; i++) { const a0 = i / 18 * TAU, a1 = a0 + TAU / 36; boilSeed('ray' + i); paint([C, [C[0] + Math.cos(a0) * 2200, C[1] + Math.sin(a0) * 2200], [C[0] + Math.cos(a1) * 2200, C[1] + Math.sin(a1) * 2200]], { wash: '#FFC1CE', ink: null }); }
  glow(C[0], C[1], 700, '#FFE6A8', .55);

  // back row: the old couple (left) and the baby-talk couple (right)
  const G2 = 1230, u2 = 46;
  tall(250, G2, u2, { ...feel('love', .3), look: 'oldman', boilKey: 'om', aR: .45, emote: null });
  tall(450, G2, u2, { ...feel('love', .9), look: 'oldwoman', hat: 'bow', boilKey: 'ow', aL: .45, emote: null });
  tall(1530, G2, u2, { ...feel('love', .5), look: 'boy3', boilKey: 'b3', aR: .45, emote: null });
  tall(1730, G2, u2, { ...feel('love', 1.1), look: 'sweet', hat: 'bow', boilKey: 'sw', aL: .45, emote: null });
  boilSeed('hearts'); for (const [x, y, r] of [[350, 455, 30], [410, 400, 18]]) paint(heartPts(x, y, r), { wash: '#E2476E', ...{ ink: PAL.ink, sw: 1.2 } });

  // front: the bickering couple, big, nose to nose with a lightning crack between them
  const G1 = 1520, u1 = 66;
  tall(800, G1, u1, { ...feel('furious', .37), eyes: 'angry', mouth: 'teeth', look: 'boy2', boilKey: 'b2', rot: .05, aR: .6, aL: -.1, emote: 'anger', emoteK: 1 });
  tall(1230, G1, u1, { ...feel('furious', .21), eyes: 'angry', mouth: 'open', look: 'girl2', boilKey: 'g2', flip: true, rot: .05, aR: .6, aL: -.1, emote: 'anger', emoteK: 1 });
  boilSeed('bolt'); paint([[1030, 470], [985, 590], [1035, 585], [990, 720], [1075, 560], [1025, 565], [1068, 470]], { wash: '#FFD94A', ink: PAL.ink, sw: 2.2 });

  // title and tags
  boilSeed('banner'); push(); translate(960, 128); rotate(-.025); paint(rrPts(-905, -100, 1810, 200, 44, 4), { wash: PAL.ink, washOp: 235, ink: null }); pop();
  letter('EVERY TYPE OF COUPLE', 960, 132, 150, '#FFD94A', { font: F(150), stroke: PAL.ink, rot: -.025 });
  boilSeed('ask'); push(); translate(1460, 300); rotate(.04); paint(rrPts(-370, -54, 740, 108, 30, 3), { wash: '#FFFFFF', ink: PAL.ink, sw: 2.2 }); pop();
  letter('WHICH ONE ARE YOU?', 1460, 302, 60, '#E2335A', { font: F(60), rot: .04, ink: false });
  const tag = (x, y, txt, col, rot) => { boilSeed('tag' + x); push(); translate(x, y); rotate(rot); paint(rrPts(-txt.length * 17 - 26, -34, txt.length * 34 + 52, 68, 20, 2), { wash: col, ink: PAL.ink, sw: 1.8 }); pop(); letter(txt, x, y + 2, 44, '#FFFFFF', { font: F(44), rot, stroke: PAL.ink }); };
  tag(350, 340, '50 YEARS', '#8A6FB8', -.06);
  tag(1640, 432, 'BABY TALK', '#E2476E', .06);
};
LOOPS.thumb.len = 1;

// thumb2: the "lineup" thumbnail. White page, big black title, six couples full-length, a label over each.
//   node render.mjs --loop=thumb2 --stills=0.4 --out=out/thumb
LOOPS.thumb2 = t => {
  const F = s => `900 ${s}px "Segoe UI Black", "Arial Black", Impact, sans-serif`;
  boilSeed('t2 bg'); paint(rectPts(-100, -100, W + 200, H + 200), { wash: '#FBFAF7', ink: null });
  letter('EVERY TYPE OF COUPLE', 960, 108, 150, '#1E1A22', { font: F(150), ink: false });
  boilSeed('t2 ask'); push(); translate(960, 252); rotate(-.03); paint(rrPts(-560, -76, 1120, 152, 40, 3), { wash: '#E2335A', ink: PAL.ink, sw: 3 }); pop();
  letter('WHICH ONE ARE YOU?', 960, 256, 96, '#FFFFFF', { font: F(96), rot: -.03, stroke: '#1E1A22', ink: false });
  const G = 1072, u = 40, gap = 150;
  // [label, him, his mood, his arms, her, her mood, her arms, extra for her]
  const C = [
    ['BABY TALK', 'boy3', 'love', [-.7, .45], 'sweet', 'love', [.45, -.7], { hat: 'bow' }],
    ['GYM', 'gymboy', 'determined', [-.7, .3], 'gym', 'proud', [.3, -.7], {}],
    ['FIGHTERS', 'boy2', 'angry', [-.7, .6], 'girl2', 'angry', [.6, -.7], { mouth: 'open' }],
    ['OPPOSITES', 'introboy', 'bored', [-.7, -.7], 'extrovert', 'excited', [-.3, -.7], {}],
    ['INSTAGRAM', 'boy', 'happy', [-.7, .45], 'instagirl', 'smug', [.45, -.7], {}],
    ['OLD COUPLE', 'oldman', 'relieved', [-.7, .45], 'oldwoman', 'happy', [.45, -.7], { hat: 'bow' }],
  ];
  C.forEach(([label, a, ea, armA, b, eb, armB, ob], i) => {
    const cx = 160 + i * 320, still = { emote: null, dy: 0, sq: 0, rot: 0, dx: 0, squint: 0 };
    tall(cx - gap / 2, G, u, { ...feel(ea, 0), ...still, look: a, boilKey: 'a' + i, aL: armA[0], aR: armA[1] });
    tall(cx + gap / 2, G, u, { ...feel(eb, 0), ...still, ...ob, look: b, boilKey: 'b' + i, aL: armB[0], aR: armB[1] });
    letter(label, cx, 376, 42, '#1E1A22', { font: F(42), ink: false });
  });
  boilSeed('t2 hearts'); for (const [x, y, r] of [[160, 420, 22], [1760, 420, 22]]) paint(heartPts(x, y, r), { wash: '#E2476E', ink: PAL.ink, sw: 1 });
};
LOOPS.thumb2.len = 1;

// thumb3: SWEET vs TOXIC. A diagonal split, giant faces, a VS bolt, one short question.
//   node render.mjs --loop=thumb3 --stills=0.4 --out=out/thumb
LOOPS.thumb3 = t => {
  const F = s => `900 ${s}px "Segoe UI Black", "Arial Black", Impact, sans-serif`;
  boilSeed('t3 L'); paint(rectPts(-100, -100, W + 200, H + 200), { wash: '#FF9EBB', ink: null });
  glow(420, 560, 650, '#FFE3EC', .7);
  boilSeed('t3 R'); paint([[1060, -100], [W + 100, -100], [W + 100, H + 100], [860, H + 100]], { wash: '#2E1828', ink: null });
  glow(1480, 600, 620, '#FF3B3B', .55);
  boilSeed('t3 edge'); inkLine([[1060, -100], [860, H + 100]], 9, '#FFFFFF', 'ink', 0);
  // sweet: cheek to cheek, heart eyes, hearts everywhere
  const G = 1720, u = 78, still = { dy: 0, sq: 0, rot: 0, dx: 0, squint: 0, emote: null };
  tall(250, G, u, { ...feel('love', 0), ...still, look: 'boy3', boilKey: 's1', rot: .07, aR: .3, aL: -.7 });
  tall(560, G, u, { ...feel('love', 0), ...still, look: 'sweet', hat: 'bow', boilKey: 's2', rot: -.07, aL: .3, aR: -.7 });
  boilSeed('t3 hearts'); for (const [x, y, r] of [[405, 300, 54], [140, 420, 30], [690, 380, 36], [470, 210, 24], [90, 640, 22], [760, 600, 26]]) paint(heartPts(x, y, r), { wash: '#E2335A', ink: PAL.ink, sw: 2 });
  // toxic: nose to nose, red eyes, shouting
  tall(1330, G, u, { ...feel('furious', 0), ...still, eyes: 'red', mouth: 'teeth', look: 'boy2', boilKey: 't1', rot: .06, aR: .2, aL: -.7, lid: 0 });
  tall(1690, G, u, { ...feel('furious', 0), ...still, eyes: 'red', mouth: 'open', look: 'girl2', boilKey: 't2', flip: true, rot: .06, aR: .2, aL: -.7, lid: 0 });
  boilSeed('t3 anger'); emote('anger', 1250, 330, 70, 1, .5); emote('anger', 1790, 320, 70, 1, .9);
  boilSeed('t3 crack'); paint([[1525, 260], [1490, 380], [1535, 376], [1500, 520], [1580, 350], [1535, 355], [1565, 260]], { wash: '#FFD94A', ink: PAL.ink, sw: 2.4 });
  // VS badge on the split
  boilSeed('t3 vs'); paint(starPts(960, 610, 165, .62, 12, .1), { wash: '#FFD94A', ink: PAL.ink, sw: 3.2 });
  letter('VS', 960, 615, 150, '#E2335A', { font: F(150), stroke: '#1E1A22', rot: -.06 });
  // question + tags
  boilSeed('t3 top'); push(); translate(960, 112); rotate(-.02); paint(rrPts(-800, -82, 1600, 164, 40, 3), { wash: '#1E1A22', washOp: 240, ink: null }); pop();
  letter('WHICH ONE ARE YOU?', 960, 116, 128, '#FFD94A', { font: F(128), rot: -.02, ink: false });
  const tag = (x, y, txt, col, rot) => { boilSeed('t3 tag' + x); push(); translate(x, y); rotate(rot); paint(rrPts(-txt.length * 36 - 36, -62, txt.length * 72 + 72, 124, 32, 3), { wash: col, ink: PAL.ink, sw: 3 }); pop(); letter(txt, x, y + 4, 100, '#FFFFFF', { font: F(100), rot, stroke: '#1E1A22' }); };
  tag(410, 975, 'SWEET', '#E2335A', -.05);
  tag(1500, 975, 'TOXIC', '#B3122A', .05);
};
LOOPS.thumb3.len = 1;
