// tg_kit.js: props and sets for "Every Type of Person at Thanksgiving Dinner". Builds on couples_kit.js (icons, hold,
// bubbles, runSection) and tall.js (the cast).
const FALL = { wall: '#E9C49A', wallDk: '#D6A774', wood: '#9A5F36', woodDk: '#6E3F22', cloth: '#F6EBD6', runner: '#C8582E', leaf: ['#D2493A', '#E07A2E', '#E3A33B', '#9A5F36'] };

// ---------- icons (x, y centre, s = half size) ----------
Object.assign(ICON, {
  turkey: (x, y, s) => {
    el(x, y + .55 * s, 1.15 * s, .28 * s, '#F2EEE6', 1);   // platter
    for (const d of [-1, 1]) { inkLine([[x + d * .55 * s, y + .1 * s], [x + d * 1.0 * s, y - .35 * s]], 5.5 * s / 40, '#B8692E', 'ink', 0); el(x + d * 1.05 * s, y - .42 * s, .13 * s, .13 * s, '#F6F1E6', .6); }
    pw(ellPts(x, y + .1 * s, .9 * s, .55 * s, 18).filter(p => p[1] <= y + .45 * s), '#C77A3A', 1.2);
    paint(ellPts(x - .25 * s, y - .12 * s, .38 * s, .16 * s, 12), { wash: '#E8A866', ink: null });
  },
  pie: (x, y, s) => {
    pw([[x - .95 * s, y - .05 * s], [x + .95 * s, y - .05 * s], [x + .75 * s, y + .45 * s], [x - .75 * s, y + .45 * s]], '#C98A4B');
    el(x, y - .05 * s, .95 * s, .32 * s, '#D9A25A', 1); el(x, y - .07 * s, .78 * s, .24 * s, '#D9782E', .5, null);
    el(x + .1 * s, y - .22 * s, .22 * s, .12 * s, '#FBF7F0', .6);
  },
  slice: (x, y, s) => { pw([[x - .8 * s, y + .4 * s], [x + .8 * s, y + .4 * s], [x, y - .6 * s]], '#D9782E'); pw([[x - .85 * s, y + .4 * s], [x + .85 * s, y + .4 * s], [x + .85 * s, y + .62 * s], [x - .85 * s, y + .62 * s]], '#C98A4B'); el(x, y + .05 * s, .2 * s, .12 * s, '#FBF7F0', .5); },
  piebox: (x, y, s) => { ICON.pie(x, y + .1 * s, s * .9); paint(rrPts(x - 1.05 * s, y - .55 * s, 2.1 * s, 1.2 * s, .12 * s), { wash: '#CFEAF2', washOp: 90, ink: PAL.ink, sw: 1.1 }); rc(x + .3 * s, y - .5 * s, .6 * s, .32 * s, '#F2D23A', .7); inkLine([[x + .38 * s, y - .34 * s], [x + .78 * s, y - .34 * s]], .7, PAL.ink, 'inkfine', 0); },
  knife: (x, y, s) => { pw(rrPts(x - 1.1 * s, y - .25 * s, .9 * s, .5 * s, .18 * s), '#4A4263'); pw([[x - .25 * s, y - .16 * s], [x + 1.2 * s, y - .1 * s], [x + 1.25 * s, y + .05 * s], [x - .25 * s, y + .14 * s]], '#D7DDE2'); for (let i = 0; i < 6; i++) inkLine([[x + i * .22 * s, y + .12 * s], [x + i * .22 * s + .08 * s, y + .02 * s]], .6, PAL.ink, 'inkfine', 0); el(x - .75 * s, y, .08 * s, .08 * s, '#D2493A', .3); },
  tablet: (x, y, s) => { pw(rrPts(x - .8 * s, y - 1 * s, 1.6 * s, 2 * s, .16 * s), '#2B2738'); paint(rectPts(x - .66 * s, y - .84 * s, 1.32 * s, 1.68 * s), { wash: '#7FC8E8', ink: null }); pw([[x - .2 * s, y - .3 * s], [x + .3 * s, y], [x - .2 * s, y + .3 * s]], '#FBF7F0', .6); },
  football: (x, y, s) => { pw(ellPts(x, y, s, .58 * s, 18), '#8A4A2A', 1.2); inkLine([[x - .45 * s, y], [x + .45 * s, y]], 1.2, PAL.cream, 'ink', 0); for (let i = -2; i <= 2; i++) inkLine([[x + i * .18 * s, y - .14 * s], [x + i * .18 * s, y + .14 * s]], 1, PAL.cream, 'ink', 0); },
  roll: (x, y, s) => { pw(ellPts(x, y, .85 * s, .55 * s, 16), '#D9A25A', 1); inkLine([[x - .3 * s, y - .3 * s], [x + .1 * s, y + .35 * s]], .8, '#A8703C', 'ink', .4); paint(ellPts(x - .25 * s, y - .2 * s, .3 * s, .12 * s, 10), { wash: '#EFC27A', ink: null }); },
  tofu: (x, y, s) => { const w = 1 + .06 * Math.sin(T * 14); el(x, y + .55 * s, 1.15 * s, .28 * s, '#F2EEE6', 1); pw(ellPts(x, y + .1 * s, .9 * s * w, .55 * s / w, 18).filter(p => p[1] <= y + .45 * s), '#B8B4AE', 1.2); for (const d of [-1, 1]) inkLine([[x + d * .55 * s, y + .1 * s], [x + d * .95 * s, y - .3 * s]], 5 * s / 40, '#A8A49E', 'ink', 0); },
  tupper: (x, y, s) => { for (let i = 0; i < 3; i++) { const yy = y + .55 * s - i * .55 * s; rc(x - .8 * s, yy - .3 * s, 1.6 * s, .5 * s, '#EAF4F7', .8); rc(x - .86 * s, yy - .38 * s, 1.72 * s, .14 * s, '#4F9FD6', .6); paint(rectPts(x - .6 * s, yy - .15 * s, 1.2 * s, .25 * s), { wash: '#C77A3A', washOp: 150, ink: null }); } },
  ring: (x, y, s) => { paint(ellPts(x, y + .25 * s, .6 * s, .6 * s, 18), { ink: '#D9A23A', sw: 3.4 * s / 40 }); pw([[x - .3 * s, y - .35 * s], [x + .3 * s, y - .35 * s], [x + .45 * s, y - .6 * s], [x, y - .9 * s], [x - .45 * s, y - .6 * s]], '#BDE6F2', .8); },
  bottle: (x, y, s) => { rc(x - .4 * s, y - .35 * s, .8 * s, 1.25 * s, '#FBF7F0', .9); rc(x - .45 * s, y - .55 * s, .9 * s, .25 * s, '#F4A8BC', .7); pw([[x - .18 * s, y - .55 * s], [x + .18 * s, y - .55 * s], [x + .08 * s, y - .95 * s], [x - .08 * s, y - .95 * s]], '#E9C49A', .6); for (let i = 0; i < 3; i++) inkLine([[x - .4 * s, y + i * .3 * s], [x - .2 * s, y + i * .3 * s]], .6, PAL.ink, 'inkfine', 0); },
  potato: (x, y, s) => { pw(ellPts(x, y + .1 * s, s, .55 * s, 18).filter(p => p[1] >= y), '#E9DFCC'); pw(ellPts(x, y - .1 * s, .8 * s, .45 * s, 16), '#F7EFD8', .8); rc(x - .15 * s, y - .4 * s, .32 * s, .22 * s, '#F2D23A', .5); },
  leaf: (x, y, s) => { pw(starPts(x, y, s, .5, 5, -Math.PI / 2), '#E07A2E', 1); inkLine([[x, y + .2 * s], [x + .1 * s, y + 1.1 * s]], 1.2, '#7A4A2E', 'ink', 0); },
  butter: (x, y, s) => { pw([[x - .8 * s, y], [x + .5 * s, y], [x + .8 * s, y - .35 * s], [x - .5 * s, y - .35 * s]], '#F7E07A', .8); pw([[x - .8 * s, y], [x + .5 * s, y], [x + .5 * s, y + .4 * s], [x - .8 * s, y + .4 * s]], '#F2D23A', .8); },
  plate: (x, y, s) => { el(x, y + .2 * s, 1.1 * s, .35 * s, '#FBF7F0', 1); pw(ellPts(x, y, .75 * s, .55 * s, 16).filter(p => p[1] <= y + .15 * s), '#C77A3A', .8); el(x + .45 * s, y - .15 * s, .3 * s, .25 * s, '#F7EFD8', .5); el(x - .45 * s, y - .05 * s, .28 * s, .2 * s, '#6FA05A', .5); },
  gravy: (x, y, s) => { pw([[x - .9 * s, y - .1 * s], [x + .7 * s, y - .1 * s], [x + 1.1 * s, y - .45 * s], [x + .6 * s, y + .45 * s], [x - .6 * s, y + .45 * s]], '#FBF7F0'); el(x - .1 * s, y - .1 * s, .7 * s, .18 * s, '#8A4A2A', .5); },
  jelly: (x, y, s) => { const w = 1 + .08 * Math.sin(T * 16); pw(ellPts(x, y, .9 * s * w, .6 * s / w, 16), '#8A4A2A', 1); paint(ellPts(x - .25 * s, y - .2 * s, .25 * s, .12 * s, 10), { wash: '#B8703C', ink: null }); },
  stuffing: (x, y, s) => { pw(ellPts(x, y + .1 * s, s, .55 * s, 18).filter(p => p[1] >= y), '#9A5F36'); for (let i = 0; i < 6; i++) el(x - .6 * s + i * .24 * s, y - .05 * s - (i % 2) * .12 * s, .2 * s, .16 * s, '#C98A4B', .4); },
  fork: (x, y, s) => { inkLine([[x, y - .2 * s], [x, y + 1 * s]], 2.2, '#9AA3AA', 'ink', 0); for (let i = -1; i <= 1; i++) inkLine([[x + i * .16 * s, y - .9 * s], [x + i * .16 * s, y - .3 * s]], 1.4, '#9AA3AA', 'ink', 0); inkLine([[x - .2 * s, y - .3 * s], [x + .2 * s, y - .3 * s]], 1.6, '#9AA3AA', 'ink', 0); },
  news: (x, y, s) => { ICON.tv(x, y, s); paint(rectPts(x - .82 * s, y + .1 * s, 1.64 * s, .3 * s), { wash: '#D2493A', ink: null }); },
  chart: (x, y, s) => { rc(x - .9 * s, y - .8 * s, 1.8 * s, 1.6 * s, PAL.paper, 1); for (let i = 0; i < 3; i++) rc(x - .6 * s + i * .45 * s, y + .55 * s - (.4 + i * .3) * s, .3 * s, (.4 + i * .3) * s, ['#4F9FD6', '#E3A33B', '#D2493A'][i], .5); },
  car: (x, y, s) => { pw(rrPts(x - 1 * s, y - .2 * s, 2 * s, .55 * s, .2 * s), '#D2493A'); pw([[x - .55 * s, y - .2 * s], [x - .3 * s, y - .6 * s], [x + .4 * s, y - .6 * s], [x + .65 * s, y - .2 * s]], '#9FD3E8'); for (const d of [-.55, .55]) el(x + d * s, y + .38 * s, .22 * s, .22 * s, '#2B2738', .6); },
  wifi2: (x, y, s) => ICON.wifi(x, y, s),
  whistle: (x, y, s) => { pw(ellPts(x, y, .6 * s, .5 * s, 14), '#D7DDE2'); rc(x, y - .45 * s, .9 * s, .4 * s, '#D7DDE2', .7); },
  thanks: (x, y, s) => { pw(heartPts(x, y, s * .95), '#E07A2E'); },
});

// ---------- sets ----------
function fallWindow(x, y, w, h, night) {
  boilSeed('fwin' + x); rc(x - 16, y - 16, w + 32, h + 32, FALL.cloth, 1);
  paint(rectPts(x, y, w, h), { wash: night ? '#2E2F5A' : '#A9D3E8', ink: PAL.ink, sw: .8 });
  if (!night) for (let i = 0; i < 4; i++) { boilSeed('tree' + x + i); paint(ellPts(x + w * (.2 + i * .22), y + h * (.62 - (i % 2) * .12), w * .16, h * .2, 12, 3), { wash: FALL.leaf[i], ink: null }); }
  else paint(ellPts(x + w * .72, y + h * .3, 26, 26, 16), { wash: PAL.cream, ink: null });
  inkLine([[x + w / 2, y], [x + w / 2, y + h]], 1.5); inkLine([[x, y + h / 2], [x + w, y + h / 2]], 1.5);
}
function garland(y, x0 = -60, x1 = 1980) {
  boilSeed('garland'); const P = []; for (let i = 0; i <= 10; i++) P.push([lerp(x0, x1, i / 10), y + 40 * Math.sin(i / 10 * Math.PI * 2) ** 2]);
  inkLine(P, 1.4, '#6E3F22', 'inkfine', .5);
  for (let i = 0; i < 20; i++) { const k = (i + .5) / 20, x = lerp(x0, x1, k), yy = y + 40 * Math.sin(k * Math.PI * 2) ** 2 + 10; boilSeed('gl' + i); paint(starPts(x, yy, 22, .5, 5, i), { wash: FALL.leaf[i % 4], ink: PAL.ink, sw: .6 }); }
}
function wallBase(col = FALL.wall) {
  boilSeed('tgwall'); paint(rectPts(-500, -400, 2920, 1900), { wash: col, ink: null });
  boilSeed('tgwain'); paint(rectPts(-500, GY - 330, 2920, 300), { wash: mixCol(col, FALL.woodDk, .25), ink: null }); inkLine([[-400, GY - 330], [2400, GY - 330]], 1.2, PAL.ink, 'ink', 0);
  boilSeed('tgfloor'); paint(rectPts(-500, GY - 40, 2920, 700), { wash: FALL.wood, ink: null }); inkLine([[-400, GY - 40], [2400, GY - 40]], 1.2, PAL.ink, 'ink', 0);
}
function tgPicture(x, y, col) { boilSeed('tgpic' + x); rc(x - 70, y - 55, 140, 110, '#C9965F', 1); paint(rectPts(x - 56, y - 41, 112, 82), { wash: col, ink: PAL.ink, sw: .6 }); paint(ellPts(x, y + 10, 26, 18, 12), { wash: '#E07A2E', ink: null }); }
// the dining room: o.night for dusk, o.warm 0..1 for the golden ending light
function tgDining(t, o = {}) {
  wallBase(o.night ? '#B98A6A' : FALL.wall);
  fallWindow(830, 150, 260, 220, o.night); tgPicture(420, 290, '#E3A33B'); tgPicture(1500, 290, '#C8582E');
  garland(70);
  if (o.warm) glow(960, 380, 900, '#FFB45A', .45 * o.warm);
}
// the table goes OVER the cast (they stand behind it); dishes sit on its top edge
const TT = GY - 135;
function tgTable(t, dishes = ['pie', 'potato', 'turkey', 'roll', 'pie'], o = {}) {
  boilSeed('tgtable');
  paint(rectPts(-80, TT, 2080, 420), { wash: FALL.cloth, fill: '#E9DCC0', fillOp: 60, tex: .5, ink: null });
  inkLine([[-80, TT], [2000, TT]], 1.4, PAL.ink, 'ink', 0);
  paint(rectPts(560, TT, 800, 420), { wash: FALL.runner, ink: null }); inkLine([[560, TT], [560, GY + 200]], 1, PAL.ink, 'inkfine', 0); inkLine([[1360, TT], [1360, GY + 200]], 1, PAL.ink, 'inkfine', 0);
  for (let i = 0; i < 9; i++) inkLine([[i * 240 - 20, TT + 30], [i * 240 - 40, GY + 200]], .7, '#D9C9A8', 'inkfine', 0);
  const xs = o.xs || dishes.map((_, i) => 960 + (i - (dishes.length - 1) / 2) * (o.gap || 300));
  dishes.forEach((d, i) => { if (!d) return; boilSeed('dish' + i); const s = d === 'turkey' || d === 'tofu' ? 70 : 44; icon(d, xs[i], TT - s * .5 + 4, s); });
  for (const cx of [260, 1660]) { boilSeed('candle' + cx); rc(cx - 12, TT - 110, 24, 110, '#F6EBD6', .8); paint(ellPts(cx, TT - 126, 9, 16, 10), { wash: '#F2C14E', ink: null }); glow(cx, TT - 130, 90, '#FFC86A', .5); }
}
function tgKitchen(t, o = {}) {
  boilSeed('kwall'); paint(rectPts(-500, -400, 2920, 1900), { wash: '#F3E6CF', ink: null });
  for (let i = 0; i < 16; i++) inkLine([[-200 + i * 160, 300], [-200 + i * 160, GY - 330]], .6, '#E0CFB0', 'inkfine', 0);
  for (let j = 0; j < 5; j++) inkLine([[-200, 300 + j * 66], [2200, 300 + j * 66]], .6, '#E0CFB0', 'inkfine', 0);
  boilSeed('kcab'); for (let i = 0; i < 5; i++) { rc(80 + i * 360, 60, 320, 200, '#C9965F', 1); el(80 + i * 360 + 160, 240, 12, 6, PAL.ink, .3); }
  boilSeed('kcounter'); rc(-60, GY - 330, 2040, 300, '#B98557', 1.2); rc(-80, GY - 350, 2080, 34, '#E9DFCC', 1.2);
  for (let i = 0; i < 5; i++) inkLine([[i * 420 + 200, GY - 316], [i * 420 + 200, GY - 40]], 1, PAL.ink, 'inkfine', 0);
  boilSeed('koven'); rc(1350, GY - 330, 420, 300, '#4A4263', 1.3); rc(1390, GY - 290, 340, 170, '#2B2738', 1); glow(1560, GY - 205, 200, '#FF9A3A', .6 + .1 * Math.sin(t * 3));
  paint(rectPts(1400, GY - 280, 320, 150), { wash: '#E07A2E', washOp: 160, ink: null }); icon('turkey', 1560, GY - 210, 46);
  boilSeed('kstove'); for (const [x, c] of [[1440, '#7A7A8A'], [1680, '#C8582E']]) { pw([[x - 80, GY - 420], [x + 80, GY - 420], [x + 70, GY - 352], [x - 70, GY - 352]], c, 1); for (let k = 0; k < 3; k++) { const f = frac(t * .6 + k / 3 + x * .001); paint(ellPts(x - 30 + k * 30, GY - 440 - f * 120, 18 * (1 - f * .5), 24 * (1 - f * .5), 10), { wash: '#FFFFFF', washOp: 160 * (1 - f), ink: null }); } }
  boilSeed('kfloor'); paint(rectPts(-500, GY - 40, 2920, 700), { wash: '#C9B79A', ink: null }); for (let i = 0; i < 14; i++) inkLine([[-200 + i * 180, GY - 40], [-260 + i * 200, GY + 300]], .7, '#A8967A', 'inkfine', 0);
}
function tgLiving(t, o = {}) {
  wallBase('#D9C2A8');
  fallWindow(300, 150, 240, 210, o.night); tgPicture(900, 280, '#5E8F4E');
  boilSeed('tvst'); rc(1400, GY - 150, 440, 150, '#6E3F22', 1);
  pw(rrPts(1420, GY - 470, 400, 300, 18), '#2B2738', 1.4);
  const on = o.tv !== false;
  paint(rectPts(1440, GY - 450, 360, 260), { wash: on ? '#5E9E4E' : '#4A4560', ink: null });
  if (on) { for (let i = 1; i < 5; i++) inkLine([[1440 + i * 72, GY - 450], [1440 + i * 72, GY - 190]], .8, PAL.cream, 'inkfine', 0); for (let i = 0; i < 5; i++) { const px = 1470 + frac(t * .2 + i * .23) * 300, py = GY - 420 + hash(i) * 200; el(px, py, 9, 9, i % 2 ? '#D2493A' : '#2E5AA8', .3); } glow(1620, GY - 320, 300, '#9EE08A', .25); }
  if (o.recliner) { const x = o.recliner; boilSeed('recl'); pw(rrPts(x - 170, GY - 420, 340, 300, 60), '#8A5A3C', 1.3); pw(rrPts(x - 210, GY - 240, 90, 210, 36), '#7A4A2E', 1.2); pw(rrPts(x + 120, GY - 240, 90, 210, 36), '#7A4A2E', 1.2); pw(rrPts(x - 140, GY - 160, 280, 120, 30), '#A8703C', 1.2); }
}
function tgDoor(t, o = {}) {
  wallBase('#E3C9A6');
  boilSeed('door'); const dx = o.door || 1500; rc(dx - 150, GY - 560, 300, 520, '#8A4A2A', 1.3); rc(dx - 110, GY - 520, 220, 140, '#C9E4EF', .9);
  for (const yy of [GY - 340, GY - 200]) rc(dx - 110, yy, 220, 110, '#7A4026', .8); el(dx + 110, GY - 300, 14, 14, '#E3A33B', .6);
  boilSeed('wreath'); for (let i = 0; i < 14; i++) { const a = i / 14 * TAU; paint(starPts(dx + Math.cos(a) * 62, GY - 450 + Math.sin(a) * 62, 22, .5, 5, a), { wash: FALL.leaf[i % 4], ink: PAL.ink, sw: .5 }); }
  boilSeed('coat'); inkLine([[300, GY - 40], [300, GY - 560]], 3, FALL.woodDk, 'ink', 0); for (const d of [-1, 1]) inkLine([[300, GY - 540], [300 + d * 50, GY - 500]], 2.5, FALL.woodDk, 'ink', 0);
  pw([[250, GY - 500], [350, GY - 500], [370, GY - 300], [230, GY - 300]], '#4F6E9A', 1);
  tgPicture(800, 300, '#E3A33B');
}
function leavesFalling(t, n = 10) { for (let i = 0; i < n; i++) { boilSeed('fall' + i); const k = frac(t * (.06 + .04 * hash(i)) + hash(i + 9)), x = hash(i + 3) * 1920 + 60 * Math.sin(t + i), y = -60 + k * 1200; paint(starPts(x, y, 16, .5, 5, t * (1 + hash(i)) + i), { wash: FALL.leaf[i % 4], ink: PAL.ink, sw: .5 }); } }

// test sheet: node render.mjs --loop=tgsets --sheet=0.5 --cols=1 --w=1920 --out=out/check/tgsets.jpg
LOOPS.tgsets = t => {
  const k = Math.floor(t);
  if (k === 0) { tgDining(t); tall(600, GY, 26, { ...feel('happy', t), look: 'boy', boilKey: 'y' }); tall(960, GY, 26, { ...feel('angry', t), look: 'uncle', boilKey: 'u' }); tall(1320, GY, 26, { ...feel('excited', t), look: 'aunt', boilKey: 'au' }); tgTable(t); }
  if (k === 1) { tgKitchen(t); tall(700, GY, 26, { ...feel('nervous', t), look: 'host', boilKey: 'h', ...hold('turkey') }); tall(1100, GY, 26, { ...feel('determined', t), look: 'carver', boilKey: 'c', ...hold('knife') }); }
  if (k === 2) { tgLiving(t, { recliner: 500 }); tall(500, GY, 26, { ...feel('sleepy', t), look: 'grandpa', boilKey: 'g', sit: 5 }); tall(1100, GY, 26, { ...feel('angry', t), look: 'fan', boilKey: 'f', ...hold('football') }); tall(800, GY, 18, { ...feel('bored', t), look: 'kid', boilKey: 'k', ...hold('tablet') }); }
  if (k === 3) { tgDoor(t); tall(700, GY, 26, { ...feel('smug', t), look: 'piegirl', boilKey: 'p', ...hold('piebox', 'R', .85, 1.6) }); tall(1100, GY, 26, { ...feel('proud', t), look: 'vegan', boilKey: 'v', ...hold('tofu', 'L', .85, 1.6) }); tall(1500, GY, 26, { ...feel('cool', t), look: 'late', boilKey: 'l', hat: 'beanie', ...hold('tupper') }); leavesFalling(t, 6); }
};
LOOPS.tgsets.len = 4;
