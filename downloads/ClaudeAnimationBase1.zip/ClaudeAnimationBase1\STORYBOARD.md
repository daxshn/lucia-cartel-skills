# The Butterfly (15 s)

Logline: Clawd wants to catch a butterfly, but every pounce and leap misses, so it gives up — and the butterfly comes to it.

World: one sunny meadow. Pale blue sky, soft green hills, cream daisies, a violet butterfly (the only violet thing, so the eye finds it). The light warms from fresh morning blue (A, B) to a peach afternoon (C) as Clawd stops chasing.

Motif: the daisy. The butterfly lands on it at the start; Clawd flattens it in the pounce and wears it for the rest of the film; the butterfly lands on it again at the end — now on Clawd's head.

Clawd's arc: bored → surprised → starstruck → mischief → (ko) → determined → confused → sad → surprised → love.

Shots:

A  0.0–4.6  [transition in: iris opens on Clawd]  Medium, slow push right. A butterfly flutters in and lands on a daisy; Clawd creeps up and pounces.  
reads:  0.0–0.5   Clawd, bored, alone in a meadow  
0.5–1.8   a butterfly flutters in from the top right, down past Clawd's face  
1.85–2.4  Clawd notices (take), eyes follow it  
2.4–3.1   starstruck; the butterfly drifts to the daisy and lands  
3.25–3.5  mischief: Clawd has a plan  
3.5–4.25  tiptoe creep toward the daisy  
4.25–4.6  wind-up, leap

B  4.6–9.6  [transition: cut on action, mid-leap, camera carries through]  The chase. Camera tracks right.  
reads:  4.6–4.85  the butterfly lifts off just as Clawd comes down  
4.85–5.6  belly-flop on the daisy (shake, dust); the butterfly hovers above, unbothered  
5.65–6.2  Clawd gets up, determined, daisy stuck to its head, eyes on the butterfly  
6.2–6.9   crouch, jump, arms up — the butterfly hops out of reach  
6.9–7.3   lands; the butterfly sets off to the right  
7.3–8.2   Clawd runs after it (camera tracks)  
8.2–8.55  second leap; the butterfly loops up and back over Clawd's head  
8.55–9.3  Clawd skids to a stop, confused, looking the wrong way; the butterfly hovers behind it

C  9.6–15.0  [transition: brush wipe in meadow green and gold]  Close on Clawd, warm afternoon light.  
reads:  9.9–10.5   Clawd slumps, sad, eyes down. It has given up  
10.3–11.9  the butterfly drifts down from the top right, slow and lazy  
11.9–12.3  it lands on the daisy on Clawd's head. Clawd hasn't noticed  
12.35–13.1 Clawd feels it: eyes roll up, a small frozen take  
13.1–13.9  love: blush, hearts; the butterfly opens and closes its wings  
13.9–15.0  iris closes to Clawd and the butterfly, holds, shuts  
[transition out: iris]

Checks: event in every shot (pounce / chase / it lands); each read has its own time; transitions at every seam; no text; the ending (butterfly on the daisy) rhymes with the opening.
