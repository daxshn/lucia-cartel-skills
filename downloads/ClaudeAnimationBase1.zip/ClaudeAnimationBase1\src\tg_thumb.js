// tg_thumb.js: two thumbnails for the Thanksgiving video.
//   node render.mjs --loop=tgthumbA --stills=0.4 --out=out/tg/thumbA      (lineup, white page)
//   node render.mjs --loop=tgthumbB --stills=0.4 --out=out/tg/thumbB      (drama close-up)
const TGF = s => `900 ${s}px "Segoe UI Black", "Arial Black", Impact, sans-serif`;
const STILL = { dy: 0, sq: 0, rot: 0, dx: 0, squint: 0, emote: null };

LOOPS.tgthumbA = t => {
  boilSeed('ta bg'); paint(rectPts(-100, -100, W + 200, H + 200), { wash: '#FBF6EE', ink: null });
  for (let i = 0; i < 14; i++) { boilSeed('ta leaf' + i); const x = 40 + i * 140 + 40 * hash(i), y = i % 2 ? 40 : 1040; paint(starPts(x, y, 30, .5, 5, i), { wash: FALL.leaf[i % 4], ink: PAL.ink, sw: 1 }); }
  letter('EVERY TYPE OF PERSON', 960, 100, 138, '#1E1A22', { font: TGF(138), ink: false });
  boilSeed('ta band'); push(); translate(960, 240); rotate(-.025); paint(rrPts(-560, -70, 1120, 140, 36, 3), { wash: '#C8582E', ink: PAL.ink, sw: 3 }); pop();
  letter('AT THANKSGIVING', 960, 244, 96, '#FFFFFF', { font: TGF(96), rot: -.025, stroke: '#1E1A22', ink: false });
  const G = 1065, u = 38;
  const C = [['THE HOST', 'host', 'nervous', [-.6, .85], 'turkey'], ['THE CARVER', 'carver', 'determined', [-.6, .85], 'knife'], ['THE UNCLE', 'uncle', 'angry', [-.6, .6], null],
    ['THE AUNT', 'aunt', 'excited', [-.6, .85], 'ring'], ['iPAD KID', 'kid', 'bored', [-.6, .85], 'tablet'], ['GRANDMA', 'oldwoman', 'love', [-.6, .85], 'pie']];
  C.forEach(([label, lk, emo, arms, prop], i) => {
    const cx = 170 + i * 316, kid = lk === 'kid', uu = kid ? u * .72 : u;
    const o = { ...feel(emo, 0), ...STILL, look: lk, boilKey: 'ta' + i, aL: arms[0], aR: arms[1], ...(lk === 'oldwoman' ? { hat: 'bow', old: true } : {}) };
    if (prop) Object.assign(o, hold(prop, 'R', .3, prop === 'turkey' || prop === 'pie' ? 1.5 : 1.2));
    tall(cx, G, uu, o);
    letter(label, cx, kid ? 575 : 395, 40, '#1E1A22', { font: TGF(40), ink: false });
  });
};
LOOPS.tgthumbA.len = 1;

LOOPS.tgthumbB = t => {
  boilSeed('tb bg'); paint(rectPts(-100, -100, W + 200, H + 200), { wash: '#F2B067', ink: null });
  const C = [760, 560];
  for (let i = 0; i < 18; i++) { const a0 = i / 18 * TAU, a1 = a0 + TAU / 36; boilSeed('tb ray' + i); paint([C, [C[0] + Math.cos(a0) * 2200, C[1] + Math.sin(a0) * 2200], [C[0] + Math.cos(a1) * 2200, C[1] + Math.sin(a1) * 2200]], { wash: '#F7C98A', ink: null }); }
  glow(760, 520, 700, '#FFE3A8', .5);
  // grandma in the back, laughing with popcorn
  tall(1260, 1330, 46, { ...feel('laugh', 0), ...STILL, look: 'oldwoman', hat: 'bow', old: true, boilKey: 'tbg', ...hold('popcorn', 'R', .35, 2.2) });
  // the uncle, huge, furious, pointing
  tall(560, 1720, 82, { ...feel('furious', 0), ...STILL, eyes: 'angry', mouth: 'open', look: 'uncle', boilKey: 'tbu', aR: .75, aL: -.6, rot: .04 });
  // you, sweating, on the right
  tall(1640, 1560, 64, { ...feel('scared', 0), ...STILL, look: 'boy', boilKey: 'tby', aL: .9, aR: -.6, flip: true, emote: 'sweat', emoteK: 1 });
  boilSeed('tb anger'); emote('anger', 300, 250, 80, 1, .5); emote('anger', 820, 210, 60, 1, .9);
  // the table with the turkey across the bottom
  boilSeed('tb table'); paint(rectPts(-80, 900, 2080, 300), { wash: FALL.cloth, ink: PAL.ink, sw: 2 }); paint(rectPts(560, 900, 800, 300), { wash: FALL.runner, ink: null });
  boilSeed('tb turkey'); icon('turkey', 960, 860, 150);
  boilSeed('tb pie'); icon('pie', 300, 880, 70); boilSeed('tb pie2'); icon('pie', 1660, 880, 70);
  // text
  boilSeed('tb top'); push(); translate(1300, 120); rotate(.03); paint(rrPts(-590, -80, 1180, 160, 36, 3), { wash: '#1E1A22', washOp: 240, ink: null }); pop();
  letter('THANKSGIVING BE LIKE', 1300, 124, 100, '#FFD94A', { font: TGF(100), rot: .03, ink: false });
  boilSeed('tb tag'); push(); translate(1500, 300); rotate(.05); paint(rrPts(-280, -54, 560, 108, 28, 3), { wash: '#FFFFFF', ink: PAL.ink, sw: 3 }); pop();
  letter('NO POLITICS!', 1500, 304, 70, '#D2493A', { font: TGF(70), rot: .05, ink: false });
};
LOOPS.tgthumbB.len = 1;
