// butterfly.js: "The Butterfly", 15 s. See STORYBOARD.md.
//   A (0–4.6):    a butterfly lands on a daisy; Clawd creeps up and pounces.
//   B (4.6–9.6):  the chase: belly-flop, a jump, a run, a second leap. All miss.
//   C (9.6–15):   Clawd gives up; the butterfly lands on the daisy now stuck to Clawd's head.
(() => {
  const G = 880, U = 24, FX = 1250, FH = 175, BS = 40;
  const WIPE = ['#5E8F4E', '#E8C766'], LEAF = '#3F6B3A';
  const smooth = P => through(P.concat([P[0]]), 5);

  // ---------- the meadow (camX drives parallax; warm 0..1 = morning → afternoon; k scales the foreground) ----------
  function meadow(t, camX, warm, gy = G, k = 1) {
    const sky = mixCol('#A8D5EF', '#F6C6A0', warm), hillF = mixCol('#A9D0B4', '#E3CC96', warm * .7),
      hillM = mixCol('#8DBD72', '#BFBB62', warm * .6), grd = mixCol('#79AA5C', '#A6AA52', warm * .5);
    const px = f => (camX - 960) * f, qx = Math.floor((camX - 1300) / 500) * 500;
    boilSeed('sky'); paint(rectPts(qx - 300, -500, 3700, 2100), { wash: sky, ink: null });
    boilSeed('sun'); paint(ellPts(330 + px(.9), 170 + 120 * warm, 78, 78, 24, 1.5), { wash: mixCol(PAL.cream, PAL.ochre, .2 + .45 * warm), ink: null });
    for (let i = 0; i < 4; i++) {
      boilSeed('cloud' + i);
      const cx = hash(i + 5) * 2400 - 200 + px(.8) + t * 9, cy = 110 + hash(i + 9) * 200, w = 130 + 70 * hash(i);
      paint(ellPts(cx, cy, w, 42, 18, 4), { wash: PAL.cream, washOp: 205, ink: null });
      paint(ellPts(cx + w * .35, cy - 30, w * .55, 40, 16, 4), { wash: PAL.cream, washOp: 205, ink: null });
      paint(ellPts(cx - w * .4, cy - 16, w * .45, 32, 16, 4), { wash: PAL.cream, washOp: 205, ink: null });
    }
    for (let i = 0; i < 5; i++) {
      boilSeed('hf' + i);
      paint(ellPts(-300 + i * 820 + px(.6), gy + 60, 600, 250 + 70 * hash(i + 2), 36, 2), { wash: hillF, fill: mixCol(hillF, PAL.teal, .35), fillOp: 60, bleed: .1, tex: .5, ink: PAL.ink, sw: .6 });
    }
    for (let i = 0; i < 5; i++) {
      boilSeed('hm' + i);
      paint(ellPts(100 + i * 900 + px(.3), gy + 90, 660, 190 + 50 * hash(i + 12), 36, 2), { wash: hillM, fill: mixCol(hillM, LEAF, .4), fillOp: 60, bleed: .08, tex: .6, ink: PAL.ink, sw: .8 });
    }
    boilSeed('ground');
    paint(rectPts(qx - 300, gy - 26 * k, 3700, 900), { wash: grd, fill: mixCol(grd, LEAF, .5), fillOp: 70, bleed: .05, tex: .6, ink: null });
    for (let j = 0; j < 4; j++) {
      const x0 = Math.floor((camX - 1300) / 800) * 800 + j * 800;
      boilSeed('hz' + x0); inkLine([[x0, gy - 26 * k], [x0 + 400, gy - 28 * k], [x0 + 800, gy - 26 * k]], 1, PAL.ink, 'ink', .3);
    }
    const tc = mixCol(grd, LEAF, .9);
    for (let i = 0; i < 76; i++) {
      const x = -600 + i * 60 + hash(i) * 40; if (Math.abs(x - camX) > 1150) continue;
      boilSeed('tuft' + i);
      const row = i % 3, y = gy + (-22 + [0, 75, 165][row] + hash(i + 50) * 30) * k, h = (18 + 10 * hash(i + 20)) * k * (1 + row * .3), s = wob(t, .45, hash(i) * 3) * 5 * k;
      for (const d of [-1, 0, 1]) inkLine([[x + d * 7 * k, y], [x + d * 12 * k + s, y - h - 6 * hash(i + d)]], 1.2, tc, 'inkfine', .4);
    }
    for (let i = 0; i < 26; i++) {
      const x = -500 + i * 150 + hash(i + 7) * 90; if (Math.abs(x - camX) > 1150) continue;
      boilSeed('dot' + i);
      paint(ellPts(x, gy + (25 + hash(i + 3) * 190) * k, 7 * k, 6 * k, 8), { wash: [PAL.rose, PAL.cream, PAL.ochre][i % 3], ink: PAL.ink, sw: .5 });
    }
  }

  // ---------- the daisy ----------
  function daisyHead(x, y, r, sw = .7, rot = 0) {
    for (let i = 0; i < 7; i++) { const a = rot + i / 7 * TAU; paint(ellPts(x + Math.cos(a) * r * .62, y + Math.sin(a) * r * .62, r * .5, r * .3, 10, 0, a), { wash: PAL.cream, ink: PAL.ink, sw }); }
    paint(ellPts(x, y, r * .36, r * .36, 12), { wash: PAL.ochre, ink: PAL.ink, sw });
  }
  const daisySway = t => 7 * Math.sin(t * 1.3);
  function daisy(t, bend = 0) {
    boilSeed('daisy');
    const sx = daisySway(t) + bend, top = [FX + sx, G - FH + Math.abs(bend) * .3];
    inkLine([[FX, G - 10], [FX + sx * .3, G - FH * .55], top], 1.7, LEAF, 'ink', .6);
    paint(smooth([[FX, G - 60], [FX + 34, G - 96], [FX + 52, G - 88], [FX + 30, G - 66]]), { wash: '#5E9450', ink: LEAF, sw: .7 });
    daisyHead(top[0], top[1], 30, .8, .2);
  }
  // the same daisy, stuck to Clawd's head: a draw() hook in body-local space
  const headDaisy = lx => (u, sw) => {
    inkLine([[(lx + .5) * u, -7.9 * u], [(lx + .3) * u, -8.9 * u], [lx * u, -9.7 * u]], sw * .9, LEAF, 'ink', .6);
    daisyHead(lx * u, -9.7 * u, 1.25 * u, sw * .5, .2);
  };
  // world position of a body-local point, from the same pose clawd() gets
  function bodyPt(x, y, u, o, lx, ly) {
    const sq = o.sq || 0, r = o.rot || 0, X = lx * u * (1 + sq * .6), Y = ly * u * (1 - sq);
    return [x + (o.dx || 0) * u + X * Math.cos(r) - Y * Math.sin(r), y + (o.dy || 0) * u + X * Math.sin(r) + Y * Math.cos(r)];
  }

  // ---------- the butterfly ----------
  // open 0..1 = wings folded → spread. Flat: the wings just narrow as they close.
  function butterfly(x, y, s, open, rot = 0) {
    boilSeed('butterfly');
    const w = lerp(.16, 1, clamp(open)), sw = clamp(s / 55, .5, 1.1);
    push(); translate(x, y); rotate(rot);
    for (const d of [-1, 1]) {
      const m = P => smooth(P.map(([a, b]) => [d * a * s * w, b * s]));
      paint(m([[.04, .05], [.7, .08], [.9, .5], [.6, .92], [.2, .62]]), { wash: '#B79AE0', ink: PAL.ink, sw });
      paint(m([[.02, -.08], [.3, -.9], [.9, -1.08], [1.2, -.55], [.85, -.02], [.2, .08]]), { wash: '#8A63C8', ink: PAL.ink, sw });
      paint(ellPts(d * .78 * s * w, -.62 * s, .17 * s * w, .17 * s, 10), { wash: PAL.cream, ink: null });
      paint(ellPts(d * .56 * s * w, .48 * s, .1 * s * w, .1 * s, 8), { wash: PAL.cream, ink: null });
      inkLine([[0, -.36 * s], [d * .13 * s, -.62 * s], [d * .27 * s, -.74 * s]], sw * .7, PAL.ink, 'inkfine', .5);
    }
    paint(ellPts(0, 0, .09 * s, .42 * s, 12), { wash: PAL.ink, ink: null });
    pop();
  }
  // Flight path for shots A and B, in video time: [t, [x, y, flutter]]. flutter 0 = sitting still.
  const SIT = G - FH - BS * .3;
  const PATH = [[.45, [1840, 100, 1]], [1.0, [1380, 330, 1]], [1.45, [1010, 440, 1]], [1.8, [770, 600, 1]], [2.3, [900, 420, 1]], [2.75, [1150, 520, 1]],
    [3.1, [FX, SIT, 0]], [4.38, [FX, SIT, 0]], [4.62, [1350, 400, 1]], [5.3, [1250, 520, 1]], [6.5, [1250, 520, 1]], [6.68, [1345, 365, 1]],
    [7.1, [1345, 380, 1]], [7.7, [1700, 470, 1]], [8.2, [2100, 500, 1]], [8.45, [2120, 290, 1]], [8.85, [1880, 320, 1]], [9.6, [1850, 390, 1]]];
  const flyAt = (t, path) => { const [x, y, a] = kf(t, path); return [x + a * 10 * Math.sin(t * 9.1) + (1 - a) * daisySway(t), y + a * 17 * Math.sin(t * 12.3 + 1), a]; };
  const wings = (t, a) => lerp(.6 + .4 * Math.sin(t * TAU * .7), .5 + .5 * Math.sin(t * TAU * 5.5), a);
  function flyer(t, path = PATH, s = BS) {
    const [x, y, a] = flyAt(t, path), vx = flyAt(t + .04, path)[0] - flyAt(t - .04, path)[0];
    butterfly(x, y, s, wings(t, a), clamp(vx * .012, -.45, .45) * a);
  }

  function puffs(x, y, age, n = 6, spread = 150, key = 'puff') {
    if (age < 0 || age > .7) return;
    boilSeed(key);
    const k = easeOut(age / .7);
    for (let i = 0; i < n; i++) {
      const d = (i - (n - 1) / 2) / n * 2;
      paint(ellPts(x + d * spread * (.4 + k), y - 12 - 46 * k * (1 - Math.abs(d) * .6), 26 * (1 - k * .6) + 8, 20 * (1 - k * .6) + 6, 12, 2), { wash: PAL.cream, washOp: 230 * (1 - k), ink: PAL.ink, sw: .5 * (1 - k) + .1 });
    }
  }

  // ---------- shot A: the pounce ----------
  const tLeap = 4.48, tHit = 4.85;
  const leapPose = t => { const k = seg(t, tLeap, tHit), p = arcPt([900, G], [1225, G], 175, k); return { x: p[0], view: 'side', dy: (p[1] - G) / U, sq: -.2, rot: .2 + .55 * k, smear: .5, smearDir: 1, aL: 1.1 }; };

  function shotPounce(t, lt, dur) {
    const camX = kf(t, [[0, 900], [3.2, 940], [4.6, 1080]]);
    camBegin(camX, 545 + 6 * Math.sin(t * .9), kf(t, [[0, 1.05], [4.6, 1.12]]));
    meadow(t, camX, 0);
    daisy(t);
    const mood = emotions(t, [[0, 'bored'], [1.85, 'surprised', { lookX: .8, lookY: -.5 }], [2.4, 'starstruck', { lookX: .9, lookY: -.2 }], [3.25, 'mischief', { lookX: .9 }]]);
    let x = lerp(560, 900, ease(seg(t, 3.52, 4.25))), pose = {};
    const walk = (x - 560) / (3 * U);
    if (t < 3.4) pose = {};
    else if (t < 3.52) pose = turn(t, 3.4, 3.52, 0, .25);
    else if (t < 4.25) pose = { view: 'side', walk, sq: .1, dy: -.35 * Math.abs(Math.sin(walk * TAU)), rot: .06, aL: .3 + .2 * Math.sin(walk * TAU) };
    else if (t < tLeap) { const k = ease(seg(t, 4.25, tLeap)); pose = { view: 'side', sq: .1 + .2 * k, dx: -.8 * k, dy: 0, rot: .06 - .22 * k, aL: .3 - .9 * k }; }
    else { pose = leapPose(t); x = pose.x; }
    clawd(x, G, U, { ...mood, ...pose });
    flyer(t);
    const eye = toScreen(560, G - 4 * U);
    camEnd();
    boilSeed('transition');
    if (lt < .5) iris(...eye, lerp(0, 1500, easeIn(lt / .5)));
  }

  // ---------- shot B: the chase ----------
  function shotChase(t, lt, dur) {
    const tUp = 1.05, j1 = [1.7, 2.3], tTurn = 2.6, tRun = 2.72, j2 = [3.6, 3.95], tStop = 4.3;
    const shake = lt > .25 ? shakeXY(t, 9 * Math.exp(-(lt - .25) * 7)) : [0, 0];
    const camX = kf(lt, [[0, 1080], [1, 1200], [2.6, 1260], [4.35, 2020]]);
    camBegin(camX + shake[0], kf(lt, [[0, 545], [1.6, 530], [2.0, 480], [2.6, 520]]) + shake[1], kf(lt, [[0, 1.12], [.7, 1], [dur, 1.04]]));
    meadow(t, camX, .15 * seg(lt, 2.5, 5));
    if (lt < .25) daisy(t, 60 * easeIn(seg(lt, .12, .25)));

    const mood = emotions(lt, [[-2, 'mischief', { lookX: .9 }], [.25, 'ko'], [tUp, 'determined', { lookX: .15, lookY: -.9 }], [4.14, 'confused', { lookX: .9 }]]);
    const x = lt < tRun ? 1225 : lerp(1225, 2130, ease(seg(lt, tRun, tStop)));
    let pose;
    if (lt < .25) pose = leapPose(t);
    else if (lt < .33) pose = { ...turn(lt, .25, .33, .25, 0), sq: (mood.sq || 0) + .25 };
    else if (lt < tTurn) {
      const j = jump(lt, ...j1, 5.5), up = easeOut(seg(lt, j1[0] - .05, j1[0] + .25)) * (1 - ease(seg(lt, j1[1], j1[1] + .3)));
      pose = { sq: (mood.sq || 0) + j.sq + .25 * Math.exp(-(lt - .25) * 5), dy: (lt < tUp ? 0 : mood.dy || 0) + j.dy };
      if (lt > j1[0] - .1) { pose.aL = lerp(mood.aL ?? .2, 1.5, up); pose.aR = lerp(mood.aR ?? .2, 1.45, easeOut(seg(lt, j1[0], j1[0] + .3)) * (1 - ease(seg(lt, j1[1] + .05, j1[1] + .4)))); }
    } else if (lt < tRun) pose = turn(lt, tTurn, tRun, 0, .25);
    else if (lt < 4.05) {
      const walk = (x - 1225) / (3.3 * U), j = jump(lt, ...j2, 4.2), skid = ease(seg(lt, j2[1], 4.05));
      pose = { view: 'side', walk: lt > j2[0] && lt < j2[1] ? .2 : walk, dy: (lt < j2[0] ? -.7 * Math.abs(Math.sin(walk * TAU)) : 0) + j.dy, sq: j.sq,
        rot: lerp(.13, -.2, skid), aL: lerp(.9 + .3 * Math.sin(walk * TAU * 2), 1.4, seg(lt, j2[0] - .1, j2[0] + .15)), smear: .35 * seg(lt, tRun, tRun + .3) * (1 - skid * .5), smearDir: 1 };
    } else if (lt < 4.17) pose = { ...turn(lt, 4.05, 4.17, .25, 0), rot: -.2 * (1 - seg(lt, 4.05, 4.17)) };
    else pose = {};
    const side = pose.view === 'side';
    clawd(x, G, U, { ...mood, ...pose, x: undefined, draw: lt >= .25 ? headDaisy(side ? -1.3 : -2) : null });
    puffs(1225, G, lt - .25, 7, 190, 'puffA');
    puffs(x + 40, G, lt - j2[1], 4, 90, 'puffB');
    flyer(t);
    camEnd();
    boilSeed('transition');
    if (lt > dur - .3) brushWipe((lt - (dur - .3)) / .6, WIPE);
  }

  // ---------- shot C: it comes to you ----------
  function shotLanding(t, lt, dur) {
    const gy = 950, u = 44, x = 960, S = 64, tLand = 2.3, tFeel = 2.75, tLove = 3.5, tIris = 4.2;
    camBegin(960 + 10 * Math.sin(lt * .7), 560 - 5 * lt, 1 + .012 * lt);
    meadow(t, 1500, .75, gy, 1.7);
    const mood = emotions(lt, [[-2, 'sad', { emote: null }], [tFeel, 'surprised', { emote: null, lookX: -.55, lookY: -1 }], [tLove, 'love']], { take: .4 });
    clawd(x, gy, u, { ...mood, draw: headDaisy(-2) });
    // the butterfly drifts down and settles on the daisy; from then on it rides Clawd's head
    const seat = bodyPt(x, gy, u, mood, -2, -9.7 - .3 * S / u);
    const fly = flyAt(lt, [[.6, [1800, -90, 1]], [1.2, [1500, 230, 1]], [1.75, [1180, 330, 1]], [tLand, [seat[0], seat[1] - 20, .25]]]);
    const k = ease(seg(lt, 1.75, tLand)), a = 1 - ease(seg(lt, 1.9, tLand + .1));
    const p = [lerp(fly[0], seat[0], k), lerp(fly[1], seat[1], k)];
    const hello = lt > tLove + .5 ? Math.exp(-(lt - tLove - .5) * 3) : 0;   // a happy flutter back at Clawd
    const open = lerp(.6 + .4 * Math.sin(lt * TAU * .7), .5 + .5 * Math.sin(lt * TAU * 5.5), Math.max(a, hello));
    if (lt > .5) butterfly(p[0], p[1], S, open, -.25 * a);
    const eye = toScreen(x - .5 * u, gy - 6.6 * u);
    camEnd();
    boilSeed('transition');
    if (lt < .3) brushWipe(.5 + lt / .6, WIPE);
    if (lt > tIris) {
      const r = lt < tIris + .5 ? lerp(1500, 330, ease(seg(lt, tIris, tIris + .5))) : lt < dur - .3 ? lerp(330, 310, seg(lt, tIris + .5, dur - .3)) : lerp(310, 0, easeIn(seg(lt, dur - .3, dur - .05)));
      iris(...eye, r);
    }
  }

  shots([[0, shotPounce], [4.6, shotChase], [9.6, shotLanding]]);
})();
