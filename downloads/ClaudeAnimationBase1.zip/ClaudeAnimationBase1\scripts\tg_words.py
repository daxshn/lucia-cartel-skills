"""Join voiceover parts (with a short gap) into one file, then time every word with faster-whisper.
    <faceless venv python> scripts/tg_words.py out/tg assets/tg/part1.mp3 assets/tg/part2.mp3 ...
Writes out/tg/voiceover.wav and out/tg/words.json (same format as out/vo/words.json).
"""
import json, os, subprocess, sys
out, parts = sys.argv[1], sys.argv[2:]
os.makedirs(out, exist_ok=True)
wav = f'{out}/voiceover.wav'
inputs, filt = [], []
for i, p in enumerate(parts):
    inputs += ['-i', p]
    filt.append(f'[{i}:a]aresample=44100,aformat=channel_layouts=mono[a{i}]')
gap = 'anullsrc=r=44100:cl=mono,atrim=0:0.8[g]'
chain = ''.join(f'[a{i}]' + ('[g%d]' % i if i < len(parts) - 1 else '') for i in range(len(parts)))
gaps = ';'.join(f'anullsrc=r=44100:cl=mono,atrim=0:0.8[g{i}]' for i in range(len(parts) - 1))
n = len(parts) * 2 - 1
fc = ';'.join(filt) + (';' + gaps if gaps else '') + f';{chain}concat=n={n}:v=0:a=1[out]'
subprocess.run(['ffmpeg', '-v', 'error', '-y', *inputs, '-filter_complex', fc, '-map', '[out]', wav], check=True)
from faster_whisper import WhisperModel
m = WhisperModel('small.en', device='cpu', compute_type='int8')
segs, info = m.transcribe(wav, word_timestamps=True, beam_size=5, language='en', vad_filter=False)
words = []
for s in segs:
    words.append({'s': round(s.start, 2), 'e': round(s.end, 2), 't': s.text.strip(), 'w': [[round(w.start, 2), round(w.end, 2), w.word.strip()] for w in s.words]})
json.dump(words, open(f'{out}/words.json', 'w', encoding='utf-8'), indent=0)
print(f'{info.duration:.1f}s, {sum(len(s["w"]) for s in words)} words')
