// tall.js: a taller, fashion-cartoon person (~16u tall: feet 0, hip -7u, shoulders -11.9u, head centre -14.3u, top -16.2u),
// hand painted with p5.brush. Takes the same options as clawd()/human() (emotions(), hold() props, hats, emotes,
// walk/view/flip), plus `look`: an outfit spec, or a key into LOOKS. Defaults to LOOKS[boilKey].
//   look = { body: 'f'|'m', skin, eye, hair: { style, col }, top: { kind, col, col2 }, bottom: { kind, col },
//            legs: 'bare'|'tights'|'fishnet'|'socks'|'thigh', legCol, shoes: { kind, col }, acc: [...] }
//   hair styles: long, wavy, ponytail, bob, short, messy, buns, curly    tops: hoodie, tee, crop, tank, sweater, jacket,
//   dress, gown, striped    bottoms: jeans, skirt, shorts, leggings, trousers, none    shoes: sneaker, boot, heel, flat
//   acc: catears, choker, glasses, headphones, earrings, bag
const LOOKS = {
  introvert: { body: 'f', skin: '#F3D2BC', eye: '#4A4A6A', hair: { style: 'messy', col: '#1F1B24' }, top: { kind: 'hoodie', col: '#4A4A55' }, bottom: { kind: 'jeans', col: '#3A3F4F' }, shoes: { kind: 'sneaker', col: '#2B2738' }, acc: ['headphones'] },
  extrovert: { body: 'f', skin: '#F6D3B5', eye: '#4F86C2', hair: { style: 'long', col: '#F0D27A' }, top: { kind: 'crop', col: '#2B2738' }, bottom: { kind: 'skirt', col: '#2B2738' }, legs: 'bare', shoes: { kind: 'sneaker', col: '#F2EEE6' }, acc: ['earrings'] },
  egirl:     { body: 'f', skin: '#F1CDB8', eye: '#7A4FB8', hair: { style: 'bob', col: '#8A5FC8' }, top: { kind: 'striped', col: '#2B2738', col2: '#E9E2EE' }, bottom: { kind: 'shorts', col: '#2B2738' }, legs: 'fishnet', shoes: { kind: 'boot', col: '#2B2738' }, acc: ['choker'] },
  gym:       { body: 'f', skin: '#D9A27A', eye: '#5A3A2A', hair: { style: 'ponytail', col: '#2A1E1A' }, top: { kind: 'tank', col: '#2B2738' }, bottom: { kind: 'leggings', col: '#2B2738' }, shoes: { kind: 'sneaker', col: '#F2EEE6' } },
  catgirl:   { body: 'f', skin: '#F6D3B5', eye: '#C84F7A', hair: { style: 'long', col: '#F2A0C0' }, top: { kind: 'dress', col: '#F4B0C8' }, bottom: { kind: 'none' }, legs: 'thigh', legCol: '#F2EEE6', shoes: { kind: 'flat', col: '#E07A9A' }, acc: ['catears', 'choker'] },
  elegant:   { body: 'f', skin: '#F1C7A6', eye: '#5A3A2A', hair: { style: 'wavy', col: '#B8402E' }, top: { kind: 'gown', col: '#B8242E' }, bottom: { kind: 'none' }, shoes: { kind: 'heel', col: '#B8242E' }, acc: ['earrings', 'bag'] },
  boy:       { body: 'm', skin: '#F1C29C', eye: '#4A3020', hair: { style: 'short', col: '#2E2224' }, top: { kind: 'jacket', col: '#4F6E9A', col2: '#F2EEE6' }, bottom: { kind: 'jeans', col: '#33405E' }, shoes: { kind: 'sneaker', col: '#F2EEE6' } },
  girl:      { body: 'f', skin: '#F6CDA9', eye: '#6A4024', hair: { style: 'wavy', col: '#5B3122' }, top: { kind: 'sweater', col: '#E8A0AE' }, bottom: { kind: 'skirt', col: '#5A6A9A' }, legs: 'tights', legCol: '#3A3448', shoes: { kind: 'boot', col: '#6B4030' } },
};

Object.assign(LOOKS, {
  boy2:     { body: 'm', skin: '#E8B48C', eye: '#3A2A20', hair: { style: 'short', col: '#1E1A22' }, top: { kind: 'tee', col: '#C8443C' }, bottom: { kind: 'jeans', col: '#2E3044' }, shoes: { kind: 'sneaker', col: '#F2EEE6' } },
  boy3:     { body: 'm', skin: '#C98D63', eye: '#3A2A20', hair: { style: 'curly', col: '#1E1A22' }, top: { kind: 'hoodie', col: '#5E8F4E' }, bottom: { kind: 'jeans', col: '#3A3F4F' }, shoes: { kind: 'sneaker', col: '#2B2738' } },
  gymboy:   { body: 'm', skin: '#D9A27A', eye: '#3A2A20', hair: { style: 'short', col: '#2A1E1A' }, top: { kind: 'tank', col: '#3E6FA8' }, bottom: { kind: 'shorts', col: '#2B2738' }, shoes: { kind: 'sneaker', col: '#E3A33B' } },
  introboy: { body: 'm', skin: '#F1C8AE', eye: '#3A3A50', hair: { style: 'messy', col: '#2A2430' }, top: { kind: 'hoodie', col: '#4A4A55' }, bottom: { kind: 'jeans', col: '#33384A' }, shoes: { kind: 'sneaker', col: '#2B2738' } },
  pjboy:    { body: 'm', skin: '#F1C29C', eye: '#4A3020', hair: { style: 'messy', col: '#2E2224' }, top: { kind: 'tee', col: '#7FA6C9' }, bottom: { kind: 'trousers', col: '#4F6E9A' }, shoes: { kind: 'flat', col: '#C9965F' } },
  detboy:   { body: 'm', skin: '#F1C29C', eye: '#4A3020', hair: { style: 'short', col: '#2E2224' }, top: { kind: 'tee', col: '#8A8FA0' }, bottom: { kind: 'trousers', col: '#3B3F55' }, shoes: { kind: 'sneaker', col: '#2B2738' } },
  oldman:   { body: 'm', skin: '#EDC3A0', eye: '#4A3020', hair: { style: 'short', col: '#D6D2DC' }, top: { kind: 'sweater', col: '#9A6A44' }, bottom: { kind: 'trousers', col: '#6B6880' }, shoes: { kind: 'flat', col: '#4A3428' }, acc: ['glasses'] },
  girl2:    { body: 'f', skin: '#EFC09C', eye: '#4A3020', hair: { style: 'ponytail', col: '#3A2418' }, top: { kind: 'tee', col: '#F2C14E' }, bottom: { kind: 'jeans', col: '#4F6E9A' }, shoes: { kind: 'sneaker', col: '#F2EEE6' } },
  sweet:    { body: 'f', skin: '#F6D3B5', eye: '#6A4024', hair: { style: 'bob', col: '#6B3A28' }, top: { kind: 'dress', col: '#F4A8BC' }, bottom: { kind: 'none' }, legs: 'socks', legCol: '#F2EEE6', shoes: { kind: 'flat', col: '#C8566A' } },
  foodgirl: { body: 'f', skin: '#E8B48C', eye: '#4A3020', hair: { style: 'buns', col: '#2A1E1A' }, top: { kind: 'sweater', col: '#F2A65A' }, bottom: { kind: 'jeans', col: '#3A4A6A' }, shoes: { kind: 'sneaker', col: '#F2EEE6' } },
  detgirl:  { body: 'f', skin: '#F6CDA9', eye: '#3A5A40', hair: { style: 'long', col: '#5B3122' }, top: { kind: 'jacket', col: '#B08A5A', col2: '#F2EEE6' }, bottom: { kind: 'trousers', col: '#3B3550' }, shoes: { kind: 'boot', col: '#3B2A22' } },
  instagirl:{ body: 'f', skin: '#F1C7A6', eye: '#5A3A2A', hair: { style: 'wavy', col: '#2A1E1A' }, top: { kind: 'crop', col: '#F2EEE6' }, bottom: { kind: 'jeans', col: '#5A6A9A' }, shoes: { kind: 'heel', col: '#2B2738' }, acc: ['earrings'] },
  pjgirl:   { body: 'f', skin: '#F6CDA9', eye: '#6A4024', hair: { style: 'buns', col: '#5B3122' }, top: { kind: 'sweater', col: '#C9B6E4' }, bottom: { kind: 'trousers', col: '#8E7BB8' }, shoes: { kind: 'flat', col: '#E8A0AE' } },
  oldwoman: { body: 'f', skin: '#F1C8A8', eye: '#5A3A2A', hair: { style: 'bun', col: '#D6D2DC' }, top: { kind: 'sweater', col: '#8A6FB8' }, bottom: { kind: 'skirt', col: '#5A4A6A' }, legs: 'tights', legCol: '#8A8296', shoes: { kind: 'flat', col: '#4A3428' }, acc: ['glasses', 'earrings'] },
  friendC:  { body: 'm', skin: '#C98D63', eye: '#3A2A20', hair: { style: 'short', col: '#231E26' }, top: { kind: 'tee', col: '#E3A33B' }, bottom: { kind: 'jeans', col: '#57483B' }, shoes: { kind: 'sneaker', col: '#2B2738' } },
  friendD:  { body: 'm', skin: '#8E5C40', eye: '#2A1A14', hair: { style: 'curly', col: '#1E1A22' }, top: { kind: 'jacket', col: '#6FA06A', col2: '#F2EEE6' }, bottom: { kind: 'trousers', col: '#3B3F55' }, shoes: { kind: 'sneaker', col: '#F2EEE6' } },
});
const CROWD_LOOKS = ['introvert', 'extrovert', 'egirl', 'gym', 'catgirl', 'elegant', 'boy2', 'boy3', 'gymboy', 'girl2', 'sweet', 'foodgirl', 'instagirl', 'friendD'];
function lookFor(name) {
  if (LOOKS[name]) return name;
  const m = { A: 'boy', B: 'girl', C: 'friendC', D: 'friendD' }[name]; if (m) return m;
  let h = 0; for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) % 997;
  return CROWD_LOOKS[h % CROWD_LOOKS.length];
}

Object.assign(LOOKS, {
  host:    { body: 'f', skin: '#F1C29C', eye: '#5A3A2A', hair: { style: 'bun', col: '#6B3A28' }, top: { kind: 'sweater', col: '#C8566A' }, bottom: { kind: 'trousers', col: '#4A4060' }, shoes: { kind: 'flat', col: '#5A3A2A' }, acc: ['apron', 'earrings'] },
  carver:  { body: 'm', skin: '#EDBE98', eye: '#4A3020', hair: { style: 'short', col: '#6A5A50' }, top: { kind: 'sweater', col: '#8A5A3C' }, bottom: { kind: 'trousers', col: '#3E3A4A' }, shoes: { kind: 'flat', col: '#3A2A22' }, acc: ['glasses'] },
  uncle:   { body: 'm', skin: '#E8B48C', eye: '#3A2A20', hair: { style: 'short', col: '#3A2A20' }, top: { kind: 'jacket', col: '#5A6E3A', col2: '#E9DCC4' }, bottom: { kind: 'jeans', col: '#2E3044' }, shoes: { kind: 'boot', col: '#5A3A22' }, acc: ['mustache'] },
  aunt:    { body: 'f', skin: '#F3CBA8', eye: '#4A6A3A', hair: { style: 'wavy', col: '#B07A3A' }, top: { kind: 'dress', col: '#8A4FA0' }, bottom: { kind: 'none' }, legs: 'tights', legCol: '#4A3A5A', shoes: { kind: 'heel', col: '#4A2A4A' }, acc: ['glasses', 'earrings', 'bag'] },
  kid:     { body: 'm', skin: '#F6D3B5', eye: '#4A6A9A', hair: { style: 'messy', col: '#B9774A' }, top: { kind: 'hoodie', col: '#3E9AA8' }, bottom: { kind: 'jeans', col: '#3A4A6A' }, shoes: { kind: 'sneaker', col: '#D2493A' } },
  fan:     { body: 'm', skin: '#C98D63', eye: '#3A2A20', hair: { style: 'short', col: '#231E26' }, top: { kind: 'tee', col: '#2E5AA8' }, bottom: { kind: 'jeans', col: '#3A3F4F' }, shoes: { kind: 'sneaker', col: '#F2EEE6' } },
  piegirl: { body: 'f', skin: '#EFC09C', eye: '#4A3020', hair: { style: 'ponytail', col: '#3A2418' }, top: { kind: 'sweater', col: '#D9A23A' }, bottom: { kind: 'jeans', col: '#4F6E9A' }, shoes: { kind: 'boot', col: '#6B4030' } },
  vegan:   { body: 'f', skin: '#F6D3B5', eye: '#3A6A40', hair: { style: 'buns', col: '#3A2418' }, top: { kind: 'tee', col: '#7FB069' }, bottom: { kind: 'trousers', col: '#6B5A4A' }, shoes: { kind: 'sneaker', col: '#F2EEE6' }, acc: ['earrings'] },
  grandpa: { body: 'm', skin: '#EDC3A0', eye: '#4A3020', hair: { style: 'short', col: '#D6D2DC' }, top: { kind: 'sweater', col: '#7A6A5A' }, bottom: { kind: 'trousers', col: '#5A5868' }, shoes: { kind: 'flat', col: '#4A3428' }, acc: ['glasses'] },
  late:    { body: 'm', skin: '#C98D63', eye: '#3A2A20', hair: { style: 'curly', col: '#1E1A22' }, top: { kind: 'jacket', col: '#2B2738', col2: '#D2493A' }, bottom: { kind: 'jeans', col: '#3A3F4F' }, shoes: { kind: 'sneaker', col: '#F2EEE6' } },
});

function tall(x, y, u, o = {}) {
  const id = o.boilKey ?? 'tall', rs = p => boilSeed(`tall ${id} ${p}`);
  const L = typeof o.look === 'object' ? o.look : LOOKS[o.look || id] || LOOKS.girl;
  const F = L.body !== 'm';
  x += (o.dx || 0) * u * .5;
  const view = o.view || 'front', side = view === 'side', back = view === 'back' || view === 'qback';
  const dy = (o.dy || 0) * u * .8, sq = ((o.sq || 0) + (o.take || 0)) * .45;
  const sw = clamp(u / 18, .4, 2.2), J = u * .03;
  let skin = L.skin;
  if (o.tint && (o.tintK ?? 1) > 0) skin = mixCol(skin, TINT[o.tint] || o.tint, .28 * clamp(o.tintK ?? 1));
  const skinDk = mixCol(skin, '#8A4A3A', .28), hairC = o.old ? '#D6D2DC' : L.hair.col, hairDk = mixCol(hairC, PAL.ink, .32);
  const P = pts => pts.map(([a, b]) => [a * u, b * u]);
  const ink = (w = 1) => ({ ink: PAL.ink, sw: sw * w });
  const HC = -14.3, HRX = 1.55, HRY = 1.8, top = L.top || {}, bot = L.bottom || {}, acc = L.acc || [];
  const fcx = side ? .55 : view === 'q' ? .3 : 0;   // face offset toward the heading (in u)
  const fw = side ? .7 : view === 'q' ? .88 : 1;

  rs('shadow');
  if (!o.noShadow) { const f = 1 - Math.min(.5, Math.abs(o.dy || 0) * .05); paint(ellPts(x, y + u * .12, u * (side ? 1.9 : 2.4) * f, u * .5 * f, 20), { fill: PAL.ink, fillOp: 80, bleed: .25, tex: .3, border: .1, ink: null }); }

  push(); translate(x, y + dy); if (o.rot) rotate(o.rot * .5);
  scale((o.flip ? -1 : 1) * (o.sx ?? 1) * (1 + sq * .5), (o.sy ?? 1) * (1 - sq));

  // ---------- legs ----------
  const HIP = -7, seat = o.sit ? (typeof o.sit === 'number' ? o.sit : 3.5) : 0, legBase = L.legs === 'tights' || L.legs === 'fishnet' ? (L.legCol || '#2B2738') : skin;
  const pants = { jeans: 1, leggings: 1, trousers: 1 }[bot.kind];
  const gx = side ? [0, 0] : F ? [-.62, .62] : [-.72, .72];
  const legPts = [];
  [0, 1].forEach(i => {
    let lx = gx[i], lift = 0, knee = 0;
    if (o.walk != null) { const ph = (o.walk + (i ? .5 : 0)) * TAU; if (side) { lx += Math.sin(ph) * 1.3; lift = Math.max(0, Math.cos(ph)) * .6; knee = Math.max(0, Math.cos(ph)) * .5; } else lift = Math.max(0, Math.sin(ph)) * .45; }
    if (o.sit) { legPts.push({ i, pts: [[gx[i] * 1.15, -seat], [gx[i] * 1.18, -seat * .5 - .3], [gx[i] * 1.15, -.55]], sit: true }); return; }
    legPts.push({ i, pts: [[gx[i] * .9, HIP + .1], [lx * .95 + knee * .4, -3.7 - lift * .6], [lx, -.55 - lift]] });
  });
  legPts.forEach(({ i, pts, sit }) => {
    rs('leg' + i);
    const far = side && i === 1, c = pants ? bot.col : legBase, cc = far ? mixCol(c, PAL.ink, .2) : c;
    if (sit) paint(ellPts(pts[0][0] * u, (-seat - .15) * u, .8 * u, .62 * u, 14), { wash: pants ? bot.col : ['dress', 'gown'].includes(top.kind) ? top.col : bot.kind === 'skirt' || bot.kind === 'shorts' ? bot.col : skin, washOp: 255, ...ink(.7) });
    paint(ribbon(P(pts), (pants ? 1.2 : 1.0) * u, (pants ? .82 : .58) * u), { wash: cc, washOp: 255, fill: mixCol(cc, PAL.ink, .25), fillOp: 40, tex: .5, ...ink(.75) });
    if (!pants && L.legs === 'fishnet') { const [a, b, c2] = pts; for (let k = 1; k < 9; k++) { const t = k / 9, p = t < .5 ? [lerp(a[0], b[0], t * 2), lerp(a[1], b[1], t * 2)] : [lerp(b[0], c2[0], t * 2 - 1), lerp(b[1], c2[1], t * 2 - 1)], w = lerp(.42, .26, t); inkLine(P([[p[0] - w, p[1] - .2], [p[0] + w, p[1] + .2]]), sw * .35, PAL.ink, 'inkfine', 0); inkLine(P([[p[0] - w, p[1] + .2], [p[0] + w, p[1] - .2]]), sw * .35, PAL.ink, 'inkfine', 0); } }
    if (!pants && (L.legs === 'thigh' || L.legs === 'socks')) { const [, b, c2] = pts, s0 = L.legs === 'thigh' ? [lerp(pts[0][0], b[0], .55), lerp(pts[0][1], b[1], .55)] : [lerp(b[0], c2[0], .55), lerp(b[1], c2[1], .55)]; paint(ribbon(P(L.legs === 'thigh' ? [s0, b, c2] : [s0, c2]), (L.legs === 'thigh' ? .84 : .66) * u, .6 * u), { wash: L.legCol || PAL.cream, washOp: 255, ...ink(.7) }); }
    // shoe
    const f = pts[2], sh = L.shoes || {}, scol = far ? mixCol(sh.col || PAL.ink, PAL.ink, .2) : sh.col || '#2B2738', fdx = side ? .45 : (i ? .15 : -.15);
    if (sh.kind === 'boot') paint(P([[f[0] - .42, f[1] - 1.3], [f[0] + .42, f[1] - 1.3], [f[0] + .45, f[1] + .2], [f[0] + .45 + fdx + (side ? .5 : 0), f[1] + .3], [f[0] + .45 + fdx + (side ? .5 : 0), f[1] + .55], [f[0] - .5, f[1] + .55]]), { wash: scol, washOp: 255, ...ink(.7), curv: .3 });
    else if (sh.kind === 'heel') { paint(P([[f[0] - .3, f[1] - .1], [f[0] + .3 + (side ? .6 : 0), f[1] + .25], [f[0] + .3 + (side ? .6 : 0), f[1] + .5], [f[0] - .2, f[1] + .3], [f[0] - .35, f[1] + .55]]), { wash: scol, washOp: 255, ...ink(.7) }); }
    else paint(ellPts((f[0] + fdx) * u, (f[1] + .3) * u, (side ? .75 : .55) * u, .33 * u, 14, J), { wash: scol, washOp: 255, ...ink(.7) });
    if (sh.kind === 'sneaker') inkLine(P([[f[0] + fdx - .45, f[1] + .45], [f[0] + fdx + .45, f[1] + .45]]), sw * .5, PAL.ink, 'inkfine', 0);
  });

  const lift = o.sit ? 7 - seat - .25 : 0;
  translate(0, lift * u);

  // ---------- hair behind everything ----------
  rs('hairback');
  const hs = o.old ? (F ? 'bun' : 'old') : L.hair.style;
  const hairFill = { wash: hairC, washOp: 255, fill: hairDk, fillOp: 70, bleed: .05, tex: .7, ...ink(.9), curv: .5 };
  if (hs === 'long' || hs === 'wavy') {
    const end = hs === 'long' ? -9.6 : -10.4, w = hs === 'wavy' ? 2.15 : 1.95, wv = hs === 'wavy' ? .25 : 0;
    const pts = back || !side
      ? [[-1.7, -15.2], [-w, -13.4], [-w - wv, -12], [-w + wv, -11.2], [-w * .9, end], [0, end - .2], [w * .9, end], [w - wv, -11.2], [w + wv, -12], [w, -13.4], [1.7, -15.2]]
      : [[-1.1, -16], [-2.1, -14.5], [-2.3, -12], [-2.0, end], [-.6, end + .3], [-.2, -12.5], [.6, -14]];
    paint(P(pts), hairFill);
  } else if (hs === 'ponytail') {
    paint(P(side || back ? [[-1, -15.6], [-2.3, -15.2], [-2.6, -13], [-2.1, -10.6], [-1.6, -11.2], [-1.7, -13.4], [-.8, -14.8]] : [[1.0, -15.9], [2.2, -15.6], [2.5, -13.5], [2.1, -11.0], [1.7, -11.6], [1.8, -13.6], [1.2, -14.8]]), hairFill);
  } else if (hs === 'bob' || hs === 'bun') {
    if (hs === 'bob') paint(P([[-1.75, -15.4], [-2.0, -13.6], [-1.95, -12.7], [-1.0, -12.6], [1.0, -12.6], [1.95, -12.7], [2.0, -13.6], [1.75, -15.4]]), hairFill);
  }

  // ---------- arms: two segments, shoulder → elbow → wrist ----------
  const SHY = -11.75, SHX = side ? .1 : F ? 1.45 : 1.7;
  const longSleeve = ['hoodie', 'sweater', 'jacket', 'striped'].includes(top.kind), shortSleeve = ['tee', 'crop'].includes(top.kind);
  const sleeveCol = top.kind === 'jacket' ? top.col : top.col;
  const arm = (which, sx, dir, behind) => {
    rs('arm' + which);
    const a = which === 'L' ? (o.aL ?? .2) : (o.aR ?? .2), hook = which === 'L' ? o.armL : o.armR;
    const ang = armAng(a), d = side ? 1 : dir;
    const v1 = [d * Math.cos(ang), -Math.sin(ang)], ang2 = ang + (ang < -.6 ? .12 : .32), v2 = [d * Math.cos(ang2), -Math.sin(ang2)];
    const sh = [sx, SHY], el = [sh[0] + v1[0] * 2.55, sh[1] + v1[1] * 2.55], wr = [el[0] + v2[0] * 2.3, el[1] + v2[1] * 2.3];
    const sk = behind ? skinDk : skin, sl = behind ? mixCol(sleeveCol, PAL.ink, .2) : sleeveCol;
    paint(ribbon(P([sh, el, wr]), .72 * u, .5 * u), { wash: sk, washOp: 255, ...ink(.7) });
    if (longSleeve) paint(ribbon(P([sh, el, [el[0] + v2[0] * 1.9, el[1] + v2[1] * 1.9]]), .86 * u, .66 * u), { wash: sl, washOp: 255, fill: mixCol(sl, PAL.ink, .25), fillOp: 40, tex: .5, ...ink(.7) });
    else if (shortSleeve) paint(ribbon(P([sh, [sh[0] + v1[0] * 1.1, sh[1] + v1[1] * 1.1]]), .9 * u, .82 * u), { wash: sl, washOp: 255, ...ink(.7) });
    const hd = [wr[0] + v2[0] * .3, wr[1] + v2[1] * .3];
    paint(ellPts(hd[0] * u, hd[1] * u, .36 * u, .4 * u, 12, J), { wash: sk, washOp: 255, ...ink(.6) });
    if (hook) {
      push(); translate(hd[0] * u, hd[1] * u);
      if (d < 0) { scale(-1, 1); rotate(Math.atan2(v2[1], -v2[0])); } else rotate(Math.atan2(v2[1], v2[0]));
      translate(-.75 * u, 0); hook(u, sw); pop();
    }
  };
  if (side) arm('R', -.15, 1, true); else if (view === 'q') arm('R', SHX - .3, 1, true);

  // ---------- bottoms ----------
  rs('bottom');
  const hipW = F ? 1.5 : 1.35;
  if (bot.kind === 'skirt') paint(P([[-hipW + .1, HIP - .9], [hipW - .1, HIP - .9], [hipW + .55, HIP + 1.4], [-hipW - .55, HIP + 1.4]]), { wash: bot.col, washOp: 255, fill: mixCol(bot.col, PAL.ink, .3), fillOp: 50, tex: .6, ...ink(.9) });
  else if (bot.kind === 'shorts') paint(P([[-hipW, HIP - .9], [hipW, HIP - .9], [hipW + .15, HIP + .9], [.05, HIP + .9], [0, HIP + .3], [-.05, HIP + .9], [-hipW - .15, HIP + .9]]), { wash: bot.col, washOp: 255, ...ink(.9) });
  else if (pants) paint(P([[-hipW, HIP - .9], [hipW, HIP - .9], [hipW + .05, HIP + .9], [0, HIP + .5], [-hipW - .05, HIP + .9]]), { wash: bot.col, washOp: 255, ...ink(.8) });

  // ---------- torso ----------
  rs('torso');
  const shW = side ? .95 : F ? 1.45 : 1.75, waW = side ? .85 : F ? 1.0 : 1.35, tc = top.col || '#888', tdk = mixCol(tc, PAL.ink, .28);
  const T0 = -12.0, WA = -9.0;
  // skin underneath (neck, midriff, shoulders)
  paint(P([[-.38, -13.1], [.38, -13.1], [.45, -11.9], [-.45, -11.9]]), { wash: skinDk, washOp: 255, ...ink(.6) });
  paint(P([[-shW, T0 + .1], [shW, T0 + .1], [waW + .05, WA], [hipW, HIP - .6], [-hipW, HIP - .6], [-waW - .05, WA]]), { wash: skin, washOp: 255, ...ink(.8), curv: .3 });
  if (top.kind === 'gown' || top.kind === 'dress') {
    const hem = top.kind === 'gown' ? (o.sit ? HIP + 2.7 : -.9) : HIP + 2.2, flare = top.kind === 'gown' ? 2.3 : 2.0;
    const strapL = top.kind === 'gown' ? [[-shW + .45, T0 + .35], [-shW + .25, T0 + .1]] : [[-shW + .05, T0 + .4], [-shW - .05, T0 + .2]];
    const D = [...strapL, [-shW + .7, T0 + .1], [-shW + .65, T0 + .9], [0, T0 + 1.35], [shW - .65, T0 + .9], [shW - .7, T0 + .1], [shW - .25, T0 + .1], [shW - .2, T0 + .5], [waW, WA], [hipW + .1, HIP], [flare, hem], [0, hem + .15], [-flare, hem], [-hipW - .1, HIP], [-waW, WA]];
    if (top.kind === 'dress') { D.splice(0, D.length, [-shW, T0 + .15], [-.6, T0 + .05], [0, T0 + .55], [.6, T0 + .05], [shW, T0 + .15], [waW, WA], [hipW + .2, HIP], [flare, hem], [0, hem + .15], [-flare, hem], [-hipW - .2, HIP], [-waW, WA]); }
    paint(P(D), { wash: tc, washOp: 255, fill: tdk, fillOp: 60, bleed: .06, tex: .7, ...ink(), curv: .25 });
    if (top.kind === 'gown') inkLine(P([[.5, HIP + .3], [.8, -3], [1.1, -1.1]]), sw * .6, tdk, 'inkfine', .5);   // slit fold
    if (top.kind === 'dress') { for (let k = 0; k < 3; k++) inkLine(P([[-1.2 + k * 1.2, HIP + .6], [-1.5 + k * 1.5, hem - .1]]), sw * .4, tdk, 'inkfine', .3); paint(P([[-waW - .05, WA - .2], [waW + .05, WA - .2], [waW + .05, WA + .25], [-waW - .05, WA + .25]]), { wash: mixCol(tc, '#FFFFFF', .4), washOp: 255, ...ink(.5) }); }
  } else if (top.kind === 'crop' || top.kind === 'tank') {
    const hem = top.kind === 'crop' ? WA - .35 : HIP - .5, nk = top.kind === 'tank' ? .55 : .3;
    paint(P([[-shW + (top.kind === 'tank' ? .45 : 0), T0 + .1], [-.5, T0 + .05], [0, T0 + .5 + nk], [.5, T0 + .05], [shW - (top.kind === 'tank' ? .45 : 0), T0 + .1], [waW + .1, hem], [-waW - .1, hem]]), { wash: tc, washOp: 255, fill: tdk, fillOp: 50, tex: .6, ...ink(), curv: .25 });
    if (top.kind === 'crop') inkLine(P([[-.05, WA + .45], [0, WA + .7]]), sw * .5, skinDk, 'inkfine', 0);   // navel
  } else {   // hoodie, tee, sweater, jacket, striped: to the hip
    const loose = top.kind === 'hoodie' || top.kind === 'sweater' ? .35 : 0, hem = HIP - .2 + loose * .8;
    paint(P([[-shW - loose * .3, T0 + .05], [shW + loose * .3, T0 + .05], [waW + .2 + loose, WA], [hipW + loose, hem], [-hipW - loose, hem], [-waW - .2 - loose, WA]]), { wash: tc, washOp: 255, fill: tdk, fillOp: 55, bleed: .05, tex: .65, ...ink(), curv: .2 });
    if (top.kind === 'striped') for (let k = 0; k < 6; k++) { const yy = T0 + .8 + k * .78, w = lerp(shW - .1, hipW - .05, (yy - T0) / (HIP - T0)) * .92; paint(P([[-w, yy], [w, yy], [w, yy + .3], [-w, yy + .3]]), { wash: top.col2 || PAL.cream, washOp: 255, ink: null }); }
    if (top.kind === 'hoodie') { paint(P([[-1.1, T0 - .1], [1.1, T0 - .1], [.5, T0 + .7], [-.5, T0 + .7]]), { wash: tdk, washOp: 255, ...ink(.7), curv: .4 }); paint(P([[-.9, WA + .2], [.9, WA + .2], [1.1, HIP - .4], [-1.1, HIP - .4]]), { wash: tdk, washOp: 255, ...ink(.6) }); for (const s of [-.25, .25]) inkLine(P([[s, T0 + .6], [s * 1.2, T0 + 2.1]]), sw * .6, PAL.cream, 'inkfine', 0); }
    if (top.kind === 'jacket') { paint(P([[-.55, T0 + .1], [.55, T0 + .1], [.45, hem], [-.45, hem]]), { wash: top.col2 || PAL.cream, washOp: 255, ...ink(.6) }); inkLine(P([[-.55, T0 + .1], [-.15, T0 + 1.6]]), sw * .7, PAL.ink, 'ink', 0); inkLine(P([[.55, T0 + .1], [.15, T0 + 1.6]]), sw * .7, PAL.ink, 'ink', 0); }
    if (top.kind === 'sweater') for (let k = 0; k < 4; k++) inkLine(P([[-hipW - .2 + k * .1, hem - .35], [hipW + .2, hem - .35]].map(([a, b], j) => [a + j * 0, b])), sw * .4, tdk, 'inkfine', 0);
    if (top.kind === 'tee') inkLine(P([[-.55, T0 + .05], [0, T0 + .55], [.55, T0 + .05]]), sw * .7, PAL.ink, 'ink', .5);
  }
  if (acc.includes('apron') && !back) { paint(P([[-.8, T0 + .9], [.8, T0 + .9], [.95, WA], [1.25, HIP + .9], [-1.25, HIP + .9], [-.95, WA]]), { wash: '#F6F1E6', washOp: 255, fill: '#E2D8C6', fillOp: 50, tex: .5, ...ink(.7), curv: .2 }); inkLine(P([[-.75, T0 + .9], [-.42, -12.95]]), sw * .8, '#E2D8C6', 'ink', 0); inkLine(P([[.75, T0 + .9], [.42, -12.95]]), sw * .8, '#E2D8C6', 'ink', 0); paint(rrPts(-.5 * u, (WA + .9) * u, 1 * u, .8 * u, .15 * u), { wash: '#E9DFCC', washOp: 255, ...ink(.5) }); }
  if (acc.includes('choker')) inkLine(P([[-.42, -12.85], [0, -12.75], [.42, -12.85]]), sw * 1.8, PAL.ink, 'ink', .4);
  if (acc.includes('bag')) { inkLine(P([[shW - .2, T0 + .1], [hipW + .3, HIP - .3]]), sw * .6, PAL.ink, 'inkfine', 0); paint(rrPts((hipW + .1) * u, (HIP - .5) * u, 1.1 * u, .8 * u, .2 * u), { wash: '#2B2738', washOp: 255, ...ink(.6) }); }

  // ---------- head ----------
  rs('head');
  const hx = fcx * .3;
  if (!back) for (const s of side ? [-1] : [-1, 1]) paint(ellPts((s * HRX * .97 + (side ? -.2 : 0)) * u, (HC + .2) * u, .3 * u, .42 * u, 10), { wash: skin, washOp: 255, ...ink(.6) });
  const head = P([[-HRX, HC - .3], [-HRX * .98, HC - 1.1], [-HRX * .7, HC - 1.65], [0, HC - HRY], [HRX * .7, HC - 1.65], [HRX * .98, HC - 1.1], [HRX, HC - .3], [HRX * .9, HC + .7], [HRX * .55, HC + 1.45], [0, HC + HRY], [-HRX * .55, HC + 1.45], [-HRX * .9, HC + .7]].map(([a, b]) => [a * (side ? .92 : 1) + hx, b]));
  paint(head, { wash: back ? hairC : skin, washOp: 255, ...ink(), curv: .55 });
  if (acc.includes('earrings') && !back) for (const s of side ? [-1] : [-1, 1]) paint(ellPts(s * HRX * 1.0 * u, (HC + .85) * u, .14 * u, .14 * u, 8), { wash: '#F2C14E', washOp: 255, ...ink(.4) });

  // ---------- face ----------
  if (!back) face();
  function face() {
    rs('face');
    const sides = side ? [1] : [-1, 1], E = Array.isArray(o.eyes) ? o.eyes : o.eyes === 'wink' ? ['happy', 'normal'] : [o.eyes || 'normal', o.eyes || 'normal'];
    const sqz = clamp(o.squint || 0), lx = (o.lookX || 0) * .13, ly = (o.lookY || 0) * .1;
    if (o.blush) for (const s of sides) paint(ellPts((fcx + s * .95 * fw) * u, (HC + .75) * u, .42 * u, .2 * u, 12), { fill: PAL.rose, fillOp: 170 * clamp(o.blush === true ? 1 : o.blush), bleed: .2, ink: null });
    // brows: their tilt is most of the acting
    const k0 = E[0], br = { angry: .35, determined: .22, furious: .4, red: .4, sad: -.3, teary: -.3, cry: -.32, scared: -.25, wide: -.1, narrow: .08 }[k0] || 0, lift = k0 === 'wide' || k0 === 'scared' ? -.2 : 0;
    for (const s of sides) { const bx = fcx + s * .63 * fw, by = HC - .62 + lift; inkLine(P([[bx - s * .32 * fw, by + br * .5], [bx + s * .3 * fw, by - br * .3 - .05]]), sw * (F ? .9 : 1.4), hairDk, 'ink', .3); }
    const OPEN = ['normal', 'look', 'wide', 'shine', 'dot', 'scared', 'blank', 'narrow', 'sleepy', 'angry', 'determined', 'sad', 'teary'];
    if (sqz > .8) { for (const s of sides) inkLine(P([[fcx + s * .63 * fw - .32, HC + .2], [fcx + s * .63 * fw + .32, HC + .22]]), sw * 1.1, PAL.ink, 'ink', .3); }
    else if (E[0] === 'shades') { push(); translate(fcx * u, (HC + .15) * u); scale(.25 * fw, .25); translate(0, 6 * u); eyes(u, o, sw * 4, sides, 0); pop(); }
    else for (const s of sides) {
      const kind = E[s < 0 ? 0 : 1], ex = fcx + s * .63 * fw, ey = HC + .15;
      push(); translate(ex * u, ey * u); if (sqz > 0) scale(1, 1 - sqz);
      if (OPEN.includes(kind)) {
        const big = kind === 'wide' || kind === 'scared' ? 1.15 : 1, rx = (F ? .4 : .34) * fw * big, ry = (F ? .48 : .4) * big;
        const blink = ['normal', 'look', 'wide'].includes(kind) && ((T * .9 + (o.seed || hash(id.length) * 3) * 1.7) % 3.3) < .12;
        if (blink) inkLine(P([[-rx, .05], [0, .18], [rx, .05]]), sw * 1.1, PAL.ink, 'ink', .4);
        else {
          paint(ellPts(0, 0, rx * u, ry * u, 16), { wash: '#FBF7F0', washOp: 255, ink: null });
          const ir = kind === 'scared' ? .16 : kind === 'dot' ? .2 : .29, ix = clamp(lx, -rx + ir, rx - ir), iy = ly + .04;
          if (kind !== 'blank') {
            paint(ellPts(ix * u, iy * u, ir * fw * u, ir * 1.12 * u, 14), { wash: kind === 'scared' ? PAL.ink : L.eye || '#5A3A2A', washOp: 255, ink: null });
            paint(ellPts(ix * u, iy * u, ir * .5 * fw * u, ir * .55 * u, 10), { wash: '#1E1A24', washOp: 255, ink: null });
            paint(ellPts((ix - ir * .35) * u, (iy - ir * .4) * u, ir * .32 * u, ir * .32 * u, 8), { wash: '#FFFFFF', washOp: 255, ink: null });
            if (kind === 'shine') paint(ellPts((ix + ir * .3) * u, (iy + ir * .4) * u, ir * .18 * u, ir * .18 * u, 8), { wash: '#FFFFFF', washOp: 255, ink: null });
          }
          // the lid: skin over the top of the eye, cut by the mood
          const lid = { narrow: [.5, .5], sleepy: [.62, .62], angry: [s < 0 ? .25 : .65, s < 0 ? .65 : .25], determined: [s < 0 ? .15 : .5, s < 0 ? .5 : .15], sad: [s < 0 ? .5 : .1, s < 0 ? .1 : .5], teary: [s < 0 ? .5 : .1, s < 0 ? .1 : .5] }[kind];
          if (lid) paint(P([[-rx - .06, -ry - .1], [rx + .06, -ry - .1], [rx + .06, -ry + 2 * ry * lid[1]], [-rx - .06, -ry + 2 * ry * lid[0]]]), { wash: skin, washOp: 255, ink: null });
          const l0 = lid ? -ry + 2 * ry * lid[0] : -ry * .55, l1 = lid ? -ry + 2 * ry * lid[1] : -ry * .55;
          inkLine(P([[-rx - .04, lid ? l0 : 0], ...(lid ? [] : [[-rx * .6, -ry * .85], [0, -ry - .02], [rx * .6, -ry * .85]]), [rx + .04, lid ? l1 : 0]]), sw * (F ? 1.15 : .9), PAL.ink, 'ink', lid ? 0 : .5);
          if (F) inkLine(P([[s * (rx + .02), (lid ? (s < 0 ? l0 : l1) : -ry * .35)], [s * (rx + .2), (lid ? (s < 0 ? l0 : l1) : -ry * .35) - .18]]), sw * 1.1, PAL.ink, 'ink', 0);   // lash flick
          paint(ellPts(0, 0, rx * u, ry * u, 16), { ink: PAL.ink, sw: sw * .35 });
          if (lid) paint(P([[-rx - .1, -ry - .3], [rx + .1, -ry - .3], [rx + .1, l1 - .02], [-rx - .1, l0 - .02]]), { wash: skin, washOp: 255, ink: null });
          if (lid) inkLine(P([[-rx - .04, l0], [rx + .04, l1]]), sw * (F ? 1.0 : .8), PAL.ink, 'ink', 0);
          if (kind === 'teary') paint(ellPts(0, ry * .8 * u, rx * 1.05 * u, .14 * u, 12), { wash: PAL.sky, washOp: 210, ink: null });
        }
      } else { push(); scale(.4 * fw, .4); eye(kind, s, u, o, sw * 1.3); pop(); }
      pop();
    }
    // nose and mouth
    inkLine(P([[fcx + (side ? .25 : .02), HC + .55], [fcx + (side ? .45 : .12), HC + .85], [fcx + (side ? .2 : -.05), HC + .92]]), sw * .55, skinDk, 'inkfine', .5);
    let m = o.mouth; if (!m && (o.lid || 0) > .05) m = 'teeth';
    push(); translate((fcx + (side ? .35 : 0)) * u, (HC + 1.25) * u); scale(.32 * fw, .32); translate(0, 4.3 * u); if (m) mouth(u, m, sw * 2.6); pop();
    if (!m) inkLine(P([[fcx - .22 * fw, HC + 1.22], [fcx, HC + 1.28], [fcx + .22 * fw, HC + 1.2]]), sw * .7, F ? '#B8505E' : mixCol(skinDk, PAL.ink, .3), 'ink', .5);
    if (o.draw) { push(); translate(fcx * u, (HC + .15) * u); scale(.25 * fw, .25); translate(0, 6 * u); o.draw(u, sw * 3); pop(); }
    if (acc.includes('mustache')) paint(P([[fcx - .62 * fw, HC + 1.2], [fcx - .3 * fw, HC + .98], [fcx, HC + 1.05], [fcx + .3 * fw, HC + .98], [fcx + .62 * fw, HC + 1.2], [fcx + .3 * fw, HC + 1.12], [fcx, HC + 1.16], [fcx - .3 * fw, HC + 1.12]]), { wash: hairDk, washOp: 255, ink: null, curv: .4 });
    if (acc.includes('glasses')) { for (const s of sides) paint(ellPts((fcx + s * .63 * fw) * u, (HC + .15) * u, .56 * fw * u, .5 * u, 16), { ink: '#4A3E52', sw: sw * .38 }); if (!side) inkLine(P([[fcx - .1, HC + .1], [fcx + .1, HC + .1]]), sw * .38, '#4A3E52', 'ink', 0); }
  }

  // ---------- hair on top ----------
  rs('hair');
  const HF = { ...hairFill, curv: .45 };
  if (back) paint(P([[-1.65, -14.2], [-1.6, -15.5], [0, -16.35], [1.6, -15.5], [1.65, -14.2], [1.4, -12.9], [0, -12.6], [-1.4, -12.9]]), HF);
  else if (hs === 'old') { for (const s of [-1, 1]) paint(ellPts(s * 1.45 * u, (HC - .4) * u, .45 * u, .8 * u, 12), { wash: hairC, washOp: 255, ...ink(.6) }); }
  else if (hs === 'short' || hs === 'curly') {
    if (hs === 'curly') for (let i = 0; i < 9; i++) { const a = Math.PI * (1.03 + i / 8 * .94); paint(ellPts((hx + Math.cos(a) * 1.5) * u, (HC - .4 + Math.sin(a) * 1.55) * u, .6 * u, .55 * u, 12), { wash: hairC, washOp: 255, ...ink(.6) }); }
    else paint(P([[-1.62, -13.9], [-1.7, -15.3], [-.9, -16.25], [.5, -16.4], [1.5, -15.8], [1.72, -14.2], [1.45, -14.9], [1.0, -15.1], [.55, -14.7], [.1, -15.15], [-.45, -14.75], [-.9, -15.1], [-1.3, -14.6]].map(([a, b]) => [a * fw + hx, b])), HF);
  } else if (hs === 'messy') {
    paint(P([[-1.75, -12.9], [-1.8, -15.2], [-1.1, -16.3], [.4, -16.45], [1.5, -15.9], [1.8, -14.6], [1.75, -12.9], [1.35, -13.6], [1.2, -14.2], [.75, -13.3], [.4, -14.4], [0, -13.7], [-.35, -14.75], [-.8, -14.6], [-1.25, -14.9], [-1.55, -13.6]].map(([a, b]) => [a * fw + hx, b])), HF);
  } else if (hs === 'bob' || hs === 'bun') {
    paint(P([[-1.8, -13.4], [-1.75, -15.3], [-.9, -16.3], [.9, -16.3], [1.75, -15.3], [1.8, -13.4], [1.45, -13.4], [1.4, -14.75], [-1.4, -14.75], [-1.45, -13.4]].map(([a, b]) => [a * fw + hx, b])), HF);
    if (hs === 'bun') paint(ellPts(hx * u, -16.55 * u, .75 * u, .62 * u, 14), { wash: hairC, washOp: 255, ...ink(.8) });
  } else {   // long, wavy, ponytail: centre or side part, curtains framing the face
    const curt = hs === 'ponytail' ? -13.9 : hs === 'wavy' ? -12.4 : -12.2;
    paint(P([[-1.8, curt], [-1.75, -15.2], [-1.0, -16.3], [.4, -16.4], [1.4, -15.9], [1.8, -15.0], [1.8, curt], [1.45, curt + .2], [1.35, -14.4], [.75, -15.25], [.15, -15.5], [-.6, -14.9], [-1.3, -14.3], [-1.45, curt + .2]].map(([a, b]) => [a * fw + hx, b])), HF);
    inkLine(P([[.15 + hx, -15.5], [-.2 + hx, -16.25]]), sw * .5, hairDk, 'inkfine', .3);
    if (hs === 'ponytail') paint(ellPts((hx + 1.15) * u, -16.0 * u, .3 * u, .22 * u, 10), { wash: '#D2493A', washOp: 255, ...ink(.5) });
  }
  if (acc.includes('catears') && !side) for (const s of [-1, 1]) { paint(P([[s * .55 + hx, -16.15], [s * 1.25 + hx, -17.5], [s * 1.55 + hx, -15.5]]), { wash: hairC, washOp: 255, ...ink(.8) }); paint(P([[s * .8 + hx, -16.0], [s * 1.25 + hx, -17.05], [s * 1.4 + hx, -15.75]]), { wash: '#F7C8D8', washOp: 255, ink: null }); }
  if (acc.includes('headphones') && !back) { inkLine(P([[-1.75 + hx, -14.0], [-1.5 + hx, -16.1], [0, -16.75], [1.5 + hx, -16.1], [1.75 + hx, -14.0]]), sw * 2.6, '#2B2738', 'ink', .6); for (const s of side ? [-1] : [-1, 1]) paint(rrPts((s < 0 ? -2.15 : 1.5) * u + hx * u, -14.9 * u, .65 * u, 1.3 * u, .28 * u), { wash: '#6B6482', washOp: 255, ...ink(.7) }); }
  if (o.hat && o.hat !== 'cat') { push(); translate(hx * u, -16.25 * u); scale(.37, .37); translate(0, 8 * u); hat(u, o.hat, sw * 2.7); pop(); }

  // arms in front
  if (side) arm('L', .3, 1, false); else if (view === 'q') arm('L', -SHX + .4, -1, false); else { arm('L', -SHX, -1, false); arm('R', SHX, 1, false); }
  pop();

  rs('emote');
  if (o.emote) {
    const topE = EMOTE_TOP.includes(o.emote), dir = o.flip ? -1 : 1;
    emote(o.emote, topE ? x : x + dir * 2.4 * u, y + dy + ((topE ? -18.4 : -16.6) * (1 - sq) + (o.sit ? 7 - (typeof o.sit === 'number' ? o.sit : 3.5) - .25 : 0)) * u, u * .6, o.emoteK ?? 1, o.emoteAge ?? T);
  }
  rs('after');
}

// sample sheet: node render.mjs --loop=tallcast --sheet=0.5 --cols=1 --w=1920 --out=out/check/tall.jpg
LOOPS.tallcast = t => {
  paint(rectPts(-100, -100, W + 200, H + 200), { wash: '#F3EADB', ink: null });
  boilSeed('floor'); paint(rectPts(-100, 960, W + 200, 300), { wash: '#E2D3BC', ink: null }); inkLine([[0, 962], [W, 962]], 1, PAL.ink, 'ink', 0);
  const C = [['introvert', 'bored'], ['extrovert', 'excited'], ['egirl', 'playful'], ['gym', 'determined'], ['catgirl', 'love'], ['elegant', 'smug'], ['boy', 'happy'], ['girl', 'shy']];
  C.forEach(([k, e], i) => tall(120 + i * 240, 990, 40, { ...feel(e, t + i * .3), look: k, boilKey: k }));
};
LOOPS.tallcast.len = 2;
