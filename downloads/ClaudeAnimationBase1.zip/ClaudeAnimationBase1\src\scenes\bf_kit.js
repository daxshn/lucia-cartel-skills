// bf_kit.js: props, sets and cast for "Every Type of Person on Black Friday" (vertical 1080×1920).
// World coordinates stay the same as the horizontal videos (ground GY = 900); the vertical frame is a tall window onto
// it: CAMS.W shows x ≈ 570..1350 and y ≈ -60..1330, so the cast sits mid-frame with room for the title above and the
// captions on the floor below.
CAMS.W = [960, 560, 1.38]; CAMS.T = [960, 600, 1.75]; CAMS.closeDy = 300; CAMS.closeZ = 2.1;
const BF = { red: '#D2333A', redDk: '#9E1F2A', yel: '#FFD23A', night: '#1E2348', nightLt: '#343B72', floor: '#B9B4AE', wall: '#ECE6DC' };

Object.assign(LOOKS, {
  camper:   { body: 'm', skin: '#E8B48C', eye: '#3A2A20', hair: { style: 'messy', col: '#3A2A20' }, top: { kind: 'jacket', col: '#E07A2E', col2: '#3A3F4F' }, bottom: { kind: 'jeans', col: '#33405E' }, shoes: { kind: 'boot', col: '#5A3A22' } },
  wrestA:   { body: 'm', skin: '#C98D63', eye: '#3A2A20', hair: { style: 'short', col: '#1E1A22' }, top: { kind: 'hoodie', col: '#4F86C2' }, bottom: { kind: 'jeans', col: '#2E3044' }, shoes: { kind: 'sneaker', col: '#F2EEE6' } },
  wrestB:   { body: 'f', skin: '#F3CBA8', eye: '#4A6A3A', hair: { style: 'ponytail', col: '#B07A3A' }, top: { kind: 'jacket', col: '#8A4FA0', col2: '#F2EEE6' }, bottom: { kind: 'leggings', col: '#2B2738' }, shoes: { kind: 'sneaker', col: '#F2EEE6' } },
  looker:   { body: 'f', skin: '#F1C7A6', eye: '#5A3A2A', hair: { style: 'wavy', col: '#2A1E1A' }, top: { kind: 'sweater', col: '#E8A0AE' }, bottom: { kind: 'jeans', col: '#5A6A9A' }, shoes: { kind: 'boot', col: '#6B4030' }, acc: ['earrings', 'bag'] },
  online:   { body: 'm', skin: '#F1C29C', eye: '#4A3020', hair: { style: 'messy', col: '#2E2224' }, top: { kind: 'tee', col: '#7FA6C9' }, bottom: { kind: 'trousers', col: '#4F6E9A' }, shoes: { kind: 'flat', col: '#C9965F' } },
  calc:     { body: 'm', skin: '#EDBE98', eye: '#4A3020', hair: { style: 'short', col: '#5A4A40' }, top: { kind: 'sweater', col: '#5E8F4E' }, bottom: { kind: 'trousers', col: '#3E3A4A' }, shoes: { kind: 'flat', col: '#3A2A22' }, acc: ['glasses'] },
  mom:      { body: 'f', skin: '#E8B48C', eye: '#4A3020', hair: { style: 'bun', col: '#3A2418' }, top: { kind: 'jacket', col: '#3E8A7A', col2: '#F2EEE6' }, bottom: { kind: 'jeans', col: '#3A4A6A' }, shoes: { kind: 'sneaker', col: '#F2EEE6' }, acc: ['bag'] },
  employee: { body: 'm', skin: '#8E5C40', eye: '#2A1A14', hair: { style: 'curly', col: '#1E1A22' }, top: { kind: 'tee', col: '#D2333A' }, bottom: { kind: 'trousers', col: '#2B2738' }, shoes: { kind: 'sneaker', col: '#2B2738' } },
  gifter:   { body: 'f', skin: '#F6D3B5', eye: '#6A4024', hair: { style: 'long', col: '#F0D27A' }, top: { kind: 'sweater', col: '#E3A33B' }, bottom: { kind: 'skirt', col: '#3A3448' }, legs: 'tights', legCol: '#3A3448', shoes: { kind: 'boot', col: '#6B4030' }, acc: ['earrings'] },
});

// ---------- icons ----------
Object.assign(ICON, {
  tvbox: (x, y, s) => { pw(rrPts(x - 1.2 * s, y - .8 * s, 2.4 * s, 1.6 * s, .1 * s), '#C9A06A', 1.2); pw(rrPts(x - .9 * s, y - .55 * s, 1.8 * s, 1.0 * s, .08 * s), '#2B2738'); paint(rectPts(x - .78 * s, y - .45 * s, 1.56 * s, .8 * s), { wash: '#7FC8E8', ink: null }); paint(ellPts(x - .2 * s, y - .1 * s, .5 * s, .2 * s, 12), { wash: '#BDE6F2', ink: null }); rc(x + .55 * s, y - .78 * s, .55 * s, .28 * s, BF.red, .6); },
  airfryer: (x, y, s) => { pw(rrPts(x - .7 * s, y - .9 * s, 1.4 * s, 1.8 * s, .35 * s), '#2B2738', 1.1); paint(rrPts(x - .5 * s, y - .1 * s, 1 * s, .7 * s, .12 * s), { wash: '#4A4263', ink: PAL.ink, sw: .7 }); el(x, y - .5 * s, .18 * s, .18 * s, BF.red, .5); },
  teddy: (x, y, s) => { el(x - .55 * s, y - .85 * s, .28 * s, .28 * s, '#B8703C', .8); el(x + .55 * s, y - .85 * s, .28 * s, .28 * s, '#B8703C', .8); el(x, y + .25 * s, .85 * s, .75 * s, '#C98A4B', 1); el(x, y - .45 * s, .65 * s, .6 * s, '#C98A4B', 1); el(x, y - .3 * s, .22 * s, .16 * s, '#EFC27A', .5); el(x - .22 * s, y - .55 * s, .07 * s, .08 * s, PAL.ink, .2); el(x + .22 * s, y - .55 * s, .07 * s, .08 * s, PAL.ink, .2); },
  laptop: (x, y, s) => { pw([[x - 1 * s, y - .9 * s], [x + 1 * s, y - .9 * s], [x + .9 * s, y + .3 * s], [x - .9 * s, y + .3 * s]], '#4A4263', 1); paint(rectPts(x - .82 * s, y - .78 * s, 1.64 * s, .96 * s), { wash: '#9FD3E8', ink: null }); pw([[x - 1.2 * s, y + .3 * s], [x + 1.2 * s, y + .3 * s], [x + 1.05 * s, y + .55 * s], [x - 1.05 * s, y + .55 * s]], '#6B6482', .8); },
  walkie: (x, y, s) => { pw(rrPts(x - .4 * s, y - .7 * s, .8 * s, 1.6 * s, .14 * s), '#2B2738'); inkLine([[x + .2 * s, y - .7 * s], [x + .25 * s, y - 1.3 * s]], 2, PAL.ink, 'ink', 0); paint(rectPts(x - .26 * s, y - .5 * s, .52 * s, .4 * s), { wash: '#8ED6A6', ink: null }); for (let i = 0; i < 3; i++) inkLine([[x - .24 * s, y + .1 * s + i * .18 * s], [x + .24 * s, y + .1 * s + i * .18 * s]], .7, '#6B6482', 'inkfine', 0); },
  map: (x, y, s) => { pw([[x - 1 * s, y - .7 * s], [x - .33 * s, y - .55 * s], [x + .33 * s, y - .7 * s], [x + 1 * s, y - .55 * s], [x + 1 * s, y + .7 * s], [x + .33 * s, y + .55 * s], [x - .33 * s, y + .7 * s], [x - 1 * s, y + .55 * s]], '#F6EBD6'); inkLine([[x - .7 * s, y + .3 * s], [x - .2 * s, y - .1 * s], [x + .3 * s, y + .2 * s], [x + .7 * s, y - .3 * s]], 1.4, BF.red, 'ink', .4); ICON.cross(x + .7 * s, y - .3 * s, .2 * s); },
  list: (x, y, s) => { rc(x - .65 * s, y - .9 * s, 1.3 * s, 1.8 * s, PAL.paper); for (let i = 0; i < 4; i++) { rc(x - .5 * s, y - .62 * s + i * .38 * s, .22 * s, .22 * s, ['#D2333A', '#4F9FD6', '#5E8F4E', '#E3A33B'][i], .4); inkLine([[x - .15 * s, y - .5 * s + i * .38 * s], [x + .45 * s, y - .5 * s + i * .38 * s]], .8, '#7C7390', 'inkfine', 0); } },
  register: (x, y, s) => { pw([[x - 1 * s, y - .1 * s], [x + 1 * s, y - .1 * s], [x + 1.1 * s, y + .7 * s], [x - 1.1 * s, y + .7 * s]], '#4A4263'); pw(rrPts(x - .6 * s, y - .9 * s, 1.2 * s, .7 * s, .1 * s), '#2B2738'); paint(rectPts(x - .48 * s, y - .8 * s, .96 * s, .45 * s), { wash: '#8ED6A6', ink: null }); },
  giftbag: (x, y, s) => { pw([[x - .7 * s, y - .5 * s], [x + .7 * s, y - .5 * s], [x + .8 * s, y + .9 * s], [x - .8 * s, y + .9 * s]], BF.red); for (const d of [-.3, .3]) inkLine([[x + d * s, y - .5 * s], [x + d * s * .6, y - .95 * s], [x + d * s * .2, y - .5 * s]], 1.2, PAL.ink, 'ink', .6); paint(rectPts(x - .12 * s, y - .5 * s, .24 * s, 1.4 * s), { wash: BF.yel, ink: null }); },
  calc: (x, y, s) => { pw(rrPts(x - .6 * s, y - .9 * s, 1.2 * s, 1.8 * s, .14 * s), '#4A4263'); paint(rectPts(x - .45 * s, y - .75 * s, .9 * s, .4 * s), { wash: '#8ED6A6', ink: null }); for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) el(x - .3 * s + j * .3 * s, y - .1 * s + i * .3 * s, .1 * s, .09 * s, PAL.cream, .3); },
  gas: (x, y, s) => { pw(rrPts(x - .6 * s, y - .9 * s, 1.2 * s, 1.8 * s, .12 * s), BF.red); paint(rectPts(x - .4 * s, y - .7 * s, .8 * s, .45 * s), { wash: '#FBF7F0', ink: null }); inkLine([[x + .6 * s, y - .2 * s], [x + 1 * s, y + .1 * s], [x + .9 * s, y + .7 * s]], 2, PAL.ink, 'ink', .5); },
  tag: (x, y, s) => { pw([[x - .9 * s, y - .5 * s], [x + .5 * s, y - .5 * s], [x + 1 * s, y], [x + .5 * s, y + .5 * s], [x - .9 * s, y + .5 * s]], BF.yel, 1); el(x + .45 * s, y, .1 * s, .1 * s, PAL.ink, .3); inkLine([[x - .6 * s, y + .25 * s], [x - .1 * s, y - .25 * s]], 1.4, BF.red, 'ink', 0); el(x - .55 * s, y - .18 * s, .08 * s, .08 * s, BF.red, .3); el(x - .15 * s, y + .2 * s, .08 * s, .08 * s, BF.red, .3); },
  thermos: (x, y, s) => { pw(rrPts(x - .35 * s, y - .9 * s, .7 * s, 1.8 * s, .2 * s), '#3E8A7A'); rc(x - .4 * s, y - 1.05 * s, .8 * s, .3 * s, '#2B2738', .6); },
  phoneSold: (x, y, s) => { ICON.phone(x, y, s); ICON.cross(x, y, s * .5); },
  money: (x, y, s) => { pw(rrPts(x - s, y - .55 * s, 2 * s, 1.1 * s, .1 * s), '#7FB069'); el(x, y, .3 * s, .3 * s, '#5E8F4E', .6); },
  chart: (x, y, s) => { rc(x - .9 * s, y - .8 * s, 1.8 * s, 1.6 * s, PAL.paper, 1); for (let i = 0; i < 3; i++) rc(x - .6 * s + i * .45 * s, y + .55 * s - (.4 + i * .3) * s, .3 * s, (.4 + i * .3) * s, ['#4F9FD6', '#E3A33B', '#D2493A'][i], .5); },
  box: (x, y, s) => { pw([[x - .9 * s, y - .3 * s], [x + .9 * s, y - .3 * s], [x + .9 * s, y + .8 * s], [x - .9 * s, y + .8 * s]], '#C9A06A'); pw([[x - .9 * s, y - .3 * s], [x - .5 * s, y - .75 * s], [x + 1.2 * s, y - .75 * s], [x + .9 * s, y - .3 * s]], '#D9B47E', .8); },
});

// a shopping cart at (x, ground y), with icons piled in it
function cart(x, items = [], s = 1, flip = false) {
  boilSeed('cart' + x); push(); translate(x, GY); scale((flip ? -1 : 1) * s, s);
  for (const d of [-80, 80]) el(d, -18, 18, 18, '#2B2738', .8);
  inkLine([[-110, -40], [120, -40]], 3, '#8A8F9A', 'ink', 0);
  pw([[-130, -190], [140, -190], [110, -50], [-100, -50]], '#CFD6DC', 1.2);
  for (let i = 1; i < 6; i++) inkLine([[-130 + i * 45, -188], [-100 + i * 35, -52]], .8, '#8A8F9A', 'inkfine', 0);
  items.forEach((it, i) => { boilSeed('cartit' + x + i); icon(it, -70 + (i % 3) * 75, -215 - Math.floor(i / 3) * 80, 48); });
  inkLine([[-130, -190], [-170, -250], [-210, -250]], 3, '#8A8F9A', 'ink', 0);
  pop();
}
function tent(x, s = 1) { boilSeed('tent' + x); push(); translate(x, GY); scale(s); pw([[-200, 0], [0, -230], [200, 0]], '#E07A2E', 1.4); pw([[-50, 0], [0, -150], [50, 0]], '#9A4A1E', 1); inkLine([[0, -230], [0, -260]], 2, PAL.ink, 'ink', 0); pop(); }
function saleSign(x, y, txt, rot = 0, col = BF.yel, s = 1) { boilSeed('sign' + x + y); push(); translate(x, y); rotate(rot); scale(s); paint(rrPts(-120, -60, 240, 120, 18, 2), { wash: col, ink: PAL.ink, sw: 1.4 }); pop(); letter(txt, x, y + 4, 64 * s, BF.red, { font: `900 ${64 * s}px "Segoe UI Black", Impact, sans-serif`, rot, ink: false }); }

// ---------- sets ----------
function bfFront(t, o = {}) {
  boilSeed('bfsky'); paint(rectPts(-500, -400, 2920, 1900), { wash: BF.night, ink: null }); glow(1300, -40, 500, '#6B74C8', .5);
  for (let i = 0; i < 30; i++) { boilSeed('star' + i); paint(starPts(hash(i) * 2400 - 200, hash(i + 40) * 300 - 60, 3 + 4 * hash(i + 7), .35, 4), { wash: PAL.cream, washOp: 200, ink: null }); }
  boilSeed('bfbrick'); paint(rectPts(300, 120, 1320, GY - 120), { wash: '#7A3A34', ink: PAL.ink, sw: 1.4 });
  for (let j = 0; j < 12; j++) inkLine([[300, 160 + j * 60], [1620, 160 + j * 60]], .6, '#5E2A26', 'inkfine', 0);
  boilSeed('bfdoor'); glow(960, 640, 420, '#FFE3A8', o.open ? .9 : .5);
  paint(rectPts(760, 420, 400, GY - 420), { wash: o.open ? '#FFF2C8' : '#F2D9A0', ink: PAL.ink, sw: 1.6 }); inkLine([[960, 420], [960, GY]], 2, PAL.ink, 'ink', 0);
  for (const sx of [420, 1250]) { boilSeed('bfwin' + sx); paint(rectPts(sx, 440, 250, 280), { wash: '#F6E2B0', ink: PAL.ink, sw: 1.4 }); }
  saleSign(690, 580, '-70%', -.08, BF.yel, .8); saleSign(1230, 580, 'SALE', .07, BF.yel, .8);
  boilSeed('bfsign'); paint(rrPts(560, 180, 800, 180, 30, 3), { wash: '#1E1A22', ink: PAL.ink, sw: 2 }); glow(960, 270, 380, BF.red, .45 + .15 * Math.sin(t * 6));
  letter('BLACK FRIDAY', 960, 274, 92, BF.yel, { font: '900 92px "Segoe UI Black", Impact, sans-serif', stroke: BF.redDk, ink: false });
  boilSeed('bfwalk'); paint(rectPts(-500, GY - 40, 2920, 700), { wash: '#8A8890', ink: null }); inkLine([[-400, GY - 40], [2400, GY - 40]], 1.4, PAL.ink, 'ink', 0);
  for (let i = 0; i < 10; i++) inkLine([[i * 240 - 200, GY - 40], [i * 240 - 260, GY + 400]], .8, '#6B6A72', 'inkfine', 0);
}
function bfStore(t, o = {}) {
  boilSeed('bfwall'); paint(rectPts(-500, -400, 2920, 1900), { wash: BF.wall, ink: null });
  for (let i = 0; i < 6; i++) { boilSeed('lamp' + i); const x = 300 + i * 270; inkLine([[x, -100], [x, 40]], 1.4, '#6B6482', 'ink', 0); pw([[x - 60, 40], [x + 60, 40], [x + 40, 80], [x - 40, 80]], '#D7DDE2', 1); glow(x, 120, 200, '#FFF6D8', .35); }
  boilSeed('shelf'); for (let r = 0; r < 3; r++) { const y = 260 + r * 180; rc(380, y + 120, 1160, 22, '#8A8F9A', 1); for (let i = 0; i < 11; i++) { boilSeed('pr' + r + i); const w = 70 + 30 * hash(r * 11 + i), h = 70 + 50 * hash(r * 7 + i + 3); rc(400 + i * 104, y + 120 - h, w, h, ['#4F86C2', '#D2333A', '#E3A33B', '#5E8F4E', '#8A4FA0', '#F2EEE6'][(r + i) % 6], .9); } }
  if (o.signs !== false) { saleSign(720, 110, '-60%', -.06, BF.yel, .8); saleSign(1200, 110, 'SALE', .06, BF.yel, .8); }
  boilSeed('bffloor'); paint(rectPts(-500, GY - 40, 2920, 700), { wash: BF.floor, ink: null }); inkLine([[-400, GY - 40], [2400, GY - 40]], 1.4, PAL.ink, 'ink', 0);
  for (let i = 0; i < 12; i++) inkLine([[i * 200 - 300, GY - 40], [i * 260 - 700, GY + 500]], .7, '#9A958F', 'inkfine', 0);
}
function bfTVs(t, last = true) {
  boilSeed('tvstack'); for (let i = 0; i < 6; i++) { const x = 520 + (i % 3) * 170, y = GY - 120 - Math.floor(i / 3) * 130; icon('box', x, y, 60); }
  if (last) { boilSeed('lasttv'); icon('tvbox', 960, GY - 150, 120); }
}
function bfBedroom(t) {
  boilSeed('bdwall'); paint(rectPts(-500, -400, 2920, 1900), { wash: '#2C3366', ink: null });
  boilSeed('bdwin'); rc(660, 140, 300, 260, '#ECE6DC', 1); paint(rectPts(676, 156, 268, 228), { wash: '#141838', ink: PAL.ink, sw: .8 }); paint(ellPts(880, 220, 30, 30, 16), { wash: PAL.cream, ink: null });
  boilSeed('bdclock'); el(1200, 240, 60, 60, '#ECE6DC', 1.2); inkLine([[1200, 240], [1200, 196]], 2, PAL.ink, 'ink', 0); inkLine([[1200, 240], [1234, 240]], 2, PAL.ink, 'ink', 0);
  boilSeed('bdbed'); pw(rrPts(640, GY - 260, 700, 230, 30), '#6B4A8A', 1.3); pw(rrPts(620, GY - 360, 100, 340, 30), '#4A2E5A', 1.2); pw(rrPts(680, GY - 300, 200, 90, 40), '#ECE6DC', 1);
  boilSeed('bdfloor'); paint(rectPts(-500, GY - 40, 2920, 700), { wash: '#4A3A5A', ink: null });
  glow(1050, GY - 330, 380, '#8EC8F0', .45);
}
function bfCheckout(t) {
  bfStore(t, { signs: false });
  boilSeed('checkout'); rc(380, GY - 260, 1160, 230, '#4A4263', 1.3); rc(360, GY - 290, 1200, 40, '#8A8F9A', 1.2); icon('register', 1300, GY - 360, 70);
  boilSeed('queue'); paint(rectPts(-500, -400, 900, 1900), { wash: '#000000', washOp: 0, ink: null });
}

// test sheet (vertical): node render.mjs --page=studio_bf.html --loop=bfsets --sheet=0.5,1.5,2.5,3.5 --cols=4 --w=360 --out=out/check/bfsets.jpg
LOOPS.bfsets = t => {
  const k = Math.floor(t);
  camBegin(...CAMS.W);
  if (k === 0) { bfFront(t); tent(700); tall(1100, GY, 26, { ...feel('proud', t), look: 'camper', boilKey: 'c', hat: 'beanie', ...hold('thermos') }); }
  if (k === 1) { bfStore(t); bfTVs(t); tall(780, GY, 26, { ...feel('furious', t), look: 'wrestA', boilKey: 'a' }); tall(1140, GY, 26, { ...feel('furious', t), look: 'wrestB', boilKey: 'b', flip: true }); }
  if (k === 2) { bfBedroom(t); tall(960, GY, 26, { ...feel('sleepy', t), look: 'online', boilKey: 'o', ...hold('laptop', 'R', .6, 1.4) }); }
  if (k === 3) { bfStore(t); cart(1200, ['airfryer', 'teddy', 'tvbox', 'giftbag', 'airfryer']); tall(800, GY, 26, { ...feel('happy', t), look: 'looker', boilKey: 'l' }); }
  camEnd();
};
LOOPS.bfsets.len = 4;
