// thanksgiving.js: "Every Type of Person at Thanksgiving Dinner" (8:17), cut to out/tg/voiceover.wav.
// Every beat is pinned to a spoken phrase with at('phrase'), looked up in TGW (the Whisper word timings), so the
// animation follows the voiceover. A = "you" (the guy from the couples video), B = this section's type, C/D/E = family.
(() => {
  const norm = s => s.toLowerCase().replace(/[^a-z0-9]/g, '');
  const TW = TGW.map(([s, e, w]) => [s, e, norm(w)]);
  let FROM = 0;
  // start time of the first occurrence of `phrase` at or after FROM (the current section's start)
  const CACHE = new Map();
  const at = (phrase, after = FROM) => {
    const key = phrase + '|' + after; if (CACHE.has(key)) return CACHE.get(key);
    const r = find(phrase, after); CACHE.set(key, r); return r;
  };
  const find = (phrase, after) => {
    const P = phrase.split(/\s+/).map(norm).filter(Boolean);
    for (let i = 0; i < TW.length; i++) {
      if (TW[i][0] < after - .01) continue;
      let ok = true; for (let j = 0; j < P.length; j++) if (!TW[i + j] || TW[i + j][2] !== P[j]) { ok = false; break; }
      if (ok) return TW[i][0];
    }
    console.warn('at(): no match for "' + phrase + '" after ' + after.toFixed(1)); return after;
  };
  const end = phrase => { const s = at(phrase), P = phrase.split(/\s+/).filter(Boolean).length; const i = TW.findIndex(w => w[0] === s); return TW[i + P - 1] ? TW[i + P - 1][1] : s + 1; };
  const pop = (t, a, b = 1e9) => backOut(seg(t, a, a + .25)) * (1 - ease(seg(t, b - .2, b)));
  const SEC = [], DUR_TG = 497.2;
  // every function in a spec runs with FROM set to its own section, so at() inside it searches the right stretch
  const sec = (t0, spec) => {
    FROM = t0 - .5; const S = spec(); S.t0 = t0;
    const wrap = f => f && ((...a) => { const p = FROM; FROM = t0 - .5; try { return f(...a); } finally { FROM = p; } });
    for (const k of ['bg', 'over', 'under', 'shake', 'screen']) S[k] = wrap(S[k]);
    for (const c of Object.values(S.ch)) if (c.pose) c.pose = wrap(c.pose);
    SEC.push(S);
  };
  const K = (...keys) => keys.sort((a, b) => a[0] - b[0]);
  const look = (name, extra = {}) => ({ look: name, ...extra });

  // ---------- 0. intro ----------
  sec(0, () => ({
    bg: t => { tgDining(t); leavesFalling(t, 4); }, over: t => tgTable(t),
    shake: t => { const a = at('argument nobody'); return t > a && t < a + 1 ? 10 * Math.exp(-(t - a) * 4) : 0; },
    ch: {
      C: { x: 330, o: look('carver'), k: K([0, 'happy'], [at('remembers exactly'), 'bored'], [at("there's turkey"), 'happy'], [at('argument nobody'), 'angry'], [at('no matter whose'), 'neutral'], [at('every type of person'), 'excited'], [at('grab a plate'), 'happy']) },
      D: { x: 600, o: look('host'), k: K([0, 'happy'], [at('remembers exactly'), 'nervous'], [at("there's pie"), 'proud'], [at('argument nobody'), 'scared'], [at('no matter whose'), 'happy'], [at('grab a plate'), 'excited']) },
      B: { x: 960, o: look('oldwoman', { hat: 'bow', old: true }), k: K([0, 'love'], [at('remembers exactly'), 'smug'], [at("there's turkey"), 'happy'], [at('argument nobody'), 'laugh'], [at('no matter whose'), 'happy']) },
      E: { x: 1300, o: look('uncle'), k: K([0, 'happy'], [at('remembers exactly'), 'mischief'], [at("there's turkey"), 'happy'], [at('argument nobody'), 'furious'], [at('no matter whose'), 'smug'], [at('every type of person'), 'excited']) },
      F: { x: 1580, o: look('aunt'), k: K([0, 'happy'], [at('remembers exactly'), 'suspicious'], [at("there's turkey"), 'excited'], [at('argument nobody'), 'angry'], [at('no matter whose'), 'happy'], [at('every type of person'), 'excited']) },
      A: { x: 1800, u: UU * .68, o: look('kid'), k: K([0, 'bored', hold('tablet')], [at('every type of person'), 'happy', hold('tablet')]) },
    },
    bub: [[at("there's turkey"), at("there's pie"), 'D', 'turkey'], [at("there's pie"), at('argument nobody'), 'D', 'pie'], [at('argument nobody'), at('no matter whose'), 'E', 'anger'], [at('in your family'), at('grab a plate'), 'B', '?']],
    cam: [[0, 'W'], [at('remembers exactly'), [960, 600, 1.25]], [at("there's turkey"), 'W'], [at('argument nobody'), [1150, 600, 1.4]], [at('no matter whose'), 'W']],
  }));

  // ---------- 1. the host ----------
  sec(31.0, () => ({ tt: at('number one') + .3, n: 1, title: 'The Host',
    bg: t => tgKitchen(t),
    ch: {
      A: { x: [[at('then actually try'), 300], [at('then actually try') + .9, 700]], o: look('boy'), k: K([0, 'neutral'], [at('this person'), 'surprised'], [at('ask them if'), 'hopeful'], [at('then actually try'), 'happy'], [at('doing it wrong'), 'scared'], [at('by the time'), 'neutral'], [at('not dry'), 'relieved'], [at('nine more times'), 'bored']) },
      B: { x: [[at('three timers'), 1000], [at('three timers') + .7, 1500], [at('oven is full') , 1500], [at('oven is full') + .7, 1200], [at('casserole'), 1200], [at('casserole') + .7, 1050]], o: look('host'),
        k: K([0, 'nervous'], [at('three timers'), 'nervous'], [at('oven is full'), 'nervous', hold('turkey')], [at('casserole'), 'dizzy'], [at('they\'ll say'), 'happy'], [at('doing it wrong'), 'angry'], [at('open the oven'), 'furious'], [at('until christmas'), 'angry'], [at('by the time'), 'sleepy'], [at('watching everyone'), 'nervous', { lookX: -.8 }], [at('not dry'), 'shy'], [at('nine more times'), 'nervous', { lookX: -.8 }]) },
    },
    bub: [[at('three timers'), at('oven is full'), 'B', 'clock'], [at('oven is full'), at('casserole'), 'B', 'turkey'], [at('casserole'), at('ask them if'), 'B', ['stuffing', '?']], [at('they\'ll say'), at('then actually try'), 'B', 'check'], [at('open the oven'), at('by the time'), 'B', 'cross'], [at('is it good'), at('not dry'), 'B', ['turkey', '?']], [at('nine more times'), at('nine more times') + 2.4, 'B', ['turkey', '?']]],
    cam: [[0, 'W'], [at('ask them if'), 'T'], [at('open the oven'), 'B'], [at('by the time'), 'W'], [at('watching everyone'), 'B'], [at('not dry'), 'T']],
  }));

  // ---------- 2. the carver ----------
  sec(73.3, () => ({ tt: at('number two') + .3, n: 2, title: 'The Turkey Carver',
    bg: t => tgDining(t),
    over: t => { const shred = t > at('paper shredder'); tgTable(t, ['pie', 'potato', shred ? 'stuffing' : 'turkey', 'roll', 'pie']); },
    ch: {
      C: { x: 560, o: look('host'), k: K([0, 'happy'], [at('nobody is allowed'), 'scared'], [at('starving'), 'sad'], [at('paper shredder'), 'surprised'], [at('perfect cut'), 'happy']) },
      B: { x: 960, o: look('carver'), k: K([0, 'neutral'], [at('picks up'), 'determined', hold('knife')], [at('completely different'), 'cool', hold('knife')], [at('nobody is allowed'), 'angry', hold('knife')], [at('there are rules'), 'determined', hold('knife')], [at('sharpens'), 'determined', hold('knife', 'R', 1.2)], [at('paper shredder'), 'proud', hold('knife')], [at('perfect cut'), 'proud']) },
      D: { x: 1350, o: look('uncle'), k: K([0, 'happy'], [at('nobody is allowed'), 'nervous'], [at('starving'), 'sad'], [at('paper shredder'), 'disgusted'], [at('perfect cut'), 'smug']) },
      A: { x: 1680, o: look('boy'), k: K([0, 'happy'], [at('there are rules'), 'nervous'], [at('starving'), 'sad'], [at('paper shredder'), 'confused'], [at('not say a word'), 'nervous'], [at('you smile'), 'happy', hold('plate')], [at('perfect cut'), 'happy', hold('plate')]) },
    },
    bub: [[at('watched a video'), at('sharpens'), 'B', 'tv'], [at('sharpens'), at('starving'), 'B', 'clock'], [at('starving'), at('and then'), 'D', 'turkey'], [at('food is getting cold'), at("he's got a technique"), 'A', 'cold']],
    cam: [[0, 'W'], [at('picks up'), 'B'], [at('nobody is allowed'), 'T'], [at('starving'), 'W'], [at('paper shredder'), [960, 700, 1.5]], [at('not say a word'), 'A'], [at('perfect cut'), 'T']],
  }));

  // ---------- 3. the uncle ----------
  sec(114.1, () => ({ tt: at('number three') + .3, n: 3, title: 'The Uncle With Opinions',
    bg: t => tgDining(t), over: t => tgTable(t),
    shake: t => { const a = at('three people are yelling'); return t > a && t < a + 1.3 ? 12 * Math.exp(-(t - a) * 3) : 0; },
    ch: {
      D: { x: 560, o: look('oldwoman', { hat: 'bow', old: true }), k: K([0, 'happy'], [at('no politics'), 'suspicious'], [at('hearing aid'), 'laugh'], [at('nobody changes'), 'bored']) },
      B: { x: 960, o: look('uncle'), k: K([0, 'smug'], [at('as a challenge'), 'mischief'], [at('starts small'), 'neutral', hold('potato')], [at('did you see the news'), 'smug'], [at('three people are yelling'), 'furious'], [at('not even mad'), 'laugh'], [at('super bowl'), 'proud'], [at('nobody changes'), 'smug'], [at('round two'), 'mischief']) },
      C: { x: 1340, o: look('carver'), k: K([0, 'happy'], [at('no politics'), 'nervous'], [at('did you see the news'), 'suspicious'], [at('three people are yelling'), 'angry'], [at('googling'), 'determined', hold('phone')], [at('nobody changes'), 'bored']) },
      A: { x: 1680, o: look('boy'), k: K([0, 'happy'], [at('no politics'), 'nervous'], [at('as a challenge'), 'scared'], [at('three people are yelling'), 'angry'], [at('not even mad'), 'confused'], [at('nobody changes'), 'bored'], [at('round two'), 'sad']) },
    },
    bub: [[at('no politics'), at('as a challenge'), 'A', ['tv', 'cross']], [at('did you see the news'), at('five minutes later'), 'B', 'news'], [at('hearing aid'), at('googling'), 'D', 'popcorn'], [at('googling'), at('and honestly'), 'C', 'chart'], [at('round two'), at('round two') + 2.2, 'B', 'anger']],
    cam: [[0, 'W'], [at('as a challenge'), 'B'], [at('starts small'), 'T'], [at('three people are yelling'), 'W'], [at('hearing aid'), 'D'], [at('googling'), 'C'], [at('not even mad'), 'B'], [at('nobody changes'), 'W']],
  }));

  // ---------- 4. the aunt ----------
  sec(154.0, () => ({ tt: at('number four') + .3, n: 4, title: 'The Aunt With All the Questions',
    bg: t => tgDoor(t, { door: 1600 }),
    ch: {
      A: { x: 700, o: look('boy'), k: K([0, 'neutral'], [at('coat off'), 'surprised'], [at('seeing anyone'), 'nervous'], [at('finish line'), 'dizzy'], [at('how much you make'), 'nervous'], [at('little weight'), 'surprised'], [at('say you\'re single'), 'scared'], [at('your number'), 'ko'], [at('with love'), 'neutral'], [at('makes it worse'), 'sad']) },
      B: { x: [[at('coat off') - .3, 2300], [at('coat off') + 1.2, 1150]], o: look('aunt'), k: K([0, 'excited'], [at('seeing anyone'), 'excited'], [at('the wedding'), 'starstruck'], [at('the baby'), 'excited'], [at('how much you make'), 'suspicious'], [at('little weight'), 'smug'], [at('say you\'re single'), 'mischief'], [at('accountant'), 'excited'], [at('your number'), 'proud'], [at('with love'), 'love']) },
    },
    bub: [[at('seeing anyone'), at('say yes'), 'B', 'heart'], [at('the wedding'), at('get married'), 'B', 'ring'], [at('the baby'), at('have a baby'), 'B', 'bottle'], [at('second one'), at('no finish line'), 'B', ['bottle', 'bottle']], [at('how much you make'), at('jobs'), 'B', 'coin'], [at('jobs'), at('little weight'), 'B', 'doc'], [at('little weight'), at('appetizers') + .6, 'B', 'cake'], [at('nephew'), at('accountant'), 'B', 'heart'], [at('accountant'), at('very tall'), 'B', 'chart'], [at('your number'), at('the worst part'), 'B', 'phone']],
    cam: [[0, 'W'], [at('seeing anyone'), 'T'], [at('finish line'), 'A'], [at('how much you make'), 'T'], [at('say you\'re single'), 'B'], [at('your number'), 'A'], [at('the worst part'), 'T']],
  }));

  // ---------- 5. the kid ----------
  sec(194.3, () => ({ tt: at('number five') + .3, n: 5, title: 'The Kid Glued to the iPad',
    bg: t => { tgLiving(t); sofa(960, 700, '#8A5A3C'); },
    ch: {
      A: { x: 420, o: look('boy'), k: K([0, 'neutral'], [at('zero words'), 'confused'], [at('honestly fair'), 'smug'], [at('wi'), 'laugh'], [at('dinner rolls'), 'neutral'], [at('smartest person'), 'starstruck']) },
      B: { x: [[at('disappear'), 960], [at('disappear') + 1.4, -320]], u: UU * .68, o: look('kid'), k: K([0, 'bored', hold('tablet')], [at('volume'), 'playful', hold('tablet')], [at('looks up'), 'neutral', { lookX: -.6 }], [at('goes right back'), 'bored', hold('tablet')], [at('wi'), 'hopeful', hold('tablet')], [at('dinner rolls'), 'happy', hold('roll')], [at('disappear'), 'happy']) },
      C: { x: [[at('somebody says') - .2, 2300], [at('somebody says') + .9, 1450], [at('honestly fair'), 1450], [at('honestly fair') + 1.2, 2300]], o: look('host'), k: K([0, 'angry'], [at('goes right back'), 'confused']) },
    },
    bub: [[at('volume'), at('headphones'), 'B', 'music'], [at('headphones'), at('somebody says'), 'B', 'headphones' in ICON ? 'headphones' : ['music', 'cross']], [at('somebody says'), at('looks up'), 'C', 'tablet'], [at('wi'), at('dinner rolls'), 'B', 'wifi'], [at('pie comes out'), at('truly'), 'A', 'pie']],
    cam: [[0, 'W'], [at('zero words'), 'B'], [at('somebody says'), 'T'], [at('honestly fair'), 'A'], [at('wi'), 'B'], [at('dinner rolls'), 'W']],
  }));

  // ---------- 6. the football guy ----------
  sec(226.7, () => ({ tt: at('number six') + .3, n: 6, title: 'The Football Guy',
    bg: t => tgLiving(t),
    shake: t => { const a = at('referee'); return t > a && t < a + 1 ? 9 * Math.exp(-(t - a) * 4) : 0; },
    ch: {
      A: { x: 380, o: look('boy'), k: K([0, 'neutral'], [at('about the game'), 'confused'], [at('remember your name'), 'sad'], [at('team loses'), 'nervous'], [at('calm him down'), 'relieved']) },
      B: { x: 1050, o: look('fan'), k: K([0, 'excited', hold('football')], [at('eats standing'), 'happy', hold('plate')], [at('referee'), 'furious'], [at('stats'), 'smug'], [at('jersey'), 'proud'], [at('bad play'), 'angry'], [at('team loses'), 'cry'], [at('calm him down'), 'relieved', hold('slice')]) },
      C: { x: [[at('grandma has to') - .2, 2300], [at('grandma has to') + 1.3, 1350]], o: look('oldwoman', { hat: 'bow', old: true }), k: K([0, 'happy', hold('slice', 'L')], [at('calm him down'), 'love']) },
    },
    bub: [[at('referee'), at('stats'), 'B', 'whistle'], [at('stats'), at('remember your name'), 'B', 'chart'], [at('remember your name'), at('jersey'), 'B', ['?', '?']], [at('team loses'), at('grandma has to'), 'B', 'broken']],
    cam: [[0, 'W'], [at('referee'), 'B'], [at('remember your name'), 'A'], [at('jersey'), 'T'], [at('team loses'), 'B'], [at('grandma has to'), 'W']],
  }));

  // ---------- 7. the store-bought pie ----------
  sec(256.9, () => ({ tt: at('number seven') + .3, n: 7, title: 'The Store-Bought Pie',
    bg: t => tgDoor(t, { door: 1650 }),
    ch: {
      A: { x: 330, o: look('boy'), k: K([0, 'neutral'], [at('price sticker'), 'smug'], [at('receipt'), 'laugh'], [at('aisle seven'), 'smug'], [at('first thing'), 'happy', hold('slice')]) },
      C: { x: 640, o: look('host'), k: K([0, 'happy'], [at('price sticker'), 'suspicious'], [at('family recipe'), 'suspicious'], [at('aisle seven'), 'laugh'], [at('first thing'), 'happy']) },
      B: { x: [[at('they walk in') - .2, 2300], [at('they walk in') + 1.4, 1150]], o: look('piegirl'), k: K([0, 'happy', hold('piebox', 'R', .85, 1.6)], [at('try to hide'), 'nervous', hold('piebox', 'R', .85, 1.6)], [at('nice plate'), 'nervous', hold('pie', 'R', .85, 1.5)], [at('family recipe'), 'smug', hold('pie', 'R', .85, 1.5)], [at('receipt'), 'scared'], [at('aisle seven'), 'shy'], [at('first thing'), 'proud']) },
    },
    bub: [[at('price sticker'), at('some of them'), 'C', 'piebox'], [at('family recipe'), at('bonus points'), 'B', 'heart'], [at('receipt'), at('putty'), 'B', 'doc'], [at('aisle seven'), at('but honestly'), 'A', 'coin']],
    cam: [[0, 'W'], [at('they walk in') + 1, 'B'], [at('price sticker'), 'T'], [at('family recipe'), 'B'], [at('putty'), 'A'], [at('first thing'), 'W']],
  }));

  // ---------- 8. the vegan cousin ----------
  sec(284.9, () => ({ tt: at('number eight') + .3, n: 8, title: 'The Vegan Cousin',
    bg: t => tgDining(t), over: t => tgTable(t, ['pie', 'turkey', 'tofu', 'roll', 'pie'], { gap: 330 }),
    ch: {
      A: { x: 520, o: look('boy'), k: K([0, 'neutral'], [at('heard about it twice'), 'bored'], [at("it's gray"), 'disgusted'], [at('presentation'), 'sleepy'], [at('pass the gravy'), 'hopeful', hold('gravy')], [at('end of the night'), 'neutral'], [at("nobody's looking"), 'smug']) },
      B: { x: [[at('end of the night'), 960], [at('end of the night') + .8, 1200]], o: look('vegan'), k: K([0, 'proud'], [at('tofu turkey'), 'proud'], [at('nobody is touching'), 'sad'], [at('presentation'), 'excited'], [at('butter'), 'scared'], [at('end of the night'), 'mischief', hold('stuffing')], [at("nobody's looking"), 'playful', hold('stuffing')]) },
      C: { x: 1400, o: look('uncle'), k: K([0, 'happy'], [at("it's gray"), 'suspicious'], [at('nobody is touching'), 'disgusted'], [at('what do you even eat'), 'confused'], [at('presentation'), 'bored'], [at("nobody's looking"), 'surprised']) },
    },
    bub: [[at('went vegan three'), at('before you even'), 'B', 'leaf'], [at('tofu turkey'), at("it's gray"), 'B', 'tofu'], [at('what do you even eat'), at("now we're"), 'C', '?'], [at('protein'), at('pass the gravy'), 'B', 'dumbbell'], [at('butter'), at('butter') + 2.2, 'B', ['butter', 'cross']]],
    cam: [[0, 'W'], [at('tofu turkey'), [960, 700, 1.45]], [at('nobody is touching'), 'W'], [at('what do you even eat'), 'C'], [at('presentation'), 'T'], [at('butter'), 'B'], [at('end of the night'), 'W']],
  }));

  // ---------- 9. grandpa's food coma ----------
  sec(320.4, () => ({ tt: at('number nine') + .3, n: 9, title: 'The Food Coma Champion',
    bg: t => tgLiving(t, { recliner: 820, night: t > at('four hours later') }),
    ch: {
      A: { x: 320, o: look('boy'), k: K([0, 'neutral'], [at('snoring'), 'laugh'], [at('scientists'), 'confused'], [at('talks around him'), 'neutral'], [at('what did i miss'), 'laugh']) },
      B: { x: 820, o: look('grandpa', { sit: 5, old: true }), k: K([0, 'happy', hold('plate')], [at('two slices'), 'starstruck', hold('slice')], [at('rest his eyes'), 'sleepy'], [at('fork still'), 'sleepy', hold('fork')], [at('talks around him'), 'sleepy'], [at('put things on his head'), 'sleepy', { hat: 'party' }], [at('wakes up'), 'surprised', { hat: 'party' }], [at('what did i miss'), 'confused', { hat: 'party' }]) },
      C: { x: [[at('put things on his head') - .2, 1500], [at('put things on his head') + .8, 1080], [at('wakes up'), 1080], [at('wakes up') + .7, 1500]], u: UU * .68, o: look('kid'), k: K([0, 'bored', hold('tablet')], [at('put things on his head'), 'mischief'], [at('wakes up'), 'scared']) },
    },
    bub: [[at('second plate'), at('two slices'), 'B', 'plate'], [at('two slices'), at('then he sits'), 'B', ['slice', 'slice']], [at('snoring'), at('nobody knows'), 'A', 'tv']],
    cam: [[0, 'W'], [at('rest his eyes'), 'B'], [at('scientists'), 'A'], [at('fork still'), 'B'], [at('talks around him'), 'W'], [at('wakes up'), 'B']],
  }));

  // ---------- 10. the food photographer ----------
  const flashTimes = [];
  sec(356.7, () => {
    const p = at('47'); for (let i = 0; i < 7; i++) flashTimes.push(p + i * .32);
    const ws = at('wait nobody');
    return { tt: at('number 10') + .3, n: 10, title: 'The Food Photographer',
      bg: t => tgDining(t), over: t => tgTable(t, ['pie', 'potato', t > at('turned into jelly') ? 'jelly' : 'turkey', 'roll', 'pie']),
      under: (t, R) => { if (t > at('standing on chairs') && t < at('by the time')) { const x = R.p.B.x; boilSeed('chair'); rc(x - 90, GY - 230, 180, 30, FALL.wood, 1); for (const d of [-70, 60]) rc(x + d, GY - 205, 18, 200, FALL.woodDk, .9); } },
      screen: t => flashes(t, flashTimes),
      ch: {
        A: { x: 520, o: look('boy'), k: K([0, 'hopeful'], [at('forks are up'), 'excited', hold('fork')], [ws, 'surprised', hold('fork')], [at('standing on chairs'), 'bored', hold('fork')], [at('turned into jelly'), 'sad'], [at('hangry'), 'angry']) },
        C: { x: 850, o: look('uncle'), k: K([0, 'hopeful'], [at('forks are up'), 'excited', hold('fork')], [ws, 'surprised'], [at('chewing'), 'laugh', { mouth: 'laugh' }], [at('so blessed'), 'bored'], [at('hangry'), 'furious']) },
        B: { x: 1250, o: look('instagirl'), pose: t => (t > at('standing on chairs') && t < at('by the time')) ? { dy: -2.2 } : null,
          k: K([0, 'happy'], [ws, 'determined', hold('camera', 'L', 1, 1.5)], [at('closer to the window'), 'determined', hold('camera', 'L', 1, 1.5)], [at('47'), 'happy', hold('camera', 'L', 1, 1.5)], [at('perfect shot'), 'proud', hold('camera', 'L', 1, 1.5)], [at('so blessed'), 'love', hold('phone', 'L')], [at('hangry'), 'shy']) },
        D: { x: 1600, o: look('host'), k: K([0, 'happy'], [ws, 'confused'], [at('turned into jelly'), 'sad'], [at('hangry'), 'angry']) },
      },
      bub: [[at('47'), at('and somehow'), 'B', 'potato'], [at('turned into jelly'), at('the caption'), 'A', 'jelly'], [at('so blessed'), at('meanwhile'), 'B', 'heart'], [at('hangry'), at('hangry') + 2.4, 'A', 'anger']],
      cam: [[0, 'W'], [at('forks are up'), 'T'], [ws, 'B'], [at('standing on chairs'), 'W'], [at('chewing'), 'C'], [at('by the time'), 'T'], [at('so blessed'), 'B'], [at('hangry'), 'W']] };
  });

  // ---------- 11. the late arrival ----------
  sec(393.0, () => ({ tt: at('number 11') + .3, n: 11, title: 'The Late Arrival',
    bg: t => tgDoor(t, { door: 1650 }),
    ch: {
      A: { x: 330, o: look('boy'), k: K([0, 'neutral'], [at('dinner was at two'), 'bored'], [at('no traffic'), 'smug'], [at('good tupperware'), 'surprised'], [at('never see that'), 'sad']) },
      C: { x: 650, o: look('host'), k: K([0, 'neutral'], [at('dinner was at two'), 'bored'], [at('traffic was crazy'), 'suspicious'], [at("didn't cook"), 'angry'], [at('good tupperware'), 'furious'], [at('never see that'), 'cry']) },
      B: { x: [[at('they walk in') - .2, 2300], [at('they walk in') + 1.2, 1200], [at('favor'), 1200], [at('favor') + 1.4, 2300]], o: look('late', { hat: 'beanie' }), k: K([0, 'cool'], [at('traffic was crazy'), 'nervous'], [at("didn't cook"), 'cool'], [at('six containers'), 'happy', hold('tupper', 'R', .9, 1.6)], [at('same time next year'), 'excited', hold('tupper', 'R', .9, 1.6)]) },
    },
    bub: [[at('dinner was at two'), at('they walk in'), 'C', 'clock'], [at('traffic was crazy'), at('no traffic'), 'B', 'car'], [at('six containers'), at('good tupperware'), 'B', 'tupper'], [at('same time next year'), at('favor') + .8, 'B', 'heart']],
    cam: [[0, 'W'], [at('they walk in') + 1, 'B'], [at('no traffic'), 'A'], [at("didn't cook"), 'T'], [at('six containers'), 'B'], [at('good tupperware'), 'C'], [at('on the way out'), 'W']],
  }));

  // ---------- 12. grandma ----------
  sec(427.2, () => {
    const dusk = at('end of the night'), quiet = at('goes quiet');
    return { tt: at('number 12') + .3, n: 12, title: 'Grandma',
      bg: t => tgDining(t, { night: t > dusk, warm: ease(seg(t, dusk, quiet + 2)) }), over: t => tgTable(t),
      ch: {
        D: { x: 330, o: look('carver'), k: K([0, 'happy'], [at('one look'), 'nervous'], [at('end of the night'), 'sleepy'], [quiet, 'relieved'], [at('whole point'), 'love']) },
        A: { x: 650, o: look('boy'), k: K([0, 'happy'], [at('did wrong'), 'nervous'], [at('too skinny'), 'confused'], [at('bigger than your head'), 'surprised', hold('plate', 'R', .9, 2.4)], [at('one look'), 'happy'], [at('end of the night'), 'sleepy'], [quiet, 'relieved'], [at('whole point'), 'love']) },
        B: { x: 960, o: look('oldwoman', { hat: 'bow', old: true }), k: K([0, 'proud'], [at('notes on'), 'smug'], [at('every birthday'), 'happy'], [at('too skinny'), 'sad'], [at('bigger than your head'), 'happy'], [at('one look'), 'angry'], [at('end of the night'), 'relieved'], [at('around the table'), 'love'], [quiet, 'relieved']) },
        C: { x: 1280, o: look('uncle'), k: K([0, 'happy'], [at('end an argument'), 'furious'], [at('one look'), 'scared'], [at('end of the night'), 'bored'], [at('even the uncle'), 'relieved'], [at('whole point'), 'love']) },
        E: { x: 1560, u: UU * .68, o: look('kid'), k: K([0, 'bored', hold('tablet')], [at('kid with the ipad'), 'relieved'], [at('whole point'), 'love']) },
      },
      bub: [[at('notes on'), at('she tells you'), 'B', 'doc'], [at('every birthday'), at('allergy'), 'B', 'cake'], [at('did wrong'), at('too skinny'), 'B', 'clock'], [at('around the table'), quiet, 'B', 'thanks'], [at('whole point'), at('whole point') + 4, 'B', 'heart']],
      cam: [[0, 'W'], [at('notes on'), 'B'], [at('bigger than your head'), 'A'], [at('end an argument'), 'T'], [at('end of the night'), 'W'], [at('around the table'), 'B'], [quiet, 'W'], [at('whole point'), [960, 620, 1.15]]] };
  });

  // ---------- 13. outro ----------
  sec(479.1, () => {
    const fam = (x, name, extra = {}) => ({ x, y: GY - 50, u: UU * .8, o: look(name, extra), k: K([0, 'happy']), pose: t => move('bounce', t + x * .001, x % 7) });
    return {
      bg: t => { tgDining(t, { warm: .6 }); leavesFalling(t, 8); },
      ch: {
        F1: fam(150, 'carver'), F2: fam(380, 'aunt'), F3: fam(1540, 'vegan'), F4: fam(1770, 'fan'), F5: fam(610, 'piegirl'), F6: fam(1310, 'instagirl'),
        C: { x: 790, o: look('uncle'), k: K([0, 'happy'], [at('uncle who needs'), 'surprised'], [at('send it to him'), 'nervous']) },
        A: { x: 1000, o: look('boy'), pose: t => t > at('happy thanksgiving') ? { aL: 1.2 + .5 * Math.sin(t * 13) } : null, k: K([0, 'happy'], [at('which one are you'), 'playful', { lookX: 0 }], [at('send it to him'), 'laugh'], [at('hit like'), 'excited'], [at('save me some pie'), 'happy', hold('slice')]) },
        B: { x: 1150, o: look('oldwoman', { hat: 'bow', old: true }), k: K([0, 'love'], [at('happy thanksgiving'), 'happy']) },
      },
      bub: [[at('which one are you'), at('tell us'), 'A', '?'], [at('uncle who needs'), at('send it to him') + .8, 'C', 'phone'], [at('hit like'), at('happy thanksgiving'), 'A', 'heart']],
      cam: [[0, 'W'], [at('which one are you'), 'T'], [at('uncle who needs'), 'C'], [at('hit like'), 'W']] };
  });

  // ---------- timeline ----------
  const WIPES = [[FALL.runner, '#E3A33B'], ['#9A5F36', '#E07A2E'], ['#D2493A', '#F6EBD6'], ['#E3A33B', '#9A5F36']];
  SEC.forEach(prepSection);
  const last = SEC.length - 1;
  shots(SEC.map((S, i) => [S.t0, (t, lt, dur) => {
    const R = runSection(S, t);
    boilSeed('transition');
    if (i === 0 && lt < .6) iris(...R.eye, lerp(0, 1500, easeIn(lt / .6)));
    if (i > 0 && lt < .3) brushWipe(.5 + lt / .6, WIPES[i % WIPES.length]);
    if (i < last && lt > dur - .3) brushWipe((lt - (dur - .3)) / .6, WIPES[(i + 1) % WIPES.length]);
    if (i === last && t > DUR_TG - 1.6) { const mid = [960, 560]; iris(mid[0], mid[1], t < DUR_TG - 1 ? lerp(1500, 380, ease(seg(t, DUR_TG - 1.6, DUR_TG - 1))) : t < DUR_TG - .45 ? 380 : lerp(380, 0, easeIn(seg(t, DUR_TG - .45, DUR_TG - .05)))); }
  }]));
})();
