"""Thanksgiving voiceover: Kokoro (ONNX, local) per line -> one WAV with natural pauses, plus line timings and
Whisper word timings in the same format as out/vo/words.json.
    <faceless venv python> scripts/tg_voice.py scripts/thanksgiving_vo.tsv out/tg
"""
import csv, json, os, sys, wave
import numpy as np

tsv, out = sys.argv[1], sys.argv[2]
voice = sys.argv[3] if len(sys.argv) > 3 else 'am_michael'
speed = float(sys.argv[4]) if len(sys.argv) > 4 else 1.0
os.makedirs(out, exist_ok=True)
K = os.path.expanduser('~/.faceless-shorts/kokoro')
from kokoro_onnx import Kokoro
kok = Kokoro(f'{K}/kokoro-v1.0.onnx', f'{K}/voices-v1.0.bin')

rows = list(csv.DictReader(open(tsv, encoding='utf-8'), delimiter='\t'))
SR = 24000
parts, lines, t = [], [], 0.0
prev_sec = None
for r in rows:
    sec = r['id'].split('_')[0]
    gap = 1.1 if (prev_sec is not None and sec != prev_sec) else (.45 if prev_sec is not None else .3)
    parts.append(np.zeros(int(gap * SR), np.float32)); t += gap
    samples, sr = kok.create(r['text'], voice=voice, speed=speed, lang='en-us')
    assert sr == SR
    samples = np.asarray(samples, np.float32)
    lines.append({'id': r['id'], 'sec': sec, 's': round(t, 3), 'e': round(t + len(samples) / SR, 3), 't': r['text']})
    parts.append(samples); t += len(samples) / SR
    prev_sec = sec
    print(f"{r['id']} {len(samples) / SR:.2f}s", flush=True)
parts.append(np.zeros(int(1.5 * SR), np.float32))
audio = np.concatenate(parts)
audio = audio / max(1e-6, np.abs(audio).max()) * .89
with wave.open(f'{out}/voiceover.wav', 'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((audio * 32767).astype(np.int16).tobytes())
json.dump(lines, open(f'{out}/lines.json', 'w', encoding='utf-8'), indent=1)
print(f'total {len(audio) / SR:.1f}s')

from faster_whisper import WhisperModel
m = WhisperModel('small.en', device='cpu', compute_type='int8')
segs, _ = m.transcribe(f'{out}/voiceover.wav', word_timestamps=True, beam_size=5, language='en')
words = []
for s in segs:
    words.append({'s': round(s.start, 2), 'e': round(s.end, 2), 't': s.text.strip(), 'w': [[round(w.start, 2), round(w.end, 2), w.word.strip()] for w in s.words]})
json.dump(words, open(f'{out}/words.json', 'w', encoding='utf-8'), indent=0)
print(f'{sum(len(s["w"]) for s in words)} words timed')
