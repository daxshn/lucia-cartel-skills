// couples.js: "Every Type of Couple" (10:38), cut to assets/voiceover.mp3. All times are voiceover seconds.
// A = Clawd, B = Clawdi (bow), C / D = friends. Each section is a spec for runSection() in couples_kit.js.
(() => {
  const ph = hold('phone'), pl = hold('phone', 'L');
  const SKY = '#A8D5EF', NIGHT = '#2F3C7A';
  const win = (t, spans) => spans.some(([a, b]) => t >= a && t < b);
  const pop = (t, a, b = 1e9) => backOut(seg(t, a, a + .25)) * (1 - ease(seg(t, b - .2, b)));
  const SEC = [];

  // ---------- 0. intro ----------
  SEC.push({ t0: 0,
    bg: t => park(t, 0), under: () => { benchBack(1360, 560); benchSeat(1360, 560); },
    ch: {
      A: { x: 520, k: [[0, 'neutral', { lookX: 0 }], [2.6, 'sad', { emote: null }], [4.3, 'bored', { lookX: .8 }], [8.6, 'neutral'], [11.6, 'excited', hold('popcorn', 'L')], [14.4, 'disgusted'], [18.4, 'idea'], [21.5, 'playful', { lookX: 0 }], [23.6, 'shy'], [25.7, 'relieved'], [28.6, 'excited']] },
      B: { x: 1170, look: .6, o: { hat: 'bow', sit: true }, k: [[0, 'happy'], [4.3, 'love'], [8.6, 'happy'], [11.6, 'angry'], [14.4, 'love'], [18.4, 'happy']] },
      D: { x: 1550, look: -.6, o: { hat: 'beanie', sit: true }, k: [[0, 'happy'], [4.6, 'love'], [8.6, 'happy'], [11.8, 'furious'], [14.6, 'love'], [18.4, 'happy']] },
    },
    bub: [[21.5, 23.4, 'A', '?']],
    cam: [[0, 'A'], [4.3, [1360, 650, 1.4]], [8.6, 'W'], [18.4, 'A'], [28.6, 'W']] });

  // ---------- 1. bickering ----------
  SEC.push({ t0: 30.3, tt: 30.7, n: 1, title: 'The Bickering Couple',
    bg: () => { room({ wall: '#F2D9C4', floor: '#C9A27E', win: [850, 150, 220, 200, SKY, 'sun'], rug: '#D98C7A' }); picture(380, 300, PAL.teal); picture(1560, 300, PAL.ochre); sofa(960, 900, '#7FA6C9'); },
    over: t => { if (t > 59.8) { boilSeed('fries'); const k = pop(t, 60.0); push(); translate(960, GY - 60); scale(k); el(0, 40, 90, 20, PAL.cream, 1); icon('fries', 0, -20, 56); pop(); } },
    shake: t => t > 48.4 && t < 49.4 ? 12 * Math.exp(-(t - 48.4) * 4) : 0,
    ch: {
      A: { x: 640, k: [[0, 'neutral'], [33.7, 'sleepy'], [37.4, 'surprised'], [39.6, 'angry'], [42.2, 'determined'], [43.2, 'furious'], [43.9, 'determined'], [45.0, 'furious'], [45.9, 'determined'], [48.4, 'furious'], [50.5, 'angry', { view: 'qback', flip: true }], [54.4, 'hopeful'], [60.2, 'happy'], [63.8, 'suspicious', { lookX: -1 }], [66.1, 'laugh'], [68.0, 'neutral']] },
      B: { x: 1280, o: { hat: 'bow' }, k: [[0, 'neutral'], [33.7, 'sleepy'], [36.5, 'angry'], [42.2, 'determined'], [43.3, 'furious'], [43.9, 'determined'], [45.1, 'furious'], [45.9, 'determined'], [48.5, 'furious'], [50.5, 'angry', { view: 'qback' }], [53.4, 'shy', { lookX: -.8 }], [60.2, 'happy'], [63.8, 'suspicious', { lookX: -1 }], [66.1, 'love'], [68.0, 'neutral']] },
      C: { x: [[57.7, -260], [59.6, 250]], look: .6, o: { hat: 'beanie' }, k: [[0, 'determined'], [60.2, 'surprised'], [62.9, 'confused'], [64.3, 'nervous'], [66.1, 'bored'], [69.6, 'scared']] },
    },
    bub: [[36.5, 39.4, 'B', 'phone'], [42.2, 43.8, 'A', 'pizza'], [42.5, 43.8, 'B', 'burger'], [43.9, 45.7, 'A', 'tv'], [44.2, 45.7, 'B', 'tv'], [45.9, 48.2, 'A', 'cold'], [46.3, 48.2, 'B', 'hot'], [53.4, 55.5, 'B', 'fries']],
    cam: [[0, 'W'], [33.7, 'T'], [36.5, 'B'], [39.6, 'T'], [49.4, 'W'], [53.4, 'B'], [55.7, 'W'], [60.2, 'T'], [62.9, 'C'], [66.1, 'T'], [69.6, 'C']] });

  // ---------- 2. long distance ----------
  SEC.push({ t0: 73.1, tt: 73.6, n: 2, title: 'The Long Distance Couple',
    bg: t => {
      room({ wall: '#F6E3B8', floor: '#C9A27E', win: [240, 170, 220, 200, SKY, 'sun'] }); picture(700, 300, PAL.rose);
      const D = kf(t, [[104.6, 960], [105.9, 2600]]);
      if (D < 2500) {
        boilSeed('night'); paint(rectPts(D, -400, 2700 - D, 1900), { wash: '#39407A', ink: null }); paint(rectPts(D, GY - 70, 2700 - D, 700), { wash: '#272C56', ink: null });
        if (D < 1380) { rc(1386, 156, 248, 228, PAL.cream, 1); paint(rectPts(1400, 170, 220, 200), { wash: '#1F2550', ink: PAL.ink, sw: .8 }); el(1550, 240, 30, 30, PAL.cream, .5, null); paint(ellPts(1564, 232, 26, 26, 14), { wash: '#1F2550', ink: null }); }
        inkLine([[D, -100], [D + 4, 250], [D, 560]], 3, PAL.ink, 'ink', .3); inkLine([[D, 560], [D - 4, 850], [D, 1200]], 3, PAL.ink, 'ink', .3);
      }
    },
    ch: {
      A: { x: [[104.6, 480], [106.2, 850]], k: [[0, 'happy', ph], [76.4, 'neutral', ph], [80.9, 'hopeful', ph], [81.7, 'happy', ph], [86.0, 'sleepy', hold('phone', 'R', .1)], [89.2, 'surprised', ph], [91.7, 'scared', ph], [93.4, 'neutral', ph], [96.1, 'angry', ph], [100.8, 'confused', ph], [103.2, 'angry', ph], [104.6, 'excited'], [106.4, 'love'], [111.7, 'hopeful'], [116.5, 'neutral'], [118.1, 'proud']] },
      B: { x: [[104.6, 1440], [106.2, 1070]], bd: 1, o: { hat: 'bow' }, k: [[0, 'happy', pl], [76.4, 'neutral', pl], [80.9, 'hopeful', pl], [81.7, 'happy', pl], [86.2, 'sleepy', hold('phone', 'L', .1)], [89.4, 'surprised', pl], [91.7, 'neutral', pl], [96.3, 'angry', pl], [102.1, 'confused', pl], [104.6, 'excited'], [106.4, 'love'], [111.7, 'hopeful'], [116.5, 'neutral'], [118.3, 'proud']] },
      C: { x: [[106.7, 2300], [108.3, 1580]], look: -.7, o: { hat: 'hard' }, k: [[0, 'neutral'], [108.9, 'cry']] },
    },
    bub: [[79.0, 81.5, 'A', 'wifi'], [79.9, 81.5, 'B', 'battery'], [81.7, 83.7, 'A', 'pizza'], [81.9, 83.7, 'B', 'pizza'], [83.9, 85.8, 'A', 'tv'], [84.1, 85.8, 'B', 'tv'], [91.7, 93.2, 'A', 'battery'],
      [96.1, 98.4, 'A', 'nowifi'], [96.3, 98.4, 'B', 'nowifi'], [100.8, 102, 'A', '?'], [103.2, 104.4, 'B', '?'], [106.7, 108.7, 'A', 'plane'], [111.7, 116.3, 'B', 'clock']],
    cam: [[0, 'W'], [91.7, [480, 650, 1.4]], [93.4, 'W'], [106.4, 'T'], [108.9, 'C'], [111.7, 'T']] });

  // ---------- 3. baby talk ----------
  const duo3 = [750, 640, 1.38];
  SEC.push({ t0: 121.4, tt: 121.9, n: 3, title: 'The Baby Talk Couple',
    bg: () => { room({ wall: '#F7CFD6', floor: '#B98557' }); picture(1150, 280, PAL.rose); picture(1480, 300, PAL.ochre); sofa(750, 700, '#C9566A'); },
    over: () => { table(1000, 1500, '#E9D9B8'); boilSeed('plates'); for (const x of [620, 880, 1480]) el(x, GY - 96, 70, 14, PAL.cream, .9); icon('cake', 750, GY - 130, 34); },
    ch: {
      A: { x: 620, k: [[0, 'love'], [128.9, 'shy'], [131.7, 'neutral', { lookX: 0 }], [135.8, 'smug'], [137.8, 'love'], [144.4, 'confused'], [147.4, 'love'], [160.2, 'happy', ph], [162.9, 'playful', ph], [164.1, 'love', ph], [165.5, 'playful', ph]] },
      B: { x: 880, bd: 1, o: { hat: 'bow' }, k: [[0, 'love'], [128.9, 'happy', hold('cake', 'L')], [131.7, 'love'], [144.6, 'confused'], [147.4, 'love'], [160.2, 'happy', pl], [162.9, 'love', pl], [164.1, 'playful', pl], [165.5, 'love', pl]] },
      C: { x: 1480, look: -.7, o: { hat: 'beanie' }, k: [[0, 'bored'], [125.0, 'nervous'], [127.0, 'dizzy'], [128.9, 'disgusted'], [137.8, 'bored'], [154.6, 'sleepy'], [157.8, 'sad'], [160.2, 'bored'], [166.7, 'furious'], [168.2, 'cry']] },
    },
    bub: [[134.6, 135.7, 'A', 'house'], [135.8, 137.6, 'A', 'pizza'], [139.9, 140.6, 'A', 'heart'], [140.5, 141.2, 'B', 'heart'], [141.1, 141.8, 'A', 'cake'], [141.7, 142.4, 'B', 'star'], [142.3, 143.2, 'A', 'flower'], [143.0, 144.2, 'B', 'dog'], [157.8, 159.9, 'C', '?']],
    cam: [[0, duo3], [125.0, 'C'], [128.9, duo3], [131.7, 'A'], [137.8, duo3], [147.4, 'W'], [154.6, 'C'], [160.2, duo3], [166.7, 'C']] });

  // ---------- 4. foodie ----------
  const PILE = [['burger', -210, 0], ['pizza', -70, 0], ['fries', 70, 0], ['cake', 210, 0], ['popcorn', -140, 1], ['burger', 0, 1], ['pizza', 140, 1], ['cake', 0, 2]];
  const wide4 = t => ({ sx: 1 + .38 * ease(seg(t, 211.1, 215.2)) });
  SEC.push({ t0: 171.5, tt: 172.0, n: 4, title: 'The Foodie Couple',
    bg: () => { room({ wall: '#F6E3B8', floor: '#B98557', win: [850, 130, 220, 190, SKY, 'sun'] }); picture(400, 280, '#D2493A'); picture(1520, 280, PAL.teal); },
    over: t => {
      table(960, 1150, '#E9D9B8');
      PILE.forEach(([n, dx, row], i) => { const k = pop(t, 184.4 + i * .14, 197.6 + i * .25); if (k > .03) { boilSeed('pile' + i); push(); translate(960 + dx, GY - 130 - row * 78); scale(k); icon(n, 0, 0, 50); pop(); } });
      const ks = pop(t, 200.1, 208.2); if (ks > .03) { boilSeed('slice'); push(); translate(lerp(960, 1140, ease(seg(t, 202.9, 203.7))), GY - 128); scale(ks); el(0, 40, 80, 16, PAL.cream, .9); icon('pizza', 0, 0, 46); pop(); }
    },
    ch: {
      A: { x: 640, pose: wide4, k: [[0, 'excited'], [174.6, 'love'], [178.8, 'angry'], [180.6, 'happy'], [184.4, 'starstruck'], [191.3, 'love'], [194.6, 'hopeful'], [197.5, 'neutral'], [200.1, 'determined', { lookX: .6, lookY: .7 }], [202.7, 'shy'], [206.3, 'proud'], [209.3, 'neutral'], [214.4, 'relieved']] },
      B: { x: 1280, pose: wide4, o: { hat: 'bow' }, k: [[0, 'excited'], [176.8, 'love'], [178.8, 'angry'], [180.6, 'happy'], [184.4, 'starstruck'], [191.3, 'bored'], [194.6, 'love'], [197.5, 'neutral'], [200.1, 'determined', { lookX: -.6, lookY: .7 }], [203.2, 'surprised'], [205.5, 'cry'], [209.3, 'neutral'], [214.4, 'relieved']] },
      C: { x: 1740, look: -.8, o: { hat: 'top' }, k: [[0, 'neutral'], [186.7, 'nervous'], [188.7, 'scared']] },
    },
    bub: [[174.6, 176.6, 'A', 'pizza'], [176.8, 178.6, 'B', 'cake'], [180.6, 182.2, 'A', 'fries'], [180.8, 182.2, 'B', 'burger'], [191.3, 194.4, 'A', 'heart'], [194.6, 197.3, 'A', ['pizza', '?']]],
    cam: [[0, 'W'], [174.6, 'T'], [186.7, [1500, 640, 1.3]], [191.3, 'A'], [194.6, 'T'], [200.1, [960, 700, 1.45]], [205.5, 'B'], [206.6, 'T'], [209.3, 'W']] });

  // ---------- 5. gym ----------
  const lifting = t => t > 232.6 && t < 237.6;
  SEC.push({ t0: 217.1, tt: 217.6, n: 5, title: 'The Gym Couple',
    bg: () => { room({ wall: '#C9D6DF', floor: '#8E9AA6', win: [1540, 150, 220, 200, '#39407A', 'moon'] }); mirror(960, 460, 340); boilSeed('rack'); for (let i = 0; i < 3; i++) icon('dumbbell', 200 + i * 110, GY - 40, 40); },
    over: (t, R) => { if (lifting(t)) { const p = R.p.A, y = GY - 16.4 * UU * TU * (1 - .45 * (p.o.sq || 0)); boilSeed('bar'); inkLine([[p.x - 250, y], [p.x + 250, y]], 3.2, '#4A4263', 'ink', 0); for (const d of [-1, 1]) { rc(p.x + d * 215 - 16, y - 62, 32, 124, '#4A4263', 1); rc(p.x + d * 250 - 11, y - 44, 22, 88, '#6B6482', .8); } } },
    screen: t => flashes(t, [246.2]),
    ch: {
      A: { x: 640, o: { hat: 'sweatband' }, pose: t => lifting(t) ? { aL: 1.5, aR: 1.5, dy: 0, rot: 0, sq: .13 + .13 * Math.sin((t - 232.6) * TAU * .8) } : null,
        k: [[0, 'determined'], [222.7, 'disgusted'], [224.5, 'happy', hold('shaker')], [226.1, 'determined'], [232.6, 'determined', { lookX: 0 }], [237.8, 'hopeful', hold('flower')], [239.2, 'proud', hold('tub', 'R', .5, 1.7)], [241.9, 'cry'], [244.7, 'cool'], [249.7, 'proud'], [252.3, 'surprised', { lookX: -.8 }], [255.4, 'angry', { lookX: -.8 }]] },
      B: { x: 1280, o: { hat: 'bow' }, k: [[0, 'determined'], [222.7, 'disgusted'], [224.7, 'happy', hold('shaker', 'L')], [226.1, 'determined'], [232.8, 'starstruck'], [235.1, 'love'], [237.8, 'bored'], [239.4, 'starstruck'], [241.9, 'happy'], [244.7, 'cool'], [249.7, 'proud'], [252.5, 'surprised', { lookX: -.9 }], [255.6, 'angry', { lookX: -.9 }]] },
      C: { x: [[252.0, -260], [253.3, 250]], look: .7, o: { hat: 'beanie' }, k: [[0, 'happy'], [253.4, 'playful'], [255.4, 'nervous'], [257.5, 'sleepy'], [259.5, 'dizzy']] },
    },
    bub: [[222.7, 224.3, 'A', ['cake', 'cross']], [226.1, 229.8, 'B', 'clock'], [241.9, 244.5, 'A', 'coin'], [253.4, 255.3, 'C', ['pizza', '?']], [255.4, 257.4, 'A', 'dumbbell'], [256.2, 258.2, 'B', 'clock'], [257.6, 259.6, 'A', 'shaker'], [258.4, 260.6, 'B', 'dumbbell']],
    cam: [[0, 'W'], [224.5, 'T'], [232.6, [700, 600, 1.3]], [235.1, 'B'], [237.8, 'T'], [244.7, [960, 560, 1.25]], [252.3, 'W']] });

  // ---------- 6. detective ----------
  const mg = hold('mag', 'L', .9, 1.7);
  SEC.push({ t0: 261.8, tt: 262.3, n: 6, title: 'The Detective Couple',
    bg: () => { room({ wall: '#474C80', floor: '#2E3260', win: [1500, 150, 220, 200, '#1F2550', 'moon'] }); picture(900, 280, '#6B6482'); lamp(300, 1); },
    screen: t => flashes(t, [287.3]),
    ch: {
      A: { x: 640, k: [[0, 'neutral'], [267.0, 'nervous'], [269.8, 'surprised'], [271.3, 'scared'], [277.1, 'neutral', { lookX: 0, ...hold('cup') }], [279.5, 'nervous'], [282.2, 'sad', { emote: null, ...hold('doc') }], [285.8, 'scared'], [292.0, 'nervous'], [298.4, 'neutral'], [300.3, 'smug'], [301.8, 'happy'], [303.5, 'nervous', { view: 'qback', flip: true }], [307.6, 'scared', { view: 'q', flip: true }]] },
      B: { x: [[269.8, 1280], [270.3, 1180], [271.3, 1180], [271.8, 1080], [272.6, 1080], [273.1, 990], [303.5, 990], [304.3, 1150], [307.6, 1150], [308.2, 960]], bd: 1, o: { hat: 'fedora' },
        k: [[0, 'suspicious', mg], [269.8, 'angry', mg], [277.1, 'suspicious', mg], [279.5, 'determined', mg], [286.9, 'mischief', hold('camera', 'L', 1, 1.5)], [288.2, 'suspicious', mg], [292.0, 'thinking'], [293.9, 'idea'], [298.4, 'confused'], [301.8, 'shy'], [303.5, 'suspicious', mg], [307.6, 'mischief', mg]] },
      C: { x: [[288.2, -260], [289.4, 240], [291.4, 240], [292.4, -260]], look: .7, o: { hat: 'beanie' }, k: [[0, 'happy'], [289.4, 'nervous'], [290.4, 'scared']] },
    },
    bub: [[269.8, 271.2, 'B', ['phone', 'heart']], [271.3, 272.5, 'B', '?'], [272.6, 274.9, 'B', 'wifi'], [275.0, 277, 'B', ['moon', 'clock']], [279.5, 282, 'A', 'lock'], [285.8, 288, 'A', 'pin'], [293.9, 296, 'B', 'doc'], [296.1, 298.2, 'B', 'clock'], [298.4, 301.5, 'B', ['milk', '?']], [301.8, 303.3, 'B', 'heart']],
    cam: [[0, 'W'], [264.6, 'B'], [267.0, 'A'], [269.8, 'T'], [277.1, 'A'], [279.5, 'T'], [288.2, 'W'], [292.0, 'B'], [300.3, 'T'], [303.5, 'A'], [307.6, 'T']] });

  // ---------- 7. on again, off again ----------
  SEC.push({ t0: 311.2, tt: 311.7, n: 7, title: 'The On-Again, Off-Again Couple',
    bg: t => park(t, .45),
    ch: {
      A: { x: [[321.7, 640], [322.7, 330], [325.0, 330], [326.2, 850], [326.9, 850], [327.9, 600], [336.8, 600], [338.0, 850], [351.4, 850], [352.4, 600], [355.0, 600], [355.9, 760], [357.0, 760], [357.9, 480], [360.1, 480], [361.2, 850]],
        k: [[0, 'neutral'], [319.0, 'happy'], [320.3, 'sad', { emote: null }], [321.7, 'angry'], [323.0, 'sad'], [325.0, 'love'], [326.7, 'bored'], [329.5, 'sad', { emote: null }], [336.8, 'love'], [343.7, 'angry', ph], [344.9, 'hopeful', ph], [346.0, 'angry', ph], [347.6, 'confused'], [349.5, 'angry'], [353.4, 'shy', ph], [357.0, 'angry'], [360.1, 'love']] },
      B: { x: [[321.7, 1280], [322.7, 1590], [325.0, 1590], [326.2, 1070], [326.9, 1070], [327.9, 1320], [336.8, 1320], [338.0, 1070], [351.4, 1070], [352.4, 1320], [355.0, 1320], [355.9, 1160], [357.0, 1160], [357.9, 1440], [360.1, 1440], [361.2, 1070]], bd: 1, o: { hat: 'bow' },
        k: [[0, 'neutral'], [319.0, 'happy'], [320.3, 'sad', { emote: null }], [321.7, 'angry'], [323.2, 'cry'], [325.0, 'love'], [326.7, 'angry'], [329.5, 'bored'], [336.8, 'love'], [343.7, 'angry', pl], [344.9, 'hopeful', pl], [346.0, 'angry', pl], [347.6, 'confused'], [349.5, 'furious'], [353.6, 'shy', pl], [357.0, 'angry'], [360.3, 'love']] },
      C: { x: [[329.5, -260], [330.8, 230]], look: .7, o: { hat: 'beanie' }, k: [[0, 'neutral'], [331.9, 'smug', { lookX: .6 }], [336.8, 'surprised'], [341.9, 'nervous']] },
    },
    bub: [[315.8, 318.8, 'A', 'wifi'], [319.0, 320.2, 'B', 'heart'], [320.3, 321.6, 'B', 'broken'], [321.9, 322.9, 'A', 'broken'], [323.0, 324.8, 'A', 'heart'], [326.7, 329.3, 'B', 'broken'], [331.9, 336.6, 'C', ['broken', 'check']],
      [343.7, 344.8, 'B', 'cross'], [344.9, 345.9, 'B', 'check'], [346.0, 347.5, 'B', 'cross'], [347.6, 349.3, 'A', ['phone', '?']], [355.0, 356.8, 'A', 'phone']],
    cam: [[0, 'W'], [315.8, 'T'], [321.7, 'W'], [331.9, [430, 650, 1.35]], [336.8, 'W'], [341.9, 'C'], [343.7, 'T'], [349.5, 'W'], [360.1, 'T']] });

  // ---------- 8. just friends ----------
  SEC.push({ t0: 364.0, tt: 364.5, n: 8, title: 'The "Just Friends" Couple',
    bg: t => { const n = t > 373.5 && t < 377; room({ wall: '#D9E6D2', floor: '#B98557', win: [850, 150, 220, 200, n ? '#1F2550' : SKY, n ? 'moon' : 'sun'], rug: '#A9C3D9' }); picture(420, 290, PAL.ochre); picture(1500, 290, PAL.rose); },
    ch: {
      A: { x: 640, k: [[0, 'happy'], [370.7, 'confused'], [373.5, 'happy', ph], [377.0, 'happy'], [378.7, 'sad', { emote: 'sweat', tint: 'green', tintK: .5 }], [380.9, 'hopeful'], [383.6, 'nervous'], [385.1, 'shy'], [390.2, 'happy'], [399.5, 'shy'], [401.5, 'happy'], [403.3, 'neutral'], [408.4, 'surprised']] },
      B: { x: [[379.9, 1280], [381.0, 950], [382.3, 950], [383.2, 1280]], o: { hat: 'bow' }, k: [[0, 'laugh'], [370.7, 'confused'], [373.5, 'happy', pl], [377.0, 'happy'], [378.9, 'surprised'], [379.9, 'determined', hold('soup', 'L')], [382.3, 'happy'], [383.6, 'nervous'], [385.1, 'shy'], [390.2, 'happy'], [399.5, 'shy'], [401.5, 'love'], [403.3, 'neutral'], [408.4, 'surprised']] },
      C: { x: 250, look: .8, o: { hat: 'beanie' }, k: [[0, 'suspicious'], [382.3, 'playful'], [387.0, 'smug'], [395.2, 'bored'], [399.5, 'neutral'], [408.4, 'excited']] },
      D: { x: [[390.0, 2300], [391.2, 1680]], look: -.8, o: { hat: 'top' }, k: [[0, 'smug'], [395.2, 'bored'], [399.5, 'neutral'], [408.4, 'excited']] },
    },
    bub: [[367.6, 370.5, 'C', 'heart'], [373.5, 376.8, 'A', 'moon'], [377.0, 378.6, 'A', 'pizza'], [377.2, 378.6, 'B', 'pizza'], [382.3, 383.5, 'C', ['heart', '?']], [391.9, 393.2, 'D', 'heart'], [393.3, 395, 'C', 'cup'], [395.2, 399.3, 'D', 'clock'], [401.5, 403.2, 'A', 'heart'], [401.7, 403.2, 'B', 'heart']],
    cam: [[0, 'T'], [367.6, 'C'], [370.7, 'T'], [382.3, 'C'], [383.6, 'T'], [387.0, 'C'], [390.2, 'W'], [399.5, 'T'], [403.3, 'W']] });

  // ---------- 9. instagram ----------
  const camOn = t => win(t, [[0, 416.4], [434.2, 436.9], [455.2, 457.6]]);
  const cm = hold('camera', 'L', 1, 1.5);
  SEC.push({ t0: 410.4, tt: 410.9, n: 9, title: 'The Instagram Couple',
    bg: () => { room({ wall: '#F2D9C4', floor: '#B98557', win: [850, 130, 220, 190, SKY, 'sun'] }); picture(420, 280, PAL.violet); picture(1500, 280, PAL.teal); },
    over: (t, R) => {
      table(960, 620, '#E9D9B8'); if (t > 417.5 && t < 447) { boilSeed('burger'); el(960, GY - 96, 90, 16, PAL.cream, .9); icon('burger', 960, GY - 140, 54); }
      if (t > 441.4 && t < 447) { const L = 950 * easeOut(seg(t, 441.6, 445.3)) * (1 - ease(seg(t, 446.4, 447))), x = R.p.B.x - 150; boilSeed('scroll'); rc(x - L, GY + 20, L + 70, 74, PAL.paper, 1); for (let i = 0; i * 70 < L; i++) { inkLine([[x - i * 70 + 40, GY + 42], [x - i * 70 + 40, GY + 76]], .9, '#7C7390', 'inkfine', 0); } rc(x, GY - 150, 70, 180, PAL.paper, 1); }
    },
    screen: t => {
      flashes(t, [420.0, 425.6, 426.2, 426.8, 427.4, 428.5, 429.5, 430.7, 431.3]);
      if (camOn(t)) { boilSeed('finder'); for (const [sx, sy] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) inkLine([[960 + sx * 800, 540 + sy * 320], [960 + sx * 800, 540 + sy * 440], [960 + sx * 680, 540 + sy * 440]], 3.2, PAL.cream, 'ink', 0); if (Math.floor(t * 2) % 2) el(1680, 150, 20, 20, '#D2493A', .8); }
    },
    ch: {
      A: { x: 640, k: [[0, 'love'], [416.6, 'bored', ph], [417.5, 'neutral'], [420.9, 'sad', { emote: null, lookY: .6 }], [425.5, 'happy', { lookX: 0 }], [428.2, 'laugh'], [429.0, 'confused'], [430.4, 'neutral', { lookX: 0 }], [431.6, 'ko'], [434.2, 'love'], [437.0, 'angry'], [441.4, 'sleepy'], [445.3, 'surprised'], [447.0, 'neutral'], [455.2, 'love'], [457.7, 'sad']] },
      B: { x: [[423.1, 1280], [423.9, 1130], [424.6, 1130], [425.4, 1300]], o: { hat: 'bow' }, k: [[0, 'love'], [416.6, 'bored', pl], [418.8, 'determined', cm], [431.6, 'angry', cm], [434.2, 'love'], [437.0, 'angry'], [441.4, 'determined', pl], [447.0, 'happy', pl], [455.2, 'love'], [457.7, 'sad']] },
      C: { x: [[447.0, -260], [448.3, 250]], look: .5, o: { hat: 'beanie' }, k: [[0, 'neutral', ph], [448.5, 'starstruck', ph], [451.4, 'sad', ph]] },
    },
    bub: [[420.9, 423, 'A', 'burger'], [434.2, 436.8, 'B', 'globe'], [445.3, 446.9, 'A', 'cake'], [451.4, 453.5, 'C', '?']],
    cam: [[0, 'T'], [417.5, 'W'], [425.5, 'A'], [431.6, 'T'], [441.4, 'W'], [448.5, 'C'], [453.7, 'T']] });

  // ---------- 10. opposites ----------
  const guest = (x, hat, style, seed) => ({ x, y: GY - 80, u: 21, look: 0, o: { hat }, k: [[0, 'happy']], pose: t => move(style, t + seed * .13, seed) });
  SEC.push({ t0: 461.9, tt: 462.4, n: 10, title: 'The Opposites Couple',
    bg: () => { room({ wall: '#E7D4F0', floor: '#B98557', rug: '#E9B8C4' }); bunting(110); },
    under: t => doggo(215, t, 1.15),
    ch: {
      G1: guest(1010, 'party', 'bounce', 1), G2: guest(1270, 'top', 'sway', 2), G3: guest(1560, 'crown', 'roof', 3),
      A: { x: [[482.2, 640], [483.6, 410], [497.4, 410], [498.6, 800]], o: { hat: 'headphones' }, k: [[0, 'neutral'], [465.0, 'shy'], [469.2, 'bored'], [477.7, 'suspicious'], [482.2, 'love'], [485.4, 'neutral'], [487.6, 'smug'], [490.9, 'neutral'], [494.0, 'sleepy'], [497.4, 'happy'], [499.4, 'starstruck'], [501.8, 'relieved'], [507.8, 'happy'], [509.3, 'love']] },
      B: { x: [[474.3, 1280], [475.0, 1660], [475.8, 1110], [476.6, 1500], [477.4, 1280], [497.4, 1280], [498.6, 1120]], bd: 1, o: { hat: 'bow' }, k: [[0, 'happy'], [466.2, 'excited'], [467.2, 'starstruck'], [469.2, 'happy'], [485.4, 'excited'], [487.6, 'confused'], [490.9, 'excited', pl], [494.0, 'happy'], [499.4, 'idea'], [501.8, 'relieved'], [507.8, 'happy'], [509.5, 'love']] },
    },
    bub: [[469.2, 471.6, 'A', 'house'], [485.4, 487.4, 'B', 'music'], [487.6, 490.7, 'A', 'moon'], [490.9, 493.8, 'B', ['phone', 'music']], [494.0, 497.2, 'A', 'mute'], [499.4, 501.6, 'B', 'globe']],
    cam: [[0, 'W'], [465.0, 'A'], [466.2, 'B'], [469.2, 'A'], [471.8, 'W'], [477.7, 'A'], [485.4, 'T'], [490.9, 'B'], [494.0, 'A'], [497.4, 'T']] });

  // ---------- 11. lazy ----------
  const night11 = t => win(t, [[528.9, 533.8], [537.8, 547.5]]), tvOn = t => win(t, [[528.9, 533.8], [547.5, 553.5]]);
  const lean = (t, t0, d) => ({ rot: d * .09 * ease(seg(t, t0, t0 + .8)) });
  const sofa11 = [820, 630, 1.32];
  SEC.push({ t0: 512.3, tt: 512.8, n: 11, title: 'The Lazy Couple',
    bg: t => { const n = night11(t); room({ wall: n ? '#8E84B0' : '#D9CFE8', floor: n ? '#7A5F48' : '#B98557', win: [170, 150, 220, 200, n ? '#1F2550' : SKY, n ? 'moon' : 'sun'] }); sofa(820, 780, '#7FA6C9'); tvSet(1600, t, tvOn(t)); lamp(1290, t > 539.3 && t < 547.5 ? 1 : 0); },
    over: t => {
      boilSeed('blanket'); pw(rrPts(500, GY - 150, 640, 190, 50), '#6FA8A0', 1.2); for (let i = 0; i < 5; i++) inkLine([[560 + i * 130, GY - 140], [550 + i * 130, GY + 30]], 2, '#4F8880', 'ink', .2);
      if (t > 547.3 && t < 553.6) { boilSeed('remote'); push(); translate(1200, GY + 40); rotate(1.2); icon('remote', 0, 0, 38); pop(); for (let i = 0; i < 3; i++) { const k = frac(t * .9 + i / 3); paint(starPts(1200 + (i - 1) * 60, GY - 20 - 60 * k, 14 * (1 - k), .3, 4), { wash: PAL.ochre, ink: null }); } }
    },
    ch: {
      A: { x: 700, pose: t => lean(t, 555.9, 1), k: [[0, 'sleepy'], [515.9, 'relieved'], [519.5, 'idea'], [521.5, 'excited'], [523.2, 'neutral'], [524.6, 'neutral', { lookX: .9 }], [525.9, 'shy'], [528.9, 'happy', { lookX: .8 }], [530.6, 'sleepy'], [533.8, 'angry'], [537.8, 'neutral'], [539.3, 'determined', { lookX: .9 }], [545.1, 'angry'], [547.5, 'sad', { emote: null, lookX: .9, lookY: .6 }], [550.7, 'love'], [553.5, 'neutral'], [555.9, 'relieved'], [560.4, 'happy']] },
      B: { x: 940, bd: 1, pose: t => lean(t, 555.9, -1), o: { hat: 'bow' }, k: [[0, 'sleepy'], [515.9, 'relieved'], [520.6, 'excited'], [523.2, 'neutral'], [524.6, 'neutral', { lookX: -.9 }], [526.1, 'shy'], [528.9, 'happy', { lookX: .8 }], [530.8, 'sleepy'], [534.0, 'angry'], [537.8, 'neutral'], [539.5, 'determined', { lookX: .9 }], [545.3, 'furious'], [547.7, 'sad', { emote: null, lookX: .9, lookY: .6 }], [550.9, 'love'], [553.5, 'neutral'], [555.9, 'relieved'], [560.4, 'happy']] },
    },
    bub: [[519.5, 523, 'A', 'plane'], [525.9, 528.7, 'A', 'pizza'], [533.8, 537.6, 'A', ['tv', '?']], [534.2, 537.6, 'B', ['tv', '?']], [539.5, 545, 'B', 'bulb'], [545.1, 547.3, 'A', 'clock'], [553.5, 554.7, 'A', ['gift', 'cross']], [554.8, 555.8, 'B', ['plane', 'cross']]],
    cam: [[0, sofa11], [523.2, 'W'], [524.6, [820, 640, 1.45]], [528.9, 'W'], [533.8, [820, 640, 1.45]], [537.8, 'W'], [547.5, [1000, 680, 1.25]], [550.7, 'W'], [553.5, sofa11]] });

  // ---------- 12. the old couple ----------
  const specs = (u, sw) => { for (const d of [-1, 1]) paint(ellPts(d * 2.5 * u, -6 * u, 1.35 * u, 1.35 * u, 18), { ink: PAL.ink, sw: sw * .9 }); inkLine([[-1.15 * u, -6 * u], [1.15 * u, -6 * u]], sw * .9, PAL.ink, 'ink', 0); };
  SEC.push({ t0: 563.8, tt: 566.1, n: 12, title: 'The Old Couple',
    bg: t => park(t, .85), under: () => { benchBack(960, 760); benchSeat(960, 760); },
    ch: {
      A: { x: 810, take: .45, o: { draw: specs, old: true, sit: true }, pose: t => lean(t, 596, 1), k: [[0, 'happy'], [571.1, 'angry'], [573.4, 'neutral'], [576.9, 'confused'], [578.6, 'neutral'], [582.3, 'shy'], [584.9, 'surprised'], [587.6, 'hopeful', hold('cup')], [589.9, 'neutral', hold('cup')], [596.0, 'relieved'], [604.3, 'happy'], [608.2, 'relieved']] },
      B: { x: 1110, take: .45, bd: 1, o: { hat: 'bow', draw: specs, old: true, sit: true }, pose: t => lean(t, 596, -1), k: [[0, 'happy'], [571.3, 'angry'], [573.4, 'neutral'], [575.6, 'determined'], [578.6, 'angry'], [580.2, 'neutral'], [582.5, 'happy'], [584.9, 'happy', hold('cup', 'L')], [587.0, 'happy'], [589.9, 'neutral'], [596.0, 'relieved'], [604.3, 'happy'], [608.2, 'relieved']] },
    },
    bub: [[575.6, 576.8, 'B', 'pill'], [576.9, 578.5, 'A', 'glasses'], [578.6, 580, 'B', 'tv'], [580.2, 582.2, 'A', ['heart', 'cross']], [582.3, 584.7, 'A', 'cold'], [587.6, 589.7, 'B', 'clock'], [589.9, 591.5, 'A', 'anger'], [591.6, 592.9, 'B', 'plane'], [593.0, 594.1, 'A', 'broken'], [594.1, 595.8, 'B', 'heart'], [606.4, 609.6, 'B', 'heart']],
    cam: [[0, 'W'], [568.6, [960, 620, 1.3]], [575.6, [960, 640, 1.42]], [589.9, [960, 620, 1.3]], [597.9, 'W'], [604.3, [960, 600, 1.15]]] });

  // ---------- 13. outro ----------
  const fan = (x, hat, style, seed) => ({ x, y: GY - 120, u: 18, look: 0, o: { hat }, k: [[0, 'happy']], pose: t => move(style, t + seed * .17, seed) });
  const wave = t => win(t, [[611.1, 613.6], [637, 640]]) ? { aL: 1.2 + .5 * Math.sin(t * 13) } : null;
  SEC.push({ t0: 610.6,
    bg: t => park(t, 0),
    ch: {
      F1: fan(190, 'party', 'bounce', 1), F2: fan(460, 'crown', 'sway', 2), F3: fan(1460, 'top', 'roof', 3), F4: fan(1730, 'cat', 'hop', 4), F5: fan(1560 - 950, 'beanie', 'wave', 5), F6: fan(1310, 'flower', 'bounce', 6),
      A: { x: 820, pose: wave, k: [[0, 'happy'], [613.9, 'playful', { lookX: 0 }], [617.1, 'happy'], [621.1, 'smug'], [623.9, 'cool'], [625.8, 'mischief'], [627.7, 'happy'], [629.3, 'relieved', { emote: null }], [630.8, 'proud'], [633.8, 'excited'], [637.0, 'happy']] },
      B: { x: 1100, bd: 1, o: { hat: 'bow' }, k: [[0, 'happy'], [617.1, 'playful', pl], [621.1, 'smug'], [623.9, 'happy'], [633.8, 'excited'], [637.0, 'love']] },
    },
    bub: [[613.9, 616.9, 'A', '?'], [627.7, 629.2, 'A', 'coin'], [629.3, 630.7, 'A', 'moon'], [630.8, 633.6, 'A', 'fullbat'], [633.8, 636.6, 'A', 'heart'], [634.2, 636.6, 'B', 'star']],
    cam: [[0, 'W'], [613.9, 'T'], [623.9, 'A'], [633.8, 'W']] });

  // ---------- timeline ----------
  const WIPES = [[PAL.clayDk, PAL.clay], ['#5E8F4E', '#E8C766'], [PAL.teal, PAL.cream], [PAL.rose, PAL.cream], [PAL.ochre, PAL.clay], ['#4A4263', PAL.violet]];
  // every couple type gets its own outfits (the tall cast); extra fields seat them on the sofa
  const OUTFIT = [['boy', 'girl'], ['boy2', 'girl2'], ['boy', 'girl'], ['boy3', 'sweet', { sit: 5 }], ['boy2', 'foodgirl'], ['gymboy', 'gym'], ['detboy', 'detgirl'],
    ['boy3', 'egirl'], ['boy', 'extrovert'], ['boy2', 'instagirl'], ['introboy', 'extrovert'], ['pjboy', 'pjgirl', { sit: 5 }], ['oldman', 'oldwoman', { draw: null }], ['boy', 'girl']];
  SEC.forEach((S, i) => { const [a, b, ex] = OUTFIT[i] || OUTFIT[0]; S.ch.A.o = { ...(S.ch.A.o || {}), look: a, ...(ex || {}) }; S.ch.B.o = { ...(S.ch.B.o || {}), look: b, ...(ex || {}) }; });
  SEC.forEach(prepSection);
  shots(SEC.map((S, i) => [S.t0, (t, lt, dur) => {
    const R = runSection(S, t);
    boilSeed('transition');
    if (i === 0 && lt < .6) iris(...R.eye, lerp(0, 1500, easeIn(lt / .6)));
    if (i > 0 && lt < .3) brushWipe(.5 + lt / .6, WIPES[i % WIPES.length]);
    if (i < SEC.length - 1 && lt > dur - .3) brushWipe((lt - (dur - .3)) / .6, WIPES[(i + 1) % WIPES.length]);
    if (i === SEC.length - 1 && t > 636.4) { const mid = toScreen(960, GY - 150, { cx: 960, cy: 540, zoom: 1, rot: 0 }); iris(mid[0], mid[1], t < 637 ? lerp(1500, 360, ease(seg(t, 636.4, 637))) : t < 637.6 ? 360 : lerp(360, 0, easeIn(seg(t, 637.6, 638))));
    }
  }]));
})();
