// bf_thumb.js: vertical cover for the Black Friday short.  node render.mjs --page=studio_bf.html --loop=bfthumb --stills=0.4 --out=out/bf/thumb
LOOPS.bfthumb = t => {
  const F = s => `900 ${s}px "Segoe UI Black", "Arial Black", Impact, sans-serif`;
  const STILL = { dy: 0, sq: 0, rot: 0, dx: 0, squint: 0, emote: null };
  boilSeed('bt bg'); paint(rectPts(-100, -100, W + 200, H + 200), { wash: '#1E1A22', ink: null });
  const C = [540, 1150];
  for (let i = 0; i < 20; i++) { const a0 = i / 20 * TAU, a1 = a0 + TAU / 40; boilSeed('bt ray' + i); paint([C, [C[0] + Math.cos(a0) * 2600, C[1] + Math.sin(a0) * 2600], [C[0] + Math.cos(a1) * 2600, C[1] + Math.sin(a1) * 2600]], { wash: '#B3122A', ink: null }); }
  glow(540, 1150, 700, '#FF5A3A', .55);
  // the last TV, and two people who will not let go of it
  boilSeed('bt tv'); icon('tvbox', 540, 1300, 230);
  tall(250, 1850, 52, { ...feel('furious', 0), ...STILL, eyes: 'angry', mouth: 'teeth', look: 'wrestA', boilKey: 'bta', aR: .05, aL: -.5, rot: .05, emote: 'anger', emoteK: 1 });
  tall(830, 1850, 52, { ...feel('furious', 0), ...STILL, eyes: 'angry', mouth: 'open', look: 'wrestB', boilKey: 'btb', flip: true, aR: .05, aL: -.5, rot: .05, emote: 'anger', emoteK: 1 });
  boilSeed('bt bolt'); paint([[560, 760], [515, 880], [565, 875], [520, 1010], [605, 840], [555, 845], [598, 760]], { wash: '#FFD23A', ink: PAL.ink, sw: 3 });
  // title block
  boilSeed('bt top'); push(); translate(540, 250); rotate(-.03); paint(rrPts(-500, -195, 1000, 410, 50, 4), { wash: '#FFD23A', ink: PAL.ink, sw: 4 }); pop();
  letter('EVERY TYPE OF', 540, 150, 92, '#1E1A22', { font: F(92), rot: -.03, ink: false });
  letter('BLACK', 540, 262, 150, '#D2333A', { font: F(150), rot: -.03, stroke: '#1E1A22' });
  letter('FRIDAY', 540, 392, 150, '#D2333A', { font: F(150), rot: -.03, stroke: '#1E1A22' });
  boilSeed('bt tag1'); push(); translate(250, 600); rotate(-.12); paint(rrPts(-150, -62, 300, 124, 24, 3), { wash: '#FFFFFF', ink: PAL.ink, sw: 3 }); pop();
  letter('-70%', 250, 604, 84, '#D2333A', { font: F(84), rot: -.12, ink: false });
  boilSeed('bt tag2'); push(); translate(820, 620); rotate(.1); paint(rrPts(-200, -62, 400, 124, 24, 3), { wash: '#FFFFFF', ink: PAL.ink, sw: 3 }); pop();
  letter('LAST ONE!', 820, 624, 70, '#1E1A22', { font: F(70), rot: .1, ink: false });
  letter('WHICH ONE ARE YOU?', 540, 1640, 76, '#FFFFFF', { font: F(76), stroke: '#1E1A22' });
};
LOOPS.bfthumb.len = 1;
