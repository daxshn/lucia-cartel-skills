import bpy, sys, os, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import kit
bpy.ops.wm.read_factory_settings(use_empty=True)
kit.render_settings(16)
kit.build_city()
import realism
realism.apply()
out = os.path.join(HERE, "city.blend")
bpy.ops.wm.save_as_mainfile(filepath=out)
print("SAVED", out, len(bpy.data.objects), "objects")
