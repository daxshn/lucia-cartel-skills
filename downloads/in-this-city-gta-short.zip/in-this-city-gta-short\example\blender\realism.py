"""Realism pass: Poly Haven CC0 PBR textures + HDRI lighting on top of the procedural kit."""
import bpy, math, os
import numpy as np
from mathutils import Vector
import kit

ASSETS = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "assets")
TEX = os.path.join(ASSETS, "tex")


def _img(n, name, noncolor=False):
    t = n.new("ShaderNodeTexImage")
    t.image = bpy.data.images.load(os.path.join(TEX, name), check_existing=True)
    if noncolor:
        t.image.colorspace_settings.name = "Non-Color"
    t.projection = 'BOX'
    t.projection_blend = 0.3
    return t


def pbr(m, prefix, scale, tint="none", rough_mul=1.0, keep_rough_link=False, nstrength=1.0, bsdf_name="Principled BSDF"):
    nt = m.node_tree
    n, l = nt.nodes, nt.links
    b = n.get(bsdf_name)
    tc = n.new("ShaderNodeTexCoord")
    mp = n.new("ShaderNodeMapping")
    mp.inputs["Scale"].default_value = (scale, scale, scale)
    l.new(tc.outputs["Object"], mp.inputs["Vector"])
    d = _img(n, f"{prefix}_diff_2k.jpg")
    r = _img(n, f"{prefix}_rough_2k.jpg", True)
    nm = _img(n, f"{prefix}_nor_gl_2k.jpg", True)
    for t in (d, r, nm):
        l.new(mp.outputs[0], t.inputs["Vector"])
    for lk in list(b.inputs["Base Color"].links):
        src = lk.from_socket
        nt.links.remove(lk)
    else:
        src = None
    if tint == "object":
        oi = n.new("ShaderNodeObjectInfo")
        mx = n.new("ShaderNodeMix"); mx.data_type = 'RGBA'; mx.blend_type = 'MULTIPLY'
        mx.inputs[0].default_value = 1.0
        l.new(oi.outputs["Color"], mx.inputs[6])
        br = n.new("ShaderNodeBrightContrast")
        br.inputs["Bright"].default_value = 0.25
        l.new(d.outputs["Color"], br.inputs["Color"])
        l.new(br.outputs[0], mx.inputs[7])
        l.new(mx.outputs[2], b.inputs["Base Color"])
    elif isinstance(tint, tuple):
        mx = n.new("ShaderNodeMix"); mx.data_type = 'RGBA'; mx.blend_type = 'MULTIPLY'
        mx.inputs[0].default_value = 1.0
        mx.inputs[6].default_value = (*[min(1.0, v) for v in tint], 1)
        bc = n.new("ShaderNodeBrightContrast")
        bc.inputs["Bright"].default_value = 0.32
        bc.inputs["Contrast"].default_value = -0.15
        l.new(d.outputs["Color"], bc.inputs["Color"])
        l.new(bc.outputs[0], mx.inputs[7])
        l.new(mx.outputs[2], b.inputs["Base Color"])
    else:
        l.new(d.outputs["Color"], b.inputs["Base Color"])
    # roughness
    old = [lk.from_socket for lk in b.inputs["Roughness"].links]
    mul = n.new("ShaderNodeMath"); mul.operation = 'MULTIPLY'
    l.new(r.outputs["Color"], mul.inputs[0])
    if keep_rough_link and old:
        l.new(old[0], mul.inputs[1])
    else:
        mul.inputs[1].default_value = rough_mul
    l.new(mul.outputs[0], b.inputs["Roughness"])
    # normal
    for lk in list(b.inputs["Normal"].links):
        nt.links.remove(lk)
    nmap = n.new("ShaderNodeNormalMap")
    nmap.inputs["Strength"].default_value = nstrength
    l.new(nm.outputs["Color"], nmap.inputs["Color"])
    l.new(nmap.outputs[0], b.inputs["Normal"])


def hdri_world(strength=0.7):
    """Camera rays keep the clean sky gradient; lighting + reflections come from the real golden-hour HDRI,
    rotated so the HDRI's sun sits where our sun lamp is."""
    w = bpy.context.scene.world
    nt = w.node_tree
    n, l = nt.nodes, nt.links
    out = n.get("World Output")
    bg_sky = n.get("Background")
    img = bpy.data.images.load(os.path.join(ASSETS, "hdri", "golden_bay_2k.hdr"), check_existing=True)
    W, H = img.size
    px = np.empty(W * H * 4, dtype=np.float32)
    img.pixels.foreach_get(px)
    lum = px.reshape(H, W, 4)[:, :, :3].sum(2)
    yy, xx = np.unravel_index(np.argmax(lum), lum.shape)
    u = (xx + 0.5) / W
    phi_h = (u - 0.5) * 2 * math.pi                      # = atan2(y, -x) of the HDRI sun
    phi_t = math.atan2(kit.SUN_DIR.y, -kit.SUN_DIR.x)    # same for our sun
    env = n.new("ShaderNodeTexEnvironment")
    env.image = img
    tc = n.new("ShaderNodeTexCoord")
    mp = n.new("ShaderNodeMapping")
    mp.inputs["Rotation"].default_value = (0, 0, phi_h - phi_t)
    l.new(tc.outputs["Generated"], mp.inputs["Vector"])
    l.new(mp.outputs[0], env.inputs["Vector"])
    bg_h = n.new("ShaderNodeBackground")
    bg_h.inputs["Strength"].default_value = strength
    l.new(env.outputs[0], bg_h.inputs["Color"])
    lp = n.new("ShaderNodeLightPath")
    mix = n.new("ShaderNodeMixShader")
    l.new(lp.outputs["Is Camera Ray"], mix.inputs[0])
    l.new(bg_h.outputs[0], mix.inputs[1])
    l.new(bg_sky.outputs[0], mix.inputs[2])
    for lk in list(out.inputs["Surface"].links):
        nt.links.remove(lk)
    l.new(mix.outputs[0], out.inputs["Surface"])
    print("HDRI sun at u=%.3f v=%.3f rot=%.1f deg" % (u, (yy + 0.5) / H, math.degrees(phi_h - phi_t)))


def apply():
    M = bpy.data.materials
    pbr(M["road"], "asphalt_02", 0.35, keep_rough_link=True, nstrength=0.8)
    pbr(M["sidewalk"], "worn_tile_floor", 0.45, tint=tuple(2.3 * v for v in kit.lin("#e6dccb")), nstrength=0.9)
    pbr(M["promenade"], "worn_tile_floor", 0.45, tint=tuple(2.3 * v for v in kit.lin("#f0dcb8")), nstrength=0.9)
    pbr(M["lot_concrete"], "worn_tile_floor", 0.2, tint=tuple(2.3 * v for v in kit.lin("#cfcac0")), nstrength=0.5)
    pbr(M["building"], "painted_plaster_wall", 0.3, tint="object", rough_mul=1.0, nstrength=0.7)
    pbr(M["sand"], "coast_sand_01", 0.25, nstrength=1.0)
    pbr(M["ground_dirt"], "coast_sand_01", 0.1, tint=kit.lin("#b0a888"), nstrength=0.6)
    for name in ("cafe_wall", "curb", "bldg_base"):
        if name in M:
            pbr(M[name], "painted_plaster_wall", 0.5, tint=tuple(M[name].diffuse_color[:3]), nstrength=0.6)
    hdri_world(0.7)
    bpy.data.lights["Sun"].energy = 4.5
