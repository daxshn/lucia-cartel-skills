"""Word-timed big captions -> caps/NN.png (1080x1920 transparent) + caps/caps.json [{png, s, e}]."""
import json, os, re, sys
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
words = json.load(open(os.path.join(ROOT, "data", "words.json"), encoding="utf-8"))
lines = json.load(open(os.path.join(ROOT, "data", "lines.json"), encoding="utf-8"))["lines"]
KEY = {0: {"bank", "balance"}, 1: {"two", "thousand"}, 2: {"forty"}, 3: {"doubled"}, 4: {"ticket"}, 5: {"three"},
       6: {"walks", "away"}, 7: {"cop"}, 8: {"minus", "sixty", "thousand"}, 9: {"speeding"}}
FONT = ImageFont.truetype("C:/Windows/Fonts/ariblk.ttf", 104)
W, H, CY, MAXW = 1080, 1920, 1200, 920
YEL, WHITE = (255, 214, 64, 255), (255, 255, 255, 255)
norm = lambda w: re.sub(r"[^a-z0-9]", "", w.lower())

# chunks: up to 3 words, break after punctuation
chunks = []
for li in range(len(lines)):
    ws = [w for w in words if w["line"] == li]
    cur = []
    for k, w in enumerate(ws):
        cur.append(w)
        nxt_last = k + 1 < len(ws) and re.search(r"[,.!?]$", ws[k + 1]["w"]) and len(cur) == 3
        if (len(cur) >= 3 and not nxt_last) or re.search(r"[,.!?]$", w["w"]):
            chunks.append((li, cur)); cur = []
    if cur:
        chunks.append((li, cur))

out_dir = os.path.join(ROOT, "caps"); os.makedirs(out_dir, exist_ok=True)
manifest = []
for i, (li, ws) in enumerate(chunks):
    s = 0.0 if i == 0 else ws[0]["s"] - 0.04
    nxt = chunks[i + 1][1][0]["s"] - 0.04 if i + 1 < len(chunks) else lines[-1]["end"] + 1.5
    e = min(nxt, ws[-1]["e"] + 0.6) if chunks[i + 1:] and chunks[i + 1][0] != li else nxt
    e = min(nxt, max(e, ws[-1]["e"] + 0.25))
    toks = [(re.sub(r"[,.!?]", "", w["w"]).upper(), norm(w["w"]) in KEY[li]) for w in ws]
    # wrap into max two rows
    rows, row = [], []
    for t in toks:
        trial = " ".join(x[0] for x in row + [t])
        if row and FONT.getlength(trial) > MAXW:
            rows.append(row); row = [t]
        else:
            row.append(t)
    rows.append(row)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    lh = 122
    y0 = CY - lh * len(rows) / 2
    for r, row in enumerate(rows):
        total = FONT.getlength(" ".join(x[0] for x in row))
        x = (W - total) / 2
        for txt, key in row:
            d.text((x, y0 + r * lh), txt, font=FONT, fill=YEL if key else WHITE, stroke_width=9, stroke_fill=(0, 0, 0, 255))
            x += FONT.getlength(txt + " ")
    p = os.path.join(out_dir, f"{i:02d}.png")
    img.save(p)
    manifest.append({"png": p, "s": round(s, 3), "e": round(e, 3), "text": " ".join(t for t, _ in toks)})
json.dump(manifest, open(os.path.join(out_dir, "caps.json"), "w"), indent=1)
for m in manifest:
    print(f'{m["s"]:6.2f}-{m["e"]:6.2f} {m["text"]}')
