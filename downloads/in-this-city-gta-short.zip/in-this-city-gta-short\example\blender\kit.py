"""In-this-city kit: reusable procedural parts for a sunny open-world game city (Blender 5.2, EEVEE).
Everything is built from code: no downloaded models, no real brands. Forward for people and cars = +Y.
"""
import bpy, bmesh, math, random
from mathutils import Vector, Matrix


# ---------------------------------------------------------------- basics
def lin(hexstr):
    h = hexstr.lstrip('#')
    out = []
    for i in (0, 2, 4):
        c = int(h[i:i + 2], 16) / 255
        out.append(c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4)
    return tuple(out)


def coll(name, parent=None):
    if name in bpy.data.collections:
        return bpy.data.collections[name]
    c = bpy.data.collections.new(name)
    (parent or bpy.context.scene.collection).children.link(c)
    return c


def nodes_of(m):
    try:
        m.use_nodes = True
    except Exception:
        pass
    return m.node_tree.nodes, m.node_tree.links


MATS = {}


def mat(name, color, rough=0.5, metal=0.0, coat=0.0, emit=None, estr=0.0, spec=0.5):
    if name in MATS:
        return MATS[name]
    m = bpy.data.materials.new(name)
    n, _ = nodes_of(m)
    b = n.get("Principled BSDF")
    b.inputs["Base Color"].default_value = (*(lin(color) if isinstance(color, str) else color), 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metal
    b.inputs["Specular IOR Level"].default_value = spec
    if coat:
        b.inputs["Coat Weight"].default_value = coat
        b.inputs["Coat Roughness"].default_value = 0.05
    if emit:
        b.inputs["Emission Color"].default_value = (*(lin(emit) if isinstance(emit, str) else emit), 1)
        b.inputs["Emission Strength"].default_value = estr
    m.diffuse_color = (*(lin(color) if isinstance(color, str) else color), 1)
    MATS[name] = m
    return m


def obj(name, me, c, loc=(0, 0, 0), rot=(0, 0, 0), parent=None, m=None):
    o = bpy.data.objects.new(name, me)
    c.objects.link(o)
    if parent:
        o.parent = parent
    o.location = loc
    o.rotation_euler = rot
    if m is not None and me is not None:
        if len(me.materials) == 0:
            me.materials.append(m)
    return o


def empty(name, c, loc=(0, 0, 0), parent=None, rot=(0, 0, 0)):
    o = bpy.data.objects.new(name, None)
    o.empty_display_size = 0.1
    c.objects.link(o)
    if parent:
        o.parent = parent
    o.location = loc
    o.rotation_euler = rot
    return o


def _finish(bm, name, smooth=False, sharp=None):
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    if smooth:
        for p in me.polygons:
            p.use_smooth = True
        if sharp:
            try:
                me.set_sharp_from_angle(angle=sharp)
            except Exception:
                pass
    return me


def cube_me(name, sx, sy, sz, taper_top=None):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    for v in bm.verts:
        if taper_top and v.co.z > 0:
            v.co.x *= taper_top[0]
            v.co.y *= taper_top[1]
            v.co.y += taper_top[2] if len(taper_top) > 2 else 0
        v.co.x *= sx
        v.co.y *= sy
        v.co.z *= sz
    return _finish(bm, name)


def cyl_me(name, r, h, seg=16, r2=None, smooth=True):
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=seg, radius1=r,
                          radius2=r if r2 is None else r2, depth=h)
    return _finish(bm, name, smooth, sharp=math.radians(40))


def sphere_me(name, r, u=20, v=12):
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=u, v_segments=v, radius=r)
    return _finish(bm, name, smooth=True)


def plane_me(name, sx, sy):
    bm = bmesh.new()
    bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=0.5)
    for v in bm.verts:
        v.co.x *= sx
        v.co.y *= sy
    return _finish(bm, name)


def bevel(o, w=0.03, seg=2):
    md = o.modifiers.new("bev", 'BEVEL')
    md.width = w
    md.segments = seg
    md.limit_method = 'ANGLE'
    return o


def box(name, c, size, loc, m, bev=0.0, seg=2, parent=None, rot=(0, 0, 0), taper=None):
    o = obj(name, cube_me(name, *size, taper_top=taper), c, loc, rot, parent, m)
    if bev:
        bevel(o, bev, seg)
        for p in o.data.polygons:
            p.use_smooth = True
        try:
            o.data.set_sharp_from_angle(angle=math.radians(50))
        except Exception:
            pass
    return o


# ---------------------------------------------------------------- special materials
def building_mat():
    if "building" in MATS:
        return MATS["building"]
    m = bpy.data.materials.new("building")
    n, l = nodes_of(m)
    out = n.get("Material Output")
    wall = n.get("Principled BSDF")
    wall.inputs["Roughness"].default_value = 0.85
    oi = n.new("ShaderNodeObjectInfo")
    l.new(oi.outputs["Color"], wall.inputs["Base Color"])
    glass = n.new("ShaderNodeBsdfPrincipled")
    glass.inputs["Base Color"].default_value = (*lin("#1b3442"), 1)
    glass.inputs["Roughness"].default_value = 0.04
    glass.inputs["Specular IOR Level"].default_value = 0.9
    glass.inputs["Metallic"].default_value = 0.35
    geo = n.new("ShaderNodeNewGeometry")
    sep = n.new("ShaderNodeSeparateXYZ")
    l.new(geo.outputs["Position"], sep.inputs[0])
    sepn = n.new("ShaderNodeSeparateXYZ")
    l.new(geo.outputs["Normal"], sepn.inputs[0])

    def math_node(op, a=None, b=None, va=None, vb=None):
        mn = n.new("ShaderNodeMath")
        mn.operation = op
        if a is not None:
            l.new(a, mn.inputs[0])
        elif va is not None:
            mn.inputs[0].default_value = va
        if b is not None:
            l.new(b, mn.inputs[1])
        elif vb is not None:
            mn.inputs[1].default_value = vb
        return mn.outputs[0]

    xy = math_node('ADD', sep.outputs[0], sep.outputs[1])
    u = math_node('FRACT', math_node('DIVIDE', xy, vb=3.0))
    mu = math_node('MULTIPLY', math_node('GREATER_THAN', u, vb=0.2), math_node('LESS_THAN', u, vb=0.8))
    v = math_node('FRACT', math_node('DIVIDE', sep.outputs[2], vb=3.4))
    mv = math_node('MULTIPLY', math_node('GREATER_THAN', v, vb=0.3), math_node('LESS_THAN', v, vb=0.82))
    upper = math_node('GREATER_THAN', sep.outputs[2], vb=3.6)
    ground = math_node('MULTIPLY', math_node('GREATER_THAN', sep.outputs[2], vb=0.35),
                       math_node('LESS_THAN', sep.outputs[2], vb=2.9))
    gu = math_node('MULTIPLY', math_node('GREATER_THAN', u, vb=0.06), math_node('LESS_THAN', u, vb=0.94))
    side = math_node('LESS_THAN', math_node('ABSOLUTE', sepn.outputs[2]), vb=0.5)
    win = math_node('ADD', math_node('MULTIPLY', math_node('MULTIPLY', upper, mu), mv),
                    math_node('MULTIPLY', ground, gu))
    win = math_node('MULTIPLY', math_node('MINIMUM', win, vb=1.0), side)
    mix = n.new("ShaderNodeMixShader")
    l.new(win, mix.inputs[0])
    l.new(wall.outputs[0], mix.inputs[1])
    l.new(glass.outputs[0], mix.inputs[2])
    l.new(mix.outputs[0], out.inputs[0])
    MATS["building"] = m
    return m


def road_mat():
    if "road" in MATS:
        return MATS["road"]
    m = bpy.data.materials.new("road")
    n, l = nodes_of(m)
    b = n.get("Principled BSDF")
    tc = n.new("ShaderNodeTexCoord")
    noise = n.new("ShaderNodeTexNoise")
    noise.inputs["Scale"].default_value = 0.08
    noise.inputs["Detail"].default_value = 6
    l.new(tc.outputs["Object"], noise.inputs["Vector"])
    ramp = n.new("ShaderNodeValToRGB")
    ramp.color_ramp.elements[0].position = 0.45
    ramp.color_ramp.elements[0].color = (0.22, 0.22, 0.22, 1)
    ramp.color_ramp.elements[1].position = 0.58
    ramp.color_ramp.elements[1].color = (0.62, 0.62, 0.62, 1)
    l.new(noise.outputs["Fac"], ramp.inputs[0])
    l.new(ramp.outputs[0], b.inputs["Roughness"])
    fine = n.new("ShaderNodeTexNoise")
    fine.inputs["Scale"].default_value = 3.0
    l.new(tc.outputs["Object"], fine.inputs["Vector"])
    col = n.new("ShaderNodeValToRGB")
    col.color_ramp.elements[0].color = (*lin("#1d1e21"), 1)
    col.color_ramp.elements[1].color = (*lin("#34363a"), 1)
    l.new(fine.outputs["Fac"], col.inputs[0])
    l.new(col.outputs[0], b.inputs["Base Color"])
    bump = n.new("ShaderNodeBump")
    bump.inputs["Strength"].default_value = 0.08
    l.new(fine.outputs["Fac"], bump.inputs["Height"])
    l.new(bump.outputs[0], b.inputs["Normal"])
    MATS["road"] = m
    return m


def tiled_mat(name, c1, c2, mortar, scale, rough=0.8):
    if name in MATS:
        return MATS[name]
    m = bpy.data.materials.new(name)
    n, l = nodes_of(m)
    b = n.get("Principled BSDF")
    b.inputs["Roughness"].default_value = rough
    tc = n.new("ShaderNodeTexCoord")
    br = n.new("ShaderNodeTexBrick")
    br.inputs["Scale"].default_value = scale
    br.inputs["Color1"].default_value = (*lin(c1), 1)
    br.inputs["Color2"].default_value = (*lin(c2), 1)
    br.inputs["Mortar"].default_value = (*lin(mortar), 1)
    br.inputs["Mortar Size"].default_value = 0.012
    br.offset = 0.0
    l.new(tc.outputs["Object"], br.inputs["Vector"])
    l.new(br.outputs["Color"], b.inputs["Base Color"])
    bump = n.new("ShaderNodeBump")
    bump.inputs["Strength"].default_value = 0.3
    bump.invert = True
    l.new(br.outputs["Fac"], bump.inputs["Height"])
    l.new(bump.outputs[0], b.inputs["Normal"])
    MATS[name] = m
    return m


def noisy_mat(name, c1, c2, scale, rough=0.9, bump_s=0.3):
    if name in MATS:
        return MATS[name]
    m = bpy.data.materials.new(name)
    n, l = nodes_of(m)
    b = n.get("Principled BSDF")
    b.inputs["Roughness"].default_value = rough
    tc = n.new("ShaderNodeTexCoord")
    no = n.new("ShaderNodeTexNoise")
    no.inputs["Scale"].default_value = scale
    no.inputs["Detail"].default_value = 8
    l.new(tc.outputs["Object"], no.inputs["Vector"])
    r = n.new("ShaderNodeValToRGB")
    r.color_ramp.elements[0].color = (*lin(c1), 1)
    r.color_ramp.elements[1].color = (*lin(c2), 1)
    l.new(no.outputs["Fac"], r.inputs[0])
    l.new(r.outputs[0], b.inputs["Base Color"])
    bump = n.new("ShaderNodeBump")
    bump.inputs["Strength"].default_value = bump_s
    l.new(no.outputs["Fac"], bump.inputs["Height"])
    l.new(bump.outputs[0], b.inputs["Normal"])
    MATS[name] = m
    return m


def ocean_mat():
    if "ocean" in MATS:
        return MATS["ocean"]
    m = bpy.data.materials.new("ocean")
    n, l = nodes_of(m)
    b = n.get("Principled BSDF")
    b.inputs["Base Color"].default_value = (*lin("#1a9bb0"), 1)
    b.inputs["Roughness"].default_value = 0.12
    b.inputs["Specular IOR Level"].default_value = 0.35
    tc = n.new("ShaderNodeTexCoord")
    wv = n.new("ShaderNodeTexWave")
    wv.inputs["Scale"].default_value = 0.05
    wv.inputs["Distortion"].default_value = 6
    wv.inputs["Detail"].default_value = 4
    l.new(tc.outputs["Object"], wv.inputs["Vector"])
    no = n.new("ShaderNodeTexNoise")
    no.inputs["Scale"].default_value = 0.6
    l.new(tc.outputs["Object"], no.inputs["Vector"])
    add = n.new("ShaderNodeMath")
    add.operation = 'ADD'
    l.new(wv.outputs["Fac"], add.inputs[0])
    l.new(no.outputs["Fac"], add.inputs[1])
    bump = n.new("ShaderNodeBump")
    bump.inputs["Strength"].default_value = 0.25
    l.new(add.outputs[0], bump.inputs["Height"])
    l.new(bump.outputs[0], b.inputs["Normal"])
    MATS["ocean"] = m
    return m


def stripe_mat(name, c1, c2, width=0.5, axis=0):
    if name in MATS:
        return MATS[name]
    m = bpy.data.materials.new(name)
    n, l = nodes_of(m)
    b = n.get("Principled BSDF")
    b.inputs["Roughness"].default_value = 0.7
    tc = n.new("ShaderNodeTexCoord")
    sep = n.new("ShaderNodeSeparateXYZ")
    l.new(tc.outputs["Object"], sep.inputs[0])
    d = n.new("ShaderNodeMath"); d.operation = 'DIVIDE'; d.inputs[1].default_value = width * 2
    l.new(sep.outputs[axis], d.inputs[0])
    f = n.new("ShaderNodeMath"); f.operation = 'FRACT'
    l.new(d.outputs[0], f.inputs[0])
    g = n.new("ShaderNodeMath"); g.operation = 'GREATER_THAN'; g.inputs[1].default_value = 0.5
    l.new(f.outputs[0], g.inputs[0])
    mx = n.new("ShaderNodeMix"); mx.data_type = 'RGBA'
    mx.inputs[6].default_value = (*lin(c1), 1)
    mx.inputs[7].default_value = (*lin(c2), 1)
    l.new(g.outputs[0], mx.inputs[0])
    l.new(mx.outputs[2], b.inputs["Base Color"])
    MATS[name] = m
    return m


# ---------------------------------------------------------------- world / lighting
SUN_ELEV = math.radians(23)
SUN_DIR = Vector((-0.22, -1.0, 0.0)).normalized()  # toward the sun: low behind the walking direction, a bit right


def world_and_sun(c):
    sc = bpy.context.scene
    w = bpy.data.worlds.new("SunsetSky")
    sc.world = w
    n, l = nodes_of(w)
    bg = n.get("Background")
    sky = n.new("ShaderNodeTexSky")
    sky.sky_type = 'MULTIPLE_SCATTERING'
    sky.sun_disc = False
    sky.sun_elevation = SUN_ELEV
    # sky sun_rotation: angle around Z measured from +Y toward -X? we match empirically via atan2
    sky.sun_rotation = math.atan2(SUN_DIR.x, SUN_DIR.y) * -1 + math.pi
    sky.air_density = 1.3
    sky.aerosol_density = 2.2
    hs = n.new("ShaderNodeHueSaturation")
    hs.inputs["Saturation"].default_value = 1.35
    l.new(sky.outputs[0], hs.inputs["Color"])
    l.new(hs.outputs[0], bg.inputs[0])
    bg.inputs[1].default_value = 0.06
    # sun lamp
    ld = bpy.data.lights.new("Sun", 'SUN')
    ld.energy = 6.0
    ld.color = lin("#ffbf7a")
    ld.angle = math.radians(1.2)
    sun = bpy.data.objects.new("Sun", ld)
    c.objects.link(sun)
    d = Vector((SUN_DIR.x * math.cos(SUN_ELEV), SUN_DIR.y * math.cos(SUN_ELEV), math.sin(SUN_ELEV)))
    sun.rotation_euler = (-d).to_track_quat('-Z', 'Y').to_euler()
    return sky, sun


def haze(density=0.0012):
    w = bpy.context.scene.world
    n, l = nodes_of(w)
    out = n.get("World Output")
    v = n.new("ShaderNodeVolumePrincipled")
    v.inputs["Density"].default_value = density
    v.inputs["Color"].default_value = (*lin("#ffd9b0"), 1)
    v.inputs["Anisotropy"].default_value = 0.6
    l.new(v.outputs[0], out.inputs["Volume"])


def render_settings(samples=24):
    sc = bpy.context.scene
    sc.render.engine = 'BLENDER_EEVEE'
    sc.render.resolution_x = 1080
    sc.render.resolution_y = 1920
    sc.render.resolution_percentage = 100
    sc.render.fps = 30
    e = sc.eevee
    e.taa_render_samples = samples
    e.use_raytracing = True
    e.ray_tracing_method = 'SCREEN'
    e.use_shadows = True
    e.shadow_resolution_scale = 1.0
    e.volumetric_end = 600
    e.volumetric_tile_size = '8'
    try:
        e.use_fast_gi = True
    except Exception:
        pass
    sc.render.use_motion_blur = True
    sc.render.motion_blur_shutter = 0.35
    vs = sc.view_settings
    vs.view_transform = 'AgX'
    for look in ("AgX - Punchy", "Punchy", "AgX - Medium High Contrast", "Medium High Contrast"):
        try:
            vs.look = look
            break
        except Exception:
            pass
    vs.exposure = 0.3
    sc.render.image_settings.file_format = 'PNG'
    sc.render.image_settings.color_mode = 'RGB'


# ---------------------------------------------------------------- city parts
def palm(c, loc, h=None, rng=random, proto={}):
    h = h or rng.uniform(7, 10)
    root = empty("palm", c, loc)
    if "trunk" not in proto:
        tm = mat("palm_trunk", "#7a6247", 0.9)
        fm = mat("palm_frond", "#3f7a2a", 0.6, spec=0.3)
        # trunk: bent tapered tube
        bm = bmesh.new()
        segs, ring = 12, 10
        rings = []
        for i in range(segs + 1):
            t = i / segs
            z = t * 9.0
            off = 0.9 * t * t
            r = 0.22 * (1 - 0.35 * t)
            rr = []
            for k in range(ring):
                a = 2 * math.pi * k / ring
                rr.append(bm.verts.new((off + r * math.cos(a), r * math.sin(a), z)))
            rings.append(rr)
        for i in range(segs):
            for k in range(ring):
                bm.faces.new((rings[i][k], rings[i][(k + 1) % ring], rings[i + 1][(k + 1) % ring], rings[i + 1][k]))
        tme = _finish(bm, "trunk", smooth=True)
        tme.materials.append(tm)
        # frond: arched strip
        bm = bmesh.new()
        L, n = 4.2, 10
        rows = []
        for i in range(n + 1):
            t = i / n
            x = t * L
            z = 0.9 * math.sin(t * math.pi * 0.75) - 1.6 * t * t
            w = 0.55 * math.sin(math.pi * min(1, t * 1.1 + 0.08))
            rows.append((bm.verts.new((x, -w, z)), bm.verts.new((x, 0, z + 0.12)), bm.verts.new((x, w, z))))
        for i in range(n):
            a, b = rows[i], rows[i + 1]
            bm.faces.new((a[0], b[0], b[1], a[1]))
            bm.faces.new((a[1], b[1], b[2], a[2]))
        fme = _finish(bm, "frond", smooth=True)
        fme.materials.append(fm)
        proto["trunk"], proto["frond"] = tme, fme
        proto["coco"] = sphere_me("coco", 0.13, 10, 6)
        proto["coco"].materials.append(mat("coco", "#4a3a1e", 0.7))
    s = h / 9.0
    root.scale = (s, s, s)
    root.rotation_euler.z = rng.uniform(0, 2 * math.pi)
    obj("trunk", proto["trunk"], c, (0, 0, 0), parent=root)
    top = (0.9, 0, 9.0)
    for k in range(9):
        a = 2 * math.pi * k / 9 + rng.uniform(-0.15, 0.15)
        obj("frond", proto["frond"], c, top, (rng.uniform(-0.25, 0.1), rng.uniform(-0.1, 0.25), a), parent=root)
    for k in range(3):
        a = 2 * math.pi * k / 3
        obj("coco", proto["coco"], c, (0.9 + 0.18 * math.cos(a), 0.18 * math.sin(a), 8.8), parent=root)
    return root


def streetlight(c, loc, facing=1, proto={}):
    if "pole" not in proto:
        mm = mat("pole", "#3d4247", 0.4, 0.8)
        proto["pole"] = cyl_me("pole", 0.09, 7.5, 12, 0.06)
        proto["pole"].materials.append(mm)
        proto["arm"] = cube_me("arm", 2.2, 0.08, 0.08)
        proto["arm"].materials.append(mm)
        proto["head"] = cube_me("lamphead", 0.7, 0.3, 0.12)
        proto["head"].materials.append(mat("lamphead", "#2b2e31", 0.5, 0.5))
    root = empty("streetlight", c, loc, rot=(0, 0, 0 if facing > 0 else math.pi))
    obj("pole", proto["pole"], c, (0, 0, 3.75), parent=root)
    obj("arm", proto["arm"], c, (-1.0, 0, 7.4), parent=root)
    obj("lamphead", proto["head"], c, (-2.0, 0, 7.35), parent=root)
    return root


def building(c, x0, x1, y0, y1, h, color, rng=random):
    bmat = building_mat()
    o = box("bldg", c, (x1 - x0, y1 - y0, h), ((x0 + x1) / 2, (y0 + y1) / 2, h / 2), bmat)
    o.color = (*lin(color), 1)
    trim = mat("trim_" + color, color, 0.8)
    trim.diffuse_color = (*[v * 0.8 for v in lin(color)], 1)
    b = trim.node_tree.nodes.get("Principled BSDF")
    b.inputs["Base Color"].default_value = (*[v * 0.75 for v in lin(color)], 1)
    box("cornice", c, (x1 - x0 + 0.4, y1 - y0 + 0.4, 0.5), ((x0 + x1) / 2, (y0 + y1) / 2, h + 0.1), trim)
    box("base", c, (x1 - x0 + 0.1, y1 - y0 + 0.1, 0.35), ((x0 + x1) / 2, (y0 + y1) / 2, 0.17), mat("bldg_base", "#8d8a85", 0.9))
    # floor bands
    if h > 8:
        band = box("band", c, (x1 - x0 + 0.15, y1 - y0 + 0.15, 0.18), ((x0 + x1) / 2, (y0 + y1) / 2, 3.3), trim)
    # rooftop units
    for k in range(rng.randint(0, 3)):
        box("ac", c, (1.6, 1.2, 0.9), (rng.uniform(x0 + 1.5, x1 - 1.5), rng.uniform(y0 + 1.5, y1 - 1.5), h + 0.8),
            mat("ac", "#b9bcbf", 0.5, 0.3), bev=0.05)
    return o


def awning(c, x, y0, y1, z, side, name="awning", c1="#e9e2d0", c2="#1f8a8a"):
    m = stripe_mat(name + "_mat", c1, c2, 0.45, axis=1)
    depth = 1.6
    xx = x + side * depth / 2
    o = box(name, c, (depth, y1 - y0, 0.06), (xx, (y0 + y1) / 2, z), m, rot=(0, side * -0.28, 0))
    return o


def car(c, name, paint="#c23b22", cop=False, loc=(0, 0, 0), heading=0.0, open_driver=True):
    root = empty(name, c, loc, rot=(0, 0, heading))
    pm = mat("paint_" + paint, paint, 0.25, 0.2, coat=1.0)
    dark = mat("car_dark", "#141516", 0.6)
    glass = mat("car_glass", "#0a1014", 0.02, 0.0, spec=1.0)
    chrome = mat("chrome", "#c8c8c8", 0.15, 1.0)
    tire = mat("tire", "#121212", 0.85)
    inter = mat("car_interior", "#2a2724", 0.8)
    if cop:
        pm = mat("cop_black", "#0d0f12", 0.25, 0.3, coat=1.0)
    # lower body
    box(name + "_body", c, (1.86, 4.6, 0.6), (0, 0, 0.62), pm, bev=0.14, seg=3, parent=root)
    # hood/trunk slight wedge
    box(name + "_hood", c, (1.8, 1.3, 0.16), (0, 1.55, 0.95), pm, bev=0.07, seg=3, parent=root, taper=(0.96, 0.9))
    box(name + "_trunk", c, (1.8, 0.95, 0.16), (0, -1.75, 0.95), pm, bev=0.07, seg=3, parent=root, taper=(0.96, 0.9))
    # interior slab + seats
    box(name + "_int", c, (1.66, 2.1, 0.06), (0, -0.25, 0.93), inter, parent=root)
    for sx in (-0.42, 0.42):
        box(name + "_seat", c, (0.5, 0.18, 0.7), (sx, -0.62, 1.1), inter, bev=0.05, parent=root, rot=(0.15, 0, 0))
    box(name + "_dash", c, (1.66, 0.4, 0.18), (0, 0.65, 1.0), inter, bev=0.04, parent=root)
    # cabin: roof + pillars + windshield + rear glass + passenger side glass
    box(name + "_roof", c, (1.5, 1.6, 0.07), (0, -0.4, 1.47), pm, bev=0.03, parent=root)
    for (px, py, rx) in ((-0.74, 0.55, 0.62), (0.74, 0.55, 0.62), (-0.74, -1.28, -0.62), (0.74, -1.28, -0.62)):
        box(name + "_pillar", c, (0.06, 0.08, 0.66), (px, py, 1.2), pm, parent=root, rot=(rx, 0, 0))
    box(name + "_wshield", c, (1.44, 0.03, 0.66), (0, 0.55, 1.2), glass, parent=root, rot=(0.95, 0, 0))
    box(name + "_rglass", c, (1.44, 0.03, 0.6), (0, -1.3, 1.2), glass, parent=root, rot=(-0.95, 0, 0))
    box(name + "_sglassR", c, (0.02, 1.7, 0.48), (0.75, -0.38, 1.21), glass, parent=root)
    if not open_driver:
        box(name + "_sglassL", c, (0.02, 1.7, 0.48), (-0.75, -0.38, 1.21), glass, parent=root)
    # bumpers, lights, mirrors
    box(name + "_bf", c, (1.9, 0.2, 0.22), (0, 2.32, 0.45), dark, bev=0.06, parent=root)
    box(name + "_br", c, (1.9, 0.2, 0.22), (0, -2.32, 0.45), dark, bev=0.06, parent=root)
    hl = mat("headlight", "#ffffff", 0.1, emit="#fff4e0", estr=3.0)
    tl = mat("taillight", "#8a0000", 0.2, emit="#ff1a1a", estr=2.0)
    for sx in (-0.68, 0.68):
        box(name + "_hl", c, (0.42, 0.06, 0.12), (sx, 2.31, 0.72), hl, parent=root)
        box(name + "_tl", c, (0.42, 0.06, 0.12), (sx, -2.31, 0.75), tl, parent=root)
        box(name + "_mirror", c, (0.18, 0.1, 0.1), (sx * 1.42, 0.45, 1.02), pm, bev=0.03, parent=root)
    box(name + "_grille", c, (0.8, 0.04, 0.16), (0, 2.31, 0.6), dark, parent=root)
    # wheels
    wme = cyl_me("wheel", 0.34, 0.24, 24)
    wme.materials.append(tire)
    rme = cyl_me("rim", 0.2, 0.25, 16)
    rme.materials.append(chrome)
    for wx in (-0.84, 0.84):
        for wy in (-1.45, 1.45):
            obj(name + "_wheel", wme, c, (wx, wy, 0.34), (0, math.pi / 2, 0), parent=root)
            obj(name + "_rim", rme, c, (wx * 1.01, wy, 0.34), (0, math.pi / 2, 0), parent=root)
    extra = {}
    if cop:
        wm = mat("cop_white", "#f2f2f2", 0.25, 0.1, coat=1.0)
        for sx in (-0.945, 0.945):
            box(name + "_door", c, (0.02, 2.0, 0.42), (sx, -0.15, 0.68), wm, parent=root)
        box(name + "_roofw", c, (1.38, 1.5, 0.02), (0, -0.4, 1.51), wm, parent=root)
        red = bpy.data.materials.new(name + "_red")
        n, _ = nodes_of(red)
        b = n.get("Principled BSDF")
        b.inputs["Base Color"].default_value = (*lin("#ff1010"), 1)
        b.inputs["Emission Color"].default_value = (*lin("#ff1010"), 1)
        b.inputs["Emission Strength"].default_value = 30
        blue = bpy.data.materials.new(name + "_blue")
        n, _ = nodes_of(blue)
        b = n.get("Principled BSDF")
        b.inputs["Base Color"].default_value = (*lin("#1030ff"), 1)
        b.inputs["Emission Color"].default_value = (*lin("#1030ff"), 1)
        b.inputs["Emission Strength"].default_value = 30
        box(name + "_bar", c, (1.2, 0.3, 0.1), (0, -0.2, 1.56), dark, bev=0.03, parent=root)
        box(name + "_red", c, (0.55, 0.26, 0.1), (-0.3, -0.2, 1.61), red, bev=0.03, parent=root)
        box(name + "_blue", c, (0.55, 0.26, 0.1), (0.3, -0.2, 1.61), blue, bev=0.03, parent=root)
        lr = bpy.data.lights.new(name + "_lr", 'POINT'); lr.color = (1, 0.05, 0.05); lr.energy = 0
        lb = bpy.data.lights.new(name + "_lb", 'POINT'); lb.color = (0.1, 0.2, 1); lb.energy = 0
        lr.shadow_soft_size = lb.shadow_soft_size = 0.2
        obj(name + "_lr", lr, c, (-0.5, -0.2, 1.9), parent=root)
        obj(name + "_lb", lb, c, (0.5, -0.2, 1.9), parent=root)
        extra = dict(red=red, blue=blue, lr=lr, lb=lb)
    return root, extra


def cop_lights_anim(extra, f0, f1, period=8):
    for f in range(f0, f1 + 1):
        ph = ((f - f0) // (period // 2)) % 2
        for key, on in (("red", ph == 0), ("blue", ph == 1)):
            b = extra[key].node_tree.nodes.get("Principled BSDF")
            b.inputs["Emission Strength"].default_value = 60 if on else 2
            b.inputs["Emission Strength"].keyframe_insert("default_value", frame=f)
        extra["lr"].energy = 900 if ph == 0 else 0
        extra["lr"].keyframe_insert("energy", frame=f)
        extra["lb"].energy = 900 if ph == 1 else 0
        extra["lb"].keyframe_insert("energy", frame=f)


def gas_pump(c, loc, rot=0.0):
    root = empty("pump", c, loc, rot=(0, 0, rot))
    box("pump_body", c, (0.75, 0.55, 1.95), (0, 0, 0.975), mat("pump_white", "#eeeeee", 0.35), bev=0.06, parent=root)
    box("pump_top", c, (0.8, 0.6, 0.35), (0, 0, 1.95), mat("pump_red", "#d0301e", 0.35), bev=0.05, parent=root)
    box("pump_screen", c, (0.4, 0.03, 0.3), (0, 0.285, 1.45), mat("pump_screen", "#0b1a12", 0.1, emit="#40ff90", estr=1.5), parent=root)
    box("pump_nozzle", c, (0.1, 0.12, 0.35), (0.25, 0.3, 1.05), mat("pump_dark", "#1a1a1a", 0.5), parent=root)
    box("pump_base", c, (1.1, 1.6, 0.18), (0, 0, 0.09), mat("concrete", "#a8a49c", 0.85), parent=root)
    return root


def text_obj(c, body, loc, rot, size, m, extrude=0.03):
    cu = bpy.data.curves.new("txt", 'FONT')
    cu.body = body
    cu.size = size
    cu.extrude = extrude
    cu.align_x = 'CENTER'
    o = bpy.data.objects.new("txt", cu)
    c.objects.link(o)
    o.location = loc
    o.rotation_euler = rot
    cu.materials.append(m)
    return o


# ---------------------------------------------------------------- city layout
# Main boulevard along +Y. Road x in [-6, 6], sidewalks to |x| = 10.
CAFE_Y = 20.0          # cafe storefront, right side (x = 10), counter faces -X
GAS_Y = (62.0, 92.0)   # gas station lot, left side
COP_Y = 112.0          # pull-over spot, right lane
BEACH_Y = 150.0        # promenade starts here, ocean beyond


def build_city(seed=7):
    rng = random.Random(seed)
    city = coll("City")
    world_and_sun(city)
    road = road_mat()
    walk = tiled_mat("sidewalk", "#c9c0b0", "#bfb6a6", "#9a9284", 0.9)
    curb = mat("curb", "#c9c5bd", 0.8)
    paint_w = mat("paint_white", "#e8e8e2", 0.6)
    paint_y = mat("paint_yellow", "#e0b02a", 0.6)
    concrete = noisy_mat("lot_concrete", "#9c9890", "#b3afa6", 0.4, 0.8, 0.1)

    # ground + main road
    obj("ground", plane_me("ground", 1200, 600 + BEACH_Y), city, (0, (BEACH_Y - 600) / 2, -0.02), m=mat("ground_dirt", "#8f8a70", 0.95))
    obj("road", plane_me("road", 12, 220), city, (0, 40, 0), m=road)
    # cross street at y=40 and y=100
    for cy in (42.0, 100.0):
        obj("xroad", plane_me("xroad", 220, 12), city, (0, cy, 0.005), m=road)
    # lane markings
    for y in range(-68, BEACH_Y.__int__() - 2, 1):
        pass
    y = -68.0
    while y < BEACH_Y - 3:
        if not any(abs(y - cy) < 8 for cy in (42.0, 100.0)):
            for sx in (-3.0, 3.0):
                obj("dash", plane_me("dash", 0.15, 3.0), city, (sx, y, 0.01), m=paint_w)
            for sx in (-0.12, 0.12):
                obj("cline", plane_me("cline", 0.12, 4.0), city, (sx, y + 1.5, 0.01), m=paint_y)
        y += 8.0
    for sx in (-5.6, 5.6):
        obj("edge", plane_me("edge", 0.15, 220), city, (sx, 40, 0.009), m=paint_w)
    # crosswalks
    for cy in (42.0, 100.0):
        for side in (-1, 1):
            for k in range(-5, 6):
                obj("zebra", plane_me("zebra", 0.6, 3.0), city, (k * 1.1, cy + side * 7.8, 0.012), m=paint_w)
    # sidewalks (raised), split at cross streets
    segs = [(-70, 35.5), (48.5, 93.5), (106.5, BEACH_Y)]
    for side in (-1, 1):
        for (a, b) in segs:
            box("sidewalk", city, (4.0, b - a, 0.16), (side * 8.0, (a + b) / 2, 0.08), walk)
            box("curb", city, (0.25, b - a, 0.17), (side * 6.1, (a + b) / 2, 0.085), curb)
    # buildings
    colors = ["#f2c6a0", "#f6e3b4", "#a8d8d2", "#f4b6b6", "#e8e4dc", "#c9b8e6", "#f7d08a", "#bfe3c0", "#f0a987", "#e9d7c1"]
    for side in (-1, 1):
        for (a, b) in segs:
            y = a + 0.5
            while y < b - 4:
                w = rng.uniform(9, 17)
                y1 = min(y + w, b - 0.5)
                if side < 0 and y1 > GAS_Y[0] and y < GAS_Y[1]:
                    y = GAS_Y[1] + 0.5
                    continue
                if side > 0 and abs((y + y1) / 2 - CAFE_Y) < 6:
                    h = 7.5
                elif side < 0 and 40 < y1 <= GAS_Y[0] + 1:
                    h = 6.5
                else:
                    h = rng.choice([6.5, 8, 10, 13, 17, 22, 28])
                depth = rng.uniform(12, 20)
                x0, x1 = (10.0, 10.0 + depth) if side > 0 else (-10.0 - depth, -10.0)
                building(city, x0, x1, y, y1, h, rng.choice(colors), rng)
                y = y1 + rng.uniform(0.4, 1.5)
    # distant skyline
    for k in range(40):
        a = rng.uniform(0, 2 * math.pi)
        r = rng.uniform(140, 260)
        x, yy = math.cos(a) * r, 60 + math.sin(a) * r
        if yy > BEACH_Y + 20:
            continue
        hgt = rng.uniform(25, 80)
        building(city, x - 8, x + 8, yy - 8, yy + 8, hgt, rng.choice(colors), rng)
    # palms + streetlights along sidewalks
    for side in (-1, 1):
        y = -60.0
        i = 0
        while y < BEACH_Y - 2:
            if not any(abs(y - cy) < 9 for cy in (42.0, 100.0)) and not (side < 0 and GAS_Y[0] - 2 < y < GAS_Y[1] + 2):
                if i % 2 == 0:
                    if not (side > 0 and abs(y - CAFE_Y) < 4):
                        palm(city, (side * 7.0, y, 0.16), rng=rng)
                else:
                    streetlight(city, (side * 6.6, y, 0.16), facing=side)
            y += 7.0
            i += 1

    # ---- cafe storefront (right side, x = 10)
    cafe = coll("Cafe", city)
    box("cafe_front", cafe, (0.4, 9.0, 7.6), (10.1, CAFE_Y, 3.8), mat("cafe_wall", "#2f6f6a", 0.6))
    box("cafe_opening", cafe, (0.5, 3.4, 1.5), (10.1, CAFE_Y, 1.85), mat("cafe_inside", "#3a2a1e", 0.9))
    box("cafe_counter", cafe, (0.7, 3.6, 1.05), (9.0, CAFE_Y, 0.68), mat("cafe_wood", "#7a4a28", 0.5), bev=0.03)
    box("cafe_top", cafe, (0.85, 3.7, 0.06), (8.98, CAFE_Y, 1.22), mat("cafe_top", "#e8e2d6", 0.3))
    box("cafe_back", cafe, (0.25, 3.4, 1.0), (9.8, CAFE_Y + 0.2, 0.5), mat("cafe_shelf", "#5a3a22", 0.7))
    for k in range(6):
        box("cup", cafe, (0.09, 0.09, 0.12), (8.85, CAFE_Y - 1.2 + k * 0.45, 1.31), mat("cup", "#f4f1ea", 0.4))
    box("espresso", cafe, (0.3, 0.6, 0.5), (9.8, CAFE_Y + 1.0, 1.25), mat("chrome", "#c8c8c8", 0.15, 1.0), bev=0.04)
    awning(cafe, 9.9, CAFE_Y - 4.2, CAFE_Y + 4.2, 3.2, -1, "cafe_awning", "#f1ece0", "#2b8c87")
    text_obj(cafe, "BEAN THERE", (9.85, CAFE_Y, 4.3), (math.pi / 2, 0, -math.pi / 2), 0.9,
             mat("sign_cream", "#fff1d6", 0.4, emit="#fff1d6", estr=0.6))
    # tables
    for k, yy in enumerate((CAFE_Y - 6, CAFE_Y + 6)):
        box("table", cafe, (0.8, 0.8, 0.05), (8.6, yy, 0.9), mat("table", "#e0e0e0", 0.3, 0.6))
        obj("tleg", cyl_me("tleg", 0.04, 0.75), cafe, (8.6, yy, 0.53), m=mat("pole", "#3d4247", 0.4, 0.8))

    # ---- gas station (left side)
    gas = coll("GasStation", city)
    gy0, gy1 = GAS_Y
    box("gas_lot", gas, (24, gy1 - gy0, 0.06), (-22, (gy0 + gy1) / 2, 0.03), concrete)
    box("gas_canopy", gas, (12, 18, 0.9), (-19, (gy0 + gy1) / 2, 5.6), mat("canopy_white", "#f4f4f2", 0.4), bev=0.05)
    box("gas_canopy_band", gas, (12.1, 18.1, 0.35), (-19, (gy0 + gy1) / 2, 5.45), mat("canopy_band", "#c22b1d", 0.4))
    for cx in (-15.5, -22.5):
        for cy in (gy0 + 7, gy1 - 7):
            obj("gas_col", cyl_me("gcol", 0.22, 5.2), gas, (cx, cy, 2.6), m=mat("canopy_white", "#f4f4f2", 0.4))
    for py in (gy0 + 9, (gy0 + gy1) / 2, gy1 - 9):
        gas_pump(gas, (-19, py, 0.06))
    building(gas, -34, -26, gy0 + 4, gy1 - 4, 4.5, "#f4f0e6", rng)
    box("gas_sign_pole", gas, (0.3, 0.3, 9), (-11.5, gy0 + 1.5, 4.5), mat("pole", "#3d4247", 0.4, 0.8))
    box("gas_sign", gas, (0.4, 3.2, 2.0), (-11.5, gy0 + 1.5, 9.5), mat("canopy_band", "#c22b1d", 0.4))
    text_obj(gas, "SUNFUEL", (-11.25, gy0 + 1.5, 9.2), (math.pi / 2, 0, math.pi / 2), 0.7,
             mat("sign_white", "#ffffff", 0.4, emit="#ffffff", estr=0.8))

    # ---- beach: promenade, sand, ocean
    beach = coll("Beach", city)
    box("promenade", beach, (120, 10, 0.2), (0, BEACH_Y + 5, 0.1), tiled_mat("promenade", "#d9c8a8", "#cdbb99", "#9d8e72", 0.4))
    for k in range(-30, 31):
        obj("rail_post", cyl_me("rpost", 0.05, 1.0), beach, (k * 2.0, BEACH_Y + 9.8, 0.7), m=mat("rail", "#f0f0f0", 0.4, 0.3))
    box("rail", beach, (120, 0.08, 0.08), (0, BEACH_Y + 9.8, 1.2), mat("rail", "#f0f0f0", 0.4, 0.3))
    obj("sand", plane_me("sand", 400, 26), beach, (0, BEACH_Y + 22, -0.4),
        m=noisy_mat("sand", "#d8bf8f", "#e8d3a6", 0.8, 0.95, 0.4))
    obj("ocean", plane_me("ocean", 3000, 1500), beach, (0, BEACH_Y + 34 + 750, -0.45), m=ocean_mat())
    obj("foam", plane_me("foam", 400, 1.2), beach, (0, BEACH_Y + 34.6, -0.43), m=mat("foam", "#f4f6f2", 0.6))
    for k in range(-5, 6):
        if k == 0:
            continue
        palm(beach, (k * 9.0 + rng.uniform(-2, 2), BEACH_Y + 2.0, 0.2), rng=rng)
    for k in (-1, 1):
        box("bench", beach, (2.0, 0.5, 0.08), (k * 5.5, BEACH_Y + 8.5, 0.6), mat("bench", "#8a5a34", 0.6), bev=0.02)
    return city


# ---------------------------------------------------------------- people
SKIN = ["#8d5a3b", "#c58c64", "#e0ac84", "#6b4129", "#f0c8a8"]


class Person:
    def __init__(self, c, name, shirt="#2f5d8a", pants="#2a2c33", skin="#c58c64", hair="#1e1610",
                 shoes="#efefef", style="short", sleeves="short", cap=None):
        self.c = c
        self.name = name
        sm = mat("skin_" + skin, skin, 0.55, spec=0.35)
        shm = mat("cloth_" + shirt, shirt, 0.8, spec=0.2)
        pm = mat("cloth_" + pants, pants, 0.85, spec=0.2)
        hm = mat("hair_" + hair, hair, 0.6)
        fm = mat("shoe_" + shoes, shoes, 0.5)
        eye = mat("eye", "#111111", 0.2)
        P = name
        self.root = empty(P + "_root", c)
        self.pelvis = empty(P + "_pelvis", c, (0, 0, 0.95), self.root)
        self.spine = empty(P + "_spine", c, (0, 0, 0.0), self.pelvis)
        box(P + "_hipsbox", c, (0.34, 0.2, 0.18), (0, 0, 0.0), pm, bev=0.07, seg=3, parent=self.pelvis)
        box(P + "_torso", c, (0.4, 0.24, 0.52), (0, 0, 0.27), shm, bev=0.09, seg=3, parent=self.spine, taper=(1.0, 0.95))
        obj(P + "_neck", cyl_me(P + "neck", 0.05, 0.12), c, (0, 0, 0.56), parent=self.spine, m=sm)
        self.head = empty(P + "_head", c, (0, 0, 0.6), self.spine)
        h = obj(P + "_skull", sphere_me(P + "skull", 0.105), c, (0, 0.0, 0.1), parent=self.head, m=sm)
        h.scale = (0.92, 1.0, 1.15)
        if style == "long":
            hh = obj(P + "_hair", sphere_me(P + "hair", 0.114), c, (0, -0.015, 0.125), parent=self.head, m=hm)
            hh.scale = (0.98, 1.02, 1.08)
            box(P + "_hairback", c, (0.22, 0.1, 0.32), (0, -0.07, -0.02), hm, bev=0.05, seg=3, parent=self.head)
        elif style == "bald":
            pass
        else:
            hh = obj(P + "_hair", sphere_me(P + "hair", 0.111), c, (0, -0.012, 0.135), parent=self.head, m=hm)
            hh.scale = (0.97, 1.03, 0.95)
        if cap:
            cm = mat("cap_" + cap, cap, 0.6)
            obj(P + "_cap", cyl_me(P + "cap", 0.112, 0.07, 20), c, (0, 0, 0.215), parent=self.head, m=cm)
            box(P + "_brim", c, (0.2, 0.12, 0.015), (0, 0.11, 0.185), cm, parent=self.head)
        for sx in (-0.036, 0.036):
            obj(P + "_eye", sphere_me(P + "eye", 0.012, 8, 6), c, (sx, 0.094, 0.12), parent=self.head, m=eye)
        obj(P + "_nose", sphere_me(P + "nose", 0.018, 8, 6), c, (0, 0.105, 0.09), parent=self.head, m=sm)
        self.sh, self.el, self.hip, self.kn = {}, {}, {}, {}
        for side, sx in (("L", -1), ("R", 1)):
            s = empty(P + "_sh" + side, c, (sx * 0.215, 0, 0.47), self.spine)
            obj(P + "_uarm" + side, cyl_me(P + "ua", 0.06, 0.3), c, (0, 0, -0.14), parent=s, m=shm)
            e = empty(P + "_el" + side, c, (0, 0, -0.29), s)
            obj(P + "_farm" + side, cyl_me(P + "fa", 0.042, 0.27, r2=0.036), c, (0, 0, -0.13), parent=e,
                m=shm if sleeves == "long" else sm)
            obj(P + "_hand" + side, sphere_me(P + "hand", 0.048, 10, 8), c, (0, 0.0, -0.3), parent=e, m=sm)
            hp = empty(P + "_hip" + side, c, (sx * 0.095, 0, -0.03), self.pelvis)
            obj(P + "_thigh" + side, cyl_me(P + "th", 0.088, 0.45, r2=0.068), c, (0, 0, -0.22), parent=hp, m=pm)
            k = empty(P + "_kn" + side, c, (0, 0, -0.44), hp)
            obj(P + "_shin" + side, cyl_me(P + "sn", 0.066, 0.43, r2=0.052), c, (0, 0, -0.215), parent=k, m=pm)
            box(P + "_foot" + side, c, (0.105, 0.26, 0.085), (0, 0.05, -0.455), fm, bev=0.035, seg=2, parent=k)
            self.sh[side], self.el[side], self.hip[side], self.kn[side] = s, e, hp, k
        self.scale_v = 1.0
        self.rest()

    def rest(self):
        for side, sx in (("L", -1), ("R", 1)):
            self.sh[side].rotation_euler = (0.05, sx * -0.12, 0)
            self.el[side].rotation_euler = (0.15, 0, 0)

    # every animated channel is keyed every frame, so interpolation never matters
    def key(self, f):
        objs = [self.root, self.pelvis, self.spine, self.head] + list(self.sh.values()) + list(self.el.values()) \
            + list(self.hip.values()) + list(self.kn.values())
        for o in objs:
            o.keyframe_insert("rotation_euler", frame=f)
            o.keyframe_insert("location", frame=f)
        self.root.keyframe_insert("scale", frame=f)

    def pose_stand(self, t, talk=0.0, look=(0, 0)):
        br = math.sin(t * 2.2)
        self.pelvis.location.z = 0.95 + 0.004 * br
        self.spine.rotation_euler = (0.02 + 0.01 * br, 0, 0)
        self.head.rotation_euler = (look[0] + 0.02 * math.sin(t * 1.3), 0, look[1])
        for side, sx in (("L", -1), ("R", 1)):
            self.hip[side].rotation_euler = (0, 0, 0)
            self.kn[side].rotation_euler = (0, 0, 0)
            self.sh[side].rotation_euler = (0.05, sx * -0.12, 0)
            self.el[side].rotation_euler = (0.15, 0, 0)
        if talk:
            g = math.sin(t * 5.0) * 0.5 + 0.5
            self.sh["R"].rotation_euler = (0.5 + 0.25 * g * talk, -0.25, 0)
            self.el["R"].rotation_euler = (1.0 + 0.4 * g * talk, 0, 0)
            self.sh["L"].rotation_euler = (0.3 + 0.2 * (1 - g) * talk, 0.2, 0)
            self.el["L"].rotation_euler = (0.9, 0, 0)
            self.head.rotation_euler.x += 0.05 * math.sin(t * 7.0) * talk

    def pose_walk(self, t, cadence=1.0, amp=1.0):
        ph = t * 2 * math.pi * 0.95 * cadence
        s = math.sin(ph)
        self.pelvis.location.z = 0.95 + 0.025 * abs(math.cos(ph)) * amp
        self.spine.rotation_euler = (0.06, 0, 0.06 * s * amp)
        self.head.rotation_euler = (0, 0, -0.04 * s)
        for side, sg in (("L", 1), ("R", -1)):
            a = sg * s
            self.hip[side].rotation_euler = (0.42 * a * amp, 0, 0)
            bend = max(0.0, -math.sin(ph * 1 + (0 if sg > 0 else math.pi) + 0.6))
            self.kn[side].rotation_euler = (-(0.15 + 0.85 * bend) * amp, 0, 0)
            self.sh[side].rotation_euler = (-0.38 * a * amp, (-1 if side == "L" else 1) * -0.1, 0)
            self.el[side].rotation_euler = (0.25 + 0.2 * max(0, -a), 0, 0)

    def pose_phone(self, t):
        self.pose_stand(t, look=(0.05, 0))
        self.sh["R"].rotation_euler = (0.35, -0.55, 0)
        self.el["R"].rotation_euler = (2.45, 0, 0)
        g = math.sin(t * 4.0)
        self.sh["L"].rotation_euler = (0.25 + 0.15 * g, 0.25, 0)
        self.el["L"].rotation_euler = (0.9 + 0.2 * g, 0, 0)

    def pose_sit(self, t, talk=0.0):
        self.pose_stand(t, talk=talk)
        for side in ("L", "R"):
            self.hip[side].rotation_euler = (1.5, 0, 0)
            self.kn[side].rotation_euler = (-1.45, 0, 0)
        if not talk:
            for side in ("L", "R"):
                self.sh[side].rotation_euler = (0.9, 0, 0)
                self.el[side].rotation_euler = (0.6, 0, 0)

    def pose_bend(self, t, amount=0.5):
        self.pose_stand(t)
        self.spine.rotation_euler = (amount, 0, 0)
        self.head.rotation_euler = (-amount * 0.5, 0, 0)
        self.sh["L"].rotation_euler = (0.2, 0.1, 0)
        self.sh["R"].rotation_euler = (-amount * 0.5, -0.15, 0)

    def pose_shrug(self, t, k=1.0):
        self.pose_stand(t)
        for side, sx in (("L", -1), ("R", 1)):
            self.sh[side].rotation_euler = (0.3 * k, sx * -0.6 * k, 0)
            self.el[side].rotation_euler = (1.4 * k, 0, sx * 0.4 * k)
        self.spine.location.z = 0.015 * k
        self.head.rotation_euler = (-0.05, 0, 0.12 * math.sin(t * 3) * k)


def ease_pop(x):
    """0..1 -> 0..1 with a little overshoot (shrink 'pop')"""
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    return 1 - math.cos(x * math.pi * 0.5) ** 2 * (1 + 0.6 * math.sin(x * math.pi))
