"""'In this city, your bank balance floats over your head.'  blender -b city.blend -P shots.py -- <shot> [still|anim] [frame]"""
import bpy, sys, os, math, json, random
from mathutils import Vector
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import kit
import humans
from kit import CAFE_Y, GAS_Y, COP_Y, BEACH_Y

argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else ["0"]
SHOT = int(argv[0])
MODE = argv[1] if len(argv) > 1 else "still"
FPS = 30
WORDS = json.load(open(os.path.join(ROOT, "data", "words.json"), encoding="utf-8"))
BOUNDS = [0, 3.75, 6.5, 10.45, 13.85, 17.75, 20.5, 23.45, 25.75, 28.2, 33.4]
F0 = round(BOUNDS[SHOT] * FPS)
F1 = round(BOUNDS[SHOT + 1] * FPS) - 1
norm = lambda w: "".join(ch for ch in w.lower() if ch.isalnum())


def word(line, w, key="s"):
    return next(x[key] for x in WORDS if x["line"] == line and norm(x["w"]) == w)


T_FORTY = word(2, "forty")
T_DOUBLED = word(3, "doubled")
T_TICKET = word(4, "ticket")
# Marcus's balance: (time, value, seconds to count to it)
MARCUS_BAL = [(0, 2000, 0), (T_FORTY + 0.1, 1960, 0.25), (T_DOUBLED + 0.1, 1840, 0.3), (T_TICKET, 3, 1.1)]

C = kit.coll("Shot")
sc = bpy.context.scene
sc.render.use_lock_interface = True
kit.MATS.clear()
for m in bpy.data.materials:
    kit.MATS[m.name] = m

# ---------------------------------------------------------------- floating balance tags
FONT = bpy.data.fonts.load("C:/Windows/Fonts/ariblk.ttf", check_existing=True)
GREEN = kit.mat("tag_green", "#1fc24f", 0.4, emit="#19d14a", estr=1.3)
RED = kit.mat("tag_red", "#e0241b", 0.4, emit="#ff1f14", estr=1.5)
BLACK = kit.mat("tag_outline", "#050505", 0.6)
TAGS = []


def fmt(v):
    v = int(round(v))
    return ("-" if v < 0 else "") + "$" + f"{abs(v):,}"


class Tag:
    def __init__(self, person, schedule, z=2.0, size=0.2, hidden=()):
        self.schedule = schedule
        self.hidden = hidden  # list of (t0, t1) when the tag is not rendered
        self.main = self._text(size, GREEN, 0.0)
        self.outline = self._text(size, BLACK, 0.014)
        self.outline.parent = self.main
        self.outline.location = (0, 0, -0.006)
        self.main.parent = person.root
        self.main.location = (0, 0, z)
        self.base_scale = 1.0
        TAGS.append(self)

    def _text(self, size, m, offset):
        cu = bpy.data.curves.new("tag", 'FONT')
        cu.font = FONT
        cu.size = size
        cu.align_x = 'CENTER'
        cu.align_y = 'CENTER'
        cu.extrude = 0.006
        cu.offset = offset
        cu.materials.append(m)
        o = bpy.data.objects.new("tag", cu)
        C.objects.link(o)
        return o

    def value(self, t):
        v = self.schedule[0][1]
        since = 99.0
        for (ts, val, dur) in self.schedule:
            if t >= ts:
                prev = v
                if dur > 0 and t < ts + dur:
                    x = (t - ts) / dur
                    v = prev + (val - prev) * (1 - (1 - x) ** 2)
                else:
                    v = val
                since = t - ts
        return v, since

    def update(self, t):
        v, since = self.value(t)
        body = fmt(v)
        self.main.data.body = body
        self.outline.data.body = body
        low = v < 100
        m = RED if (low or since < 0.7 and since >= 0 and len(self.schedule) > 1 and self.schedule[0][1] != v) else GREEN
        self.main.data.materials[0] = m
        pop = 1.0 + 0.35 * math.exp(-since * 6) if 0 <= since < 1.5 and since < t else 1.0
        self.main.scale = (pop, pop, pop)
        hide = any(a <= t < b for a, b in self.hidden)
        self.main.hide_render = hide
        self.outline.hide_render = hide


def tag_handler(scene, depsgraph=None):
    t = scene.frame_current / FPS
    for tg in TAGS:
        tg.update(t)


def face_camera():
    for tg in TAGS:
        c = tg.main.constraints.new('TRACK_TO')
        c.target = sc.camera
        c.track_axis = 'TRACK_Z'
        c.up_axis = 'UP_Y'


# ---------------------------------------------------------------- cast + helpers
NPC_KEYS = ["npc1", "npc2", "npc3", "npc4"]


def H(key, name):
    return humans.Human(C, key, name)


def place(p, x, y, heading, s=1.0, z=0.0):
    p.root.location = (x, y, z)
    p.root.rotation_euler = (0, 0, heading)
    p.root.scale = (s, s, s)


def walker(p, start, heading, speed, cadence=1.0, t_off=0.0):
    d = Vector((-math.sin(heading), math.cos(heading), 0))
    for f in range(F0, F1 + 1):
        t = (f - F0) / FPS + t_off
        loc = Vector(start) + d * speed * t
        place(p, loc.x, loc.y, heading, 1.0, start[2] if len(start) > 2 else 0)
        p.pose_walk(t, cadence)
        p.key(f)


def mover(root, start, heading, speed):
    d = Vector((-math.sin(heading), math.cos(heading), 0))
    for f in range(F0, F1 + 1):
        t = (f - F0) / FPS
        root.location = Vector(start) + d * speed * t
        root.rotation_euler = (0, 0, heading)
        root.keyframe_insert("location", frame=f)
        root.keyframe_insert("rotation_euler", frame=f)


def keyed_hold(p, pose_fn, x, y, heading, z=0.0):
    for f in range(F0, F1 + 1):
        t = f / FPS
        place(p, x, y, heading if not callable(heading) else heading(t), 1.0, z)
        pose_fn(t)
        p.key(f)


def camera(path, lens=24, dof=None):
    cd = bpy.data.cameras.new("cam")
    cd.lens = lens
    cd.sensor_width = 36
    cd.clip_start = 0.05
    cd.clip_end = 3000
    if dof:
        cd.dof.use_dof = True
        cd.dof.aperture_fstop = dof
    cam = bpy.data.objects.new("cam", cd)
    C.objects.link(cam)
    sc.camera = cam
    for f in range(F0, F1 + 1):
        u = (f - F0) / max(1, F1 - F0)
        loc, tgt = path(u, (f - F0) / FPS)
        cam.location = loc
        cam.rotation_euler = (Vector(tgt) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
        cam.keyframe_insert("location", frame=f)
        cam.keyframe_insert("rotation_euler", frame=f)
        if dof:
            cd.dof.focus_distance = (Vector(tgt) - Vector(loc)).length
            cd.dof.keyframe_insert("focus_distance", frame=f)
    return cam


def lerp(a, b, u):
    return tuple(x + (y - x) * u for x, y in zip(a, b))


def ease(u):
    u = max(0.0, min(1.0, u))
    return u * u * (3 - 2 * u)


rng = random.Random(200 + SHOT)


def street_life(y_center, n_walkers=4, traffic=True, parked=True):
    for i in range(n_walkers):
        p = H(rng.choice(NPC_KEYS), f"npc{i}")
        side = rng.choice([-1, 1])
        x = side * rng.uniform(7.2, 9.3)
        fwd = rng.random() < 0.5
        y0 = y_center + rng.uniform(5, 22)
        walker(p, (x, y0, 0.16), 0.0 if fwd else math.pi, rng.uniform(1.1, 1.45), t_off=rng.uniform(0, 3))
        Tag(p, [(0, rng.choice([84, 312, 1290, 5400, 17800, 260, 43]), 0)], z=1.97, size=0.17)
    if traffic:
        paints = ["#d9d9d9", "#1c1c1c", "#2f5d8a", "#8a8f94", "#c9a227", "#f4f4f4", "#7a1f1f"]
        for i in range(3):
            r, _ = kit.car(C, f"traffic{i}", rng.choice(paints))
            lane = rng.choice([3.0, -3.0])
            mover(r, (lane, y_center + (rng.uniform(-30, -10) if lane > 0 else rng.uniform(25, 50)), 0),
                  0.0 if lane > 0 else math.pi, rng.uniform(9, 14))
    if parked:
        for i in range(2):
            r, _ = kit.car(C, f"parked{i}", rng.choice(["#4a6fa5", "#e8e8e8", "#303030", "#a33a2a"]))
            r.location = (rng.choice([-4.6, 4.6]), y_center + rng.uniform(8, 30), 0)


MY = BEACH_Y + 4.0

# ---------------------------------------------------------------- shots
if SHOT == 0:
    m = H("marcus", "Marcus"); Tag(m, MARCUS_BAL)
    walker(m, (8.3, 1.5, 0.16), 0.0, 1.35)
    street_life(10, 5)
    camera(lambda u, t: ((7.75, 1.5 + 1.35 * t - 3.0, 2.15), (8.45, 1.5 + 1.35 * t + 6, 1.55)), 24)

elif SHOT == 1:
    m = H("marcus", "Marcus"); Tag(m, MARCUS_BAL)
    walker(m, (8.2, 6.0, 0.16), 0.0, 1.3)
    street_life(14, 3, parked=False)

    def path(u, t):
        y = 6.0 + 1.3 * t
        return (7.6, y + 3.4, 1.35), (8.2, y, 1.55)
    camera(path, 28, dof=2.8)

elif SHOT == 2:
    m = H("marcus", "Marcus"); Tag(m, MARCUS_BAL)
    keyed_hold(m, lambda t: m.pose_stand(t, talk=0.6 if t > T_FORTY + 0.3 else 0.0, look=(0.05, 0)), 8.25, CAFE_Y, -math.pi / 2, 0.16)
    b = H("barista", "Barista"); Tag(b, [(0, 410, 0)], z=1.93, size=0.17)
    keyed_hold(b, lambda t: b.pose_stand(t + 1.3, talk=0.7 if T_FORTY - 1.2 < t < T_FORTY + 0.6 else 0.0,
                                         look=(0.35 if t < T_FORTY - 1.0 else 0.05, 0)), 9.6, CAFE_Y + 0.15, math.pi / 2, 0.16)
    street_life(CAFE_Y - 6, 0, traffic=True, parked=False)
    camera(lambda u, t: (lerp((7.0, CAFE_Y - 3.9, 2.25), (7.15, CAFE_Y - 3.3, 2.15), ease(u)), (9.0, CAFE_Y + 0.3, 1.65)), 26)

elif SHOT == 3:
    gy = (GAS_Y[0] + GAS_Y[1]) / 2
    car, _ = kit.car(C, "mcar", "#c23b22"); car.location = (-16.3, gy, 0.06)
    m = H("marcus", "Marcus"); Tag(m, MARCUS_BAL)

    def pose(t):
        m.pose_stand(t, look=(0.1, 0.5) if t < T_DOUBLED - 0.6 else (0.25, 0.0))
        m._arm("L", 0.7, 0.2)
        m.pb["lowerarm01.L"].rotation_euler = (0.6, 0, 0)
    keyed_hold(m, pose, -17.85, gy + 0.6, 0.6, 0.06)
    other, _ = kit.car(C, "gascar2", "#e8e8e8"); other.location = (-21.7, gy - 6, 0.06)
    street_life(gy - 10, 2, traffic=True, parked=False)
    camera(lambda u, t: (lerp((-16.6, gy - 3.6, 2.2), (-16.8, gy - 3.0, 2.1), ease(u)), (-18.4, gy + 1.4, 1.7)), 26)

elif SHOT == 4:
    car, _ = kit.car(C, "mcar", "#c23b22"); car.location = (4.0, COP_Y, 0)
    cop_car, ex = kit.car(C, "copcar", cop=True); cop_car.location = (4.0, COP_Y - 7.0, 0)
    kit.cop_lights_anim(ex, F0, F1)
    m = H("marcus", "Marcus"); Tag(m, MARCUS_BAL, z=2.25, size=0.16)
    for f in range(F0, F1 + 1):
        t = f / FPS
        place(m, 4.0 - 0.42, COP_Y - 0.25, 0.0, 1.0, 0.48 - 0.95)
        m.pose_sit(t)
        m.set_look(0.3, 0.9 if t < T_TICKET - 0.2 else 0.5)
        m.key(f)
    cop = H("cop", "Cop"); Tag(cop, [(0, -60000, 0)], hidden=[(0, 99)])

    def cpose(t):
        cop.pose_bend(t, 0.25)
        cop._arm("L", 0.45, 0.05); cop.pb["lowerarm01.L"].rotation_euler = (1.25, 0, 0)
        w = math.sin(t * 9) * 0.08 if t > T_TICKET - 1.2 else 0
        cop._arm("R", 0.4 + w, 0.08); cop.pb["lowerarm01.R"].rotation_euler = (1.35, 0, 0)
    keyed_hold(cop, cpose, 2.55, COP_Y - 0.2, -math.pi / 2)
    for i in range(2):
        r, _ = kit.car(C, f"pass{i}", rng.choice(["#d9d9d9", "#2f5d8a", "#1c1c1c"]))
        mover(r, (-3.0, COP_Y + 25 + i * 30, 0), math.pi, 12)
    camera(lambda u, t: (lerp((1.3, COP_Y - 2.6, 1.95), (1.5, COP_Y - 2.1, 1.85), ease(u)), (3.6, COP_Y - 0.25, 1.25)), 26)

elif SHOT == 5:
    m = H("marcus", "Marcus"); Tag(m, MARCUS_BAL)

    def pose(t):
        lt = t - BOUNDS[5]
        if lt < 1.4:
            m.pose_look_hands(t)
        else:
            m.pose_shrug(t, min(1.0, (lt - 1.4) / 0.4))
    keyed_hold(m, pose, -0.25, MY, math.pi, 0.2)
    p = H("npc2", "walker"); walker(p, (2.2, MY - 3.5, 0.2), 0.0, 1.2); Tag(p, [(0, 5400, 0)], z=1.95, size=0.17)
    camera(lambda u, t: (lerp((0.25, MY - 2.9, 0.55), (0.1, MY - 2.2, 0.65), ease(u)), (-0.25, MY, 1.7)), 24, dof=2.8)

elif SHOT == 6:
    m = H("marcus", "Marcus"); Tag(m, MARCUS_BAL)
    keyed_hold(m, lambda t: m.pose_stand(t, look=(0.0, 0.0)), -0.25, MY, 0.0, 0.2)
    d = H("date", "Date"); Tag(d, [(0, 48200, 0)], z=1.95, size=0.17)
    T6 = BOUNDS[6]
    for f in range(F0, F1 + 1):
        t = f / FPS
        lt = t - T6
        if lt < 1.3:
            place(d, -0.2, MY + 1.3, math.pi, 1.0, 0.2)
            d.pose_stand(t, look=(0.45 if lt > 0.3 else 0.0, 0))
        elif lt < 1.7:
            k = ease((lt - 1.3) / 0.4)
            place(d, -0.2, MY + 1.3, math.pi + k * math.pi / 2, 1.0, 0.2)
            d.pose_stand(t)
        else:
            w = lt - 1.7
            place(d, -0.2 + 1.25 * w, MY + 1.3, 1.5 * math.pi, 1.0, 0.2)
            d.pose_walk(w)
        d.key(f)
    camera(lambda u, t: (lerp((0.55, MY - 2.9, 2.0), (0.6, MY - 2.4, 1.95), ease(u)), (0.1, MY + 1.5, 1.75)), 26)

elif SHOT == 7:
    m = H("marcus", "Marcus"); Tag(m, MARCUS_BAL)
    keyed_hold(m, lambda t: m.pose_stand(t, look=(0.0, -0.5)), -0.25, MY, 0.0, 0.2)
    cop = H("cop", "Cop"); Tag(cop, [(0, -60000, 0)], hidden=[(0, 99)])
    walker(cop, (6.5, MY + 0.6, 0.2), math.pi / 2, 1.15, cadence=0.85)
    camera(lambda u, t: (lerp((-1.6, MY - 1.6, 0.45), (-1.4, MY - 1.4, 0.45), ease(u)), (3.0, MY + 0.4, 0.75)), 34, dof=3.5)

elif SHOT == 8:
    cop = H("cop", "Cop"); Tag(cop, [(0, -60000, 0)])
    keyed_hold(cop, lambda t: cop.pose_stand(t, look=(-0.1, 0.4)), 1.0, MY + 0.5, math.pi / 2, 0.2)
    m = H("marcus", "Marcus"); Tag(m, MARCUS_BAL)
    keyed_hold(m, lambda t: m.pose_stand(t, look=(0.3, -0.6)), -0.25, MY, 0.0, 0.2)

    def path(u, t):
        e = ease(u * 1.4)
        return lerp((2.0, MY - 1.2, 1.0), (1.9, MY - 1.0, 1.25), e), lerp((1.0, MY + 0.5, 1.2), (1.0, MY + 0.5, 2.15), e)
    camera(path, 30, dof=2.5)

else:
    cop = H("cop", "Cop"); Tag(cop, [(0, -60000, 0)])

    def cpose(t):
        cop.pose_bend(t, 0.2)
        cop._arm("L", 0.45, 0.05); cop.pb["lowerarm01.L"].rotation_euler = (1.25, 0, 0)
        cop._arm("R", 0.4 + math.sin(t * 9) * 0.08, 0.08); cop.pb["lowerarm01.R"].rotation_euler = (1.35, 0, 0)
    keyed_hold(cop, cpose, 1.0, MY + 0.5, math.pi / 2, 0.2)
    m = H("marcus", "Marcus"); Tag(m, MARCUS_BAL)
    keyed_hold(m, lambda t: m.pose_stand(t, look=(0.2, -0.7)), -0.25, MY, 0.0, 0.2)
    for i in range(3):
        p = H(NPC_KEYS[i], f"crowd{i}")
        fwd = i % 2 == 0
        walker(p, (rng.choice([-1, 1]) * rng.uniform(2.0, 4.0), MY + (-6 if fwd else 6), 0.2), 0.0 if fwd else math.pi, rng.uniform(1.1, 1.4))
        Tag(p, [(0, rng.choice([312, 1290, 17800]), 0)], z=1.95, size=0.17)
    camera(lambda u, t: (lerp((0.2, MY - 3.2, 1.5), (-2.2, MY - 9.0, 5.2), ease(u)), (0.4, MY + 0.3, 1.6)), 24)

face_camera()
bpy.app.handlers.frame_change_pre.append(tag_handler)

# ---------------------------------------------------------------- render
sc.frame_start, sc.frame_end = F0, F1
out_dir = os.path.join(ROOT, "renders", f"shot{SHOT:02d}")
os.makedirs(out_dir, exist_ok=True)
if MODE == "still":
    f = int(argv[2]) if len(argv) > 2 else (F0 + F1) // 2
    sc.frame_set(f)
    sc.render.resolution_percentage = 50
    sc.render.filepath = os.path.join(ROOT, "renders", f"still_{SHOT:02d}_{f}.png")
    bpy.ops.render.render(write_still=True)
else:
    sc.render.filepath = os.path.join(out_dir, "")
    bpy.ops.render.render(animation=True)
print("DONE", SHOT, F0, F1)
