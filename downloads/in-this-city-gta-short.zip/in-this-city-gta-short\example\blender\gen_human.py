"""Generate one realistic rigged human with MPFB (MakeHuman, CC0 assets) and save it to humans/<name>.blend.
  blender -b -P gen_human.py -- <name>
"""
import bpy, sys, os, json
HERE = os.path.dirname(os.path.abspath(__file__))
from bl_ext.user_default.mpfb.services.humanservice import HumanService

CAST = {
    "marcus": dict(gender=1.0, age=0.5, muscle=0.55, weight=0.5, height=0.55, race=(0.85, 0.05, 0.10),
                   skin="young_african_male", hair="short02", eyebrows="eyebrow001",
                   clothes=["male_casualsuit04", "shoes02"]),
    "barista": dict(gender=0.0, age=0.45, muscle=0.5, weight=0.45, height=0.45, race=(0.1, 0.85, 0.05),
                    skin="young_caucasian_female", hair="ponytail01", eyebrows="eyebrow009",
                    clothes=["female_casualsuit01", "shoes01"]),
    "cop": dict(gender=1.0, age=0.7, muscle=0.6, weight=0.62, height=0.6, race=(0.2, 0.6, 0.2),
                skin="middleage_caucasian_male", hair="short01", eyebrows="eyebrow002",
                clothes=["male_casualsuit04", "shoes04"]),
    "date": dict(gender=0.0, age=0.5, muscle=0.5, weight=0.45, height=0.6, race=(0.3, 0.2, 0.5),
                 skin="young_asian_female", hair="long01", eyebrows="eyebrow010",
                 clothes=["female_elegantsuit01", "shoes05"]),
    "npc1": dict(gender=1.0, age=0.6, muscle=0.5, weight=0.6, height=0.5, race=(0.1, 0.8, 0.1),
                 skin="middleage_caucasian_male", hair="short04", eyebrows="eyebrow003",
                 clothes=["male_casualsuit02", "shoes03"]),
    "npc2": dict(gender=0.0, age=0.4, muscle=0.5, weight=0.5, height=0.5, race=(0.8, 0.1, 0.1),
                 skin="young_african_female", hair="afro01", eyebrows="eyebrow008",
                 clothes=["female_sportsuit01", "shoes06"]),
    "npc3": dict(gender=1.0, age=0.45, muscle=0.6, weight=0.45, height=0.6, race=(0.1, 0.2, 0.7),
                 skin="young_asian_male", hair="short03", eyebrows="eyebrow004",
                 clothes=["male_casualsuit06", "shoes02"]),
    "npc4": dict(gender=0.0, age=0.8, muscle=0.4, weight=0.6, height=0.4, race=(0.1, 0.85, 0.05),
                 skin="old_caucasian_female", hair="bob02", eyebrows="eyebrow011",
                 clothes=["female_casualsuit02", "shoes01"]),
}

name = sys.argv[sys.argv.index("--") + 1]
c = CAST[name]
bpy.ops.wm.read_homefile(use_empty=True)
info = HumanService._create_default_human_info_dict()
af, ca, asn = c["race"]
info["phenotype"].update(gender=c["gender"], age=c["age"], muscle=c["muscle"], weight=c["weight"], height=c["height"],
                         race={"african": af, "caucasian": ca, "asian": asn})
info["rig"] = "default"
info["eyes"] = "high-poly/high-poly.mhclo"
info["eyebrows"] = f"{c['eyebrows']}/{c['eyebrows']}.mhclo"
info["eyelashes"] = "eyelashes01/eyelashes01.mhclo"
info["hair"] = f"{c['hair']}/{c['hair']}.mhclo"
info["clothes"] = [f"{x}/{x}.mhclo" for x in c["clothes"]]
info["skin_mhmat"] = f"skins/{c['skin']}/{c['skin']}.mhmat"
info["skin_material_type"] = "ENHANCED"
info["eyes_material_type"] = "MAKESKIN"
info["alternative_materials"] = {}
info["name"] = name
st = HumanService.get_default_deserialization_settings()
st["subdiv_levels"] = 0
st["load_clothes"] = True
basemesh = HumanService.deserialize_from_dict(info, st)
rig = basemesh.parent
for o in bpy.data.objects:
    print("OBJ", o.name, o.type, o.parent.name if o.parent else "-", tuple(round(v, 2) for v in o.dimensions))
if rig:
    print("BONES", [b.name for b in rig.data.bones][:80])
out = os.path.join(HERE, "humans", f"{name}.blend")
os.makedirs(os.path.dirname(out), exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=out)
print("SAVED", out)
