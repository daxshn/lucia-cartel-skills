---
name: in-this-city-gta-short
description: Plan and build an original 30-45 second "In this city..." rule Short that looks like a 3D open-world game (a sunny city, a player character, cars, people), with just big word captions on top, rendered in Blender. Use for GTA 6-style 3D Shorts.
---

A lite version of the method from the video "Don't Clip GTA 6. Make These 3D Shorts Instead (Free Skill)". It works with public tools only.
How to use
1. Make a file ~/.claude/skills/in-this-city-gta-short/SKILL.md. Paste the grey code block from the top of this doc first, then the rest of this doc under it.
2. In Claude Code, say: use the in-this-city-gta-short skill to make a Short where, in this city, everyone can see your wanted stars floating over your head.
What you need
* Claude Code.
* Blender (Claude drives it with Python scripts, no clicking).
* A voice tool (for example ElevenLabs) and ffmpeg.
* A normal computer with a graphics card. Render with EEVEE: stills take seconds, the full Short takes minutes.
1. Pick the rule
* Line 1 is the rule and starts "In this city". No intro, no hello. The first word lands on the first frame.
* Shape: "In this city, if you [ordinary everyday thing], [weird consequence]."
* The rule can be about anything everyday: money, lying, crushes, school, family. It doesn't have to be about crime. The city is just the world it happens in.
* Examples: every lie shrinks you an inch. Your thoughts show up as captions. Every rejection ages you a year.
* Write 5 rules, then pick the one where the consequence is the easiest to SEE with the sound off.
* Good rules turn a normal moment (a lie, a crush, a bill, a family dinner, a speeding ticket) into a social problem.
2. Write the script
* About 30 to 45 seconds, about 3 words a second, said calmly and deadpan, like a nature documentary.
* Beats: the rule, then the first time it happens, then it escalates two or three times (each bigger than the last), then a twist that flips the rule back on the player.
* One sentence per shot, one shot every 2 to 3 seconds.
3. Build the city once
* Make the city a kit of reusable Python parts, not one scene: road tiles, sidewalks, building blocks, palms, street lights, a beach strip, a gas station.
* Sunny Florida-style look: low golden sun, a little haze, wet-looking roads, saturated sky. Real-looking materials (free CC0 textures and HDRIs from Poly Haven).
* Use only free-licensed models (CC0 or CC-BY, write each one down with its license). Remove every real car badge.
* Build it once, and every new Short reuses the same streets. That is what makes a series.
4. Cast, cars and cops
* One player character you design yourself, plus a few city types (a tourist, a cop, a shop owner). Rigged humans with walk, run and idle motion.
* Cars and a cop car with lights. Unbranded.
* Never use a real game's characters, map, logos or fonts.
5. The camera
* Mostly gameplay framing: a third-person camera behind the player, about shoulder height, slightly above. A driving camera behind the car.
* Cut to a cinematic angle on the punchline (a low angle, a slow push in).
6. Just the words
* No HUD, no minimap, no overlays. The only thing on top of the picture is the caption.
* Big caption words, a few at a time, right over the city. Highlight the key word of each line.
7. Look before you render
* Render one still per shot. Score each one: would a scrolling viewer believe this is real gameplay? Write the fix before making it (too dark, light up; empty street, add cars and people; camera too high, lower it).
* Repeat until most shots score about 7 out of 10.
8. Voice, captions and sound
* Narrator voice, calm, speed no faster than 1.2.
* Captions: word-timed, big, two lines max, inside the safe area.
* Game sounds per event (doors, engines, a short low siren). No music bed. Mix to about -14 LUFS.
Title
* Name GTA 6 for search, then the rule: "If GTA 6 Had This Rule...", "In GTA 6's City, If You...".
* Post fast while the niche is new.
Checks before you post
* The rule is clear by second 3, even with the sound off.
* The first word is on frame 1.
* Nothing on screen comes from a real game: no characters, map, logos, fonts or footage.
* No black frames, captions in the safe area, loudness about -14 LUFS.
Keep it original
* Invent your own rules, city and characters. Name the game in the title if you like, but everything on screen is yours.
Want the full version?
The better, full skill (plus every style and series in one plugin) is in the community: https://www.skool.com/mega-media-labs-6489/about