"""Synthesized game-style SFX bed (no music) -> data/sfx.wav, 48 kHz stereo."""
import json, os, re, wave
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR = 48000
DUR = 33.45
rng = np.random.default_rng(3)
words = json.load(open(os.path.join(ROOT, "data", "words.json"), encoding="utf-8"))
norm = lambda w: re.sub(r"[^a-z0-9]", "", w.lower())
t_of = lambda line, w: next(x["e"] for x in words if x["line"] == line and norm(x["w"]) == w)

L = int(DUR * SR)
out = np.zeros((L, 2))


def db(x):
    return 10 ** (x / 20)


def lowpass(x, fc):
    a = np.exp(-2 * np.pi * fc / SR)
    y = np.empty_like(x)
    acc = 0.0
    for i in range(len(x)):
        acc = (1 - a) * x[i] + a * acc
        y[i] = acc
    return y


def lp_fast(x, fc, passes=2):
    # FFT brickwall-ish lowpass with soft rolloff, fast for long buffers
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    X *= 1 / (1 + (f / fc) ** (2 * passes))
    return np.fft.irfft(X, len(x))


def bp_fast(x, lo, hi):
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    X *= (1 / (1 + (f / hi) ** 4)) * (1 / (1 + (lo / np.maximum(f, 1)) ** 4))
    return np.fft.irfft(X, len(x))


def add(sig, t0, gain_db=0, pan=0.0):
    i0 = int(t0 * SR)
    if sig.ndim == 1:
        l, r = np.sqrt(0.5 * (1 - pan)), np.sqrt(0.5 * (1 + pan))
        sig = np.stack([sig * l, sig * r], 1) * np.sqrt(2)
    n = min(len(sig), L - i0)
    if n > 0:
        out[i0:i0 + n] += sig[:n] * db(gain_db)


def env(n, a, r):
    e = np.ones(n)
    na, nr = int(a * SR), int(r * SR)
    e[:na] = np.linspace(0, 1, na)
    e[n - nr:] *= np.linspace(1, 0, nr)
    return e


def norm1(x):
    return x / (np.max(np.abs(x)) + 1e-9)


# --- city ambience 0 .. 17.9
n = int(18.2 * SR)
amb = norm1(lp_fast(rng.standard_normal(n), 300)) * 0.6 + norm1(bp_fast(rng.standard_normal(n), 800, 4000)) * 0.12
add(amb * env(n, 0.02, 0.4), 0, -27)

def passby(dur=2.2, f0=90):
    n = int(dur * SR); t = np.arange(n) / SR
    x = (t - dur / 2) / (dur / 5); g = 1 / (1 + x ** 2)
    pitch = f0 * (1 + 0.12 * -np.tanh(x))
    eng = np.sin(2 * np.pi * np.cumsum(pitch) / SR) + 0.5 * np.sin(4 * np.pi * np.cumsum(pitch) / SR)
    road = norm1(bp_fast(rng.standard_normal(n), 300, 2500))
    return (0.5 * eng + road) * g, np.tanh(x)
for t0, gdb in ((0.6, -16), (2.6, -19), (4.6, -18), (11.0, -22), (15.2, -20)):
    s_, p_ = passby()
    add(np.stack([s_ * np.sqrt(0.5 * (1 - p_)), s_ * np.sqrt(0.5 * (1 + p_))], 1), t0, gdb)

# --- cash register: bell + drawer
def chaching():
    n = int(0.9 * SR); t = np.arange(n) / SR
    bell = sum(np.sin(2 * np.pi * f * t) * a for f, a in ((2100, 1), (3150, 0.6), (4200, 0.35))) * np.exp(-t * 5)
    bell2 = np.zeros(n); k = int(0.09 * SR); bell2[k:] = bell[:n - k] * 0.8
    drawer = norm1(bp_fast(rng.standard_normal(n), 150, 1200)) * np.exp(-t * 30) * 0.6
    return norm1(bell + bell2 + drawer)
add(chaching(), t_of(2, "forty") + 0.05, -14, 0.2)
add(chaching(), t_of(3, "doubled") + 0.05, -14, -0.2)

# --- ticket: fast ticking count-down then a low thud
T = t_of(4, "ticket") - 0.25
for k in range(26):
    n = int(0.03 * SR); tt = np.arange(n) / SR
    add(np.sin(2 * np.pi * 1800 * tt) * np.exp(-tt * 160), T + k * 0.042, -20)
n = int(0.6 * SR); tt = np.arange(n) / SR
add(np.sin(2 * np.pi * 55 * tt) * np.exp(-tt * 7) + 0.4 * np.sin(2 * np.pi * 110 * tt) * np.exp(-tt * 9), T + 1.15, -10)

# --- pump click, cup clink
n = int(0.08 * SR); add(rng.standard_normal(n) * np.exp(-np.arange(n) / SR * 80), 10.7, -22)
for t0 in (7.2, 7.45):
    n = int(0.4 * SR); tt = np.arange(n) / SR
    add((np.sin(2 * np.pi * 2900 * tt) + 0.6 * np.sin(2 * np.pi * 4300 * tt)) * np.exp(-tt * 18), t0, -25, 0.3)

# --- engine idle 10.45 .. 17.75
n = int(7.3 * SR); t = np.arange(n) / SR
idle = np.sin(2 * np.pi * 38 * t) + 0.6 * np.sin(2 * np.pi * 76 * t) + 0.3 * np.sin(2 * np.pi * 114 * t)
idle = idle * (0.8 + 0.2 * np.sin(2 * np.pi * 12.5 * t)) + 0.3 * norm1(lp_fast(rng.standard_normal(n), 200))
add(norm1(idle) * env(n, 0.3, 0.5), 10.45, -27)

def chirp(dur=0.7):
    n = int(dur * SR); t = np.arange(n) / SR
    f = 420 + 380 * np.sin(np.pi * t / dur)
    return lp_fast(np.sign(np.sin(2 * np.pi * np.cumsum(f) / SR)), 1600) * env(n, 0.02, 0.15)
add(chirp(), 13.95, -19, -0.3)

# --- beach waves 17.6 .. end
n = L - int(17.6 * SR); t = np.arange(n) / SR
surf = norm1(lp_fast(rng.standard_normal(n), 900)) * (0.45 + 0.55 * (0.5 + 0.5 * np.sin(2 * np.pi * 0.13 * t - 1.2)) ** 2)
add((surf + norm1(bp_fast(rng.standard_normal(n), 2000, 8000)) * 0.08) * env(n, 0.5, 0.8), 17.6, -23)

# --- footsteps: date walks away, cop strolls in
def steps(t0, k, gap, gdb, pan0, dpan):
    for i in range(k):
        n = int(0.09 * SR); tt = np.arange(n) / SR
        add(norm1(bp_fast(rng.standard_normal(n), 300, 3000)) * np.exp(-tt * 55), t0 + i * gap, gdb, pan0 + dpan * i)
steps(22.25, 3, 0.42, -21, 0.0, 0.25)
steps(23.5, 5, 0.5, -20, 0.6, -0.15)

# --- reveal sting on "sixty": low boom + descending tone
T = t_of(8, "minus") - 0.05
n = int(1.6 * SR); tt = np.arange(n) / SR
boom = np.sin(2 * np.pi * (48 - 10 * tt) * tt) * np.exp(-tt * 2.5)
tone = np.sin(2 * np.pi * np.cumsum(420 * np.exp(-tt * 1.2) + 90) / SR) * np.exp(-tt * 2.2) * 0.35
add(boom + tone, T, -11)

out = np.clip(out, -1, 1)
pcm = (out * 32767).astype(np.int16)
with wave.open(os.path.join(ROOT, "data", "sfx.wav"), "wb") as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
print("data/sfx.wav", DUR, "s, peak", float(np.max(np.abs(out))))
