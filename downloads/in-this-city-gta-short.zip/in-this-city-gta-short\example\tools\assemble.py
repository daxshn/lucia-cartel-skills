"""renders/shotNN/####.png + caps + data/mix.wav -> out/in_this_city_bank_balance.mp4"""
import glob, json, os, subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
alld = os.path.join(ROOT, "renders", "all")
os.makedirs(alld, exist_ok=True)
for f in glob.glob(os.path.join(alld, "*.png")):
    os.remove(f)
frames = sorted(glob.glob(os.path.join(ROOT, "renders", "shot*", "*.png")), key=lambda p: int(os.path.basename(p)[:-4]))
for k, p in enumerate(frames):
    assert int(os.path.basename(p)[:-4]) == k, f"gap at frame {k}: {p}"
    os.link(p, os.path.join(alld, f"{k:04d}.png"))
print(len(frames), "frames")

caps = json.load(open(os.path.join(ROOT, "caps", "caps.json")))
cmd = ["ffmpeg", "-v", "error", "-y", "-framerate", "30", "-i", os.path.join(alld, "%04d.png")]
for c in caps:
    cmd += ["-i", c["png"]]
cmd += ["-i", os.path.join(ROOT, "data", "mix.wav")]
fc, last = [], "0:v"
for i, c in enumerate(caps):
    nxt = f"v{i}"
    fc.append(f"[{last}][{i + 1}:v]overlay=0:0:enable='between(t,{c['s']},{c['e']})'[{nxt}]")
    last = nxt
fc.append(f"[{last}]format=yuv420p[vout]")
out = os.path.join(ROOT, "out", "in_this_city_bank_balance.mp4")
cmd += ["-filter_complex", ";".join(fc), "-map", "[vout]", "-map", f"{len(caps) + 1}:a",
        "-c:v", "libx264", "-preset", "slow", "-crf", "17", "-r", "30", "-c:a", "aac", "-b:a", "192k",
        "-shortest", "-movflags", "+faststart", out]
subprocess.run(cmd, check=True)
print("wrote", out)
